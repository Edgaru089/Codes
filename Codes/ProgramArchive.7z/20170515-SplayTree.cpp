/*
DOCUMENT CODE "SplayTree.cpp"
CREATION DATE 2017-05-15
SIGNATURE CODE_20170515_SPLAYTREE
TOPIC Splay ��ƽ����
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170515_SPLAYTREE

#include <cstdlib>
#include <iostream>
using namespace std;

struct node {
	int val;
	node* lson, *rson;
	node* par;
};

node pool[200001], *root;
int top;

void insert(int x, node*& p = root, node* parent = NULL) {
	if (p == NULL) {
		p = &pool[++top];
		p->val = x;
		p->lson = p->rson = NULL;
		p->par = parent;
		return;
	}
	else if (x <= p->val) {    //lson
		insert(x, p->lson, p);
	}
	else {   //rson
		insert(x, p->rson, p);
	}
}

void left_rotate(node* p) {
	node* parent = p->par;
	if (p == root || parent->rson != p)
		return;
	node* lson = p->lson, *rson = p->rson, *bro = parent->rson;
	p->lson = parent;
	parent->rson = lson;
}

void right_rotate(node* p) {
	node* parent = p->par;
	if (p == root || parent->lson != p)
		return;
	node* lson = p->lson, *rson = p->rson, *bro = parent->rson;
	p->rson = parent;
	parent->lson = rson;
}

void lift_node(node* p) {
	if (p == root)
		return;
	else if (p->par->lson == p)
		right_rotate(p);
	else if (p->par->rson == p)
		left_rotate(p);
}

void splay(node* p) {
	if (p == root)
		return;
	while (p != root) {
		lift_node(p);
	}
}



int main(int argc, char* argv[]) {
	system("PAUSE");
	return 0;
}

#endif
