/*
DOCUMENT CODE "20180317-luogu1226.cpp"
CREATION DATE 2018-03-17
SIGNATURE CODE_20180317_LUOGU1226
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20180317_LUOGU1226

#include <cstdlib>
#include <iostream>
using namespace std;

// b ^ p % k
long long qm(long long b, long long p, long long k) {
	long long result = 1, step = b%k;
	while (p != 0) {
		if (p % 2 == 1) {
			result *= step;
			result %= k;
		}
		p /= 2;
		step *= step;
		step %= k;
	}
	return result;
}

int main(int argc, char* argv[]) {
	long long b, p, k;
	cin >> b >> p >> k;
	printf("%lld^%lld mod %lld=%lld\n", b, p, k, qm(b, p, k));
	return 0;
}

#endif

