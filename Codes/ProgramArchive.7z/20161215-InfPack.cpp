/*
DOCUMENT CODE "InfPack.cpp"
CREATION DATE 2016-12-15
SIGNATURE CODE_20161215_INFPACK
TOPIC �������ޱ���
MODIFY DATES 2016-12-15
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161215_INFPACK

#include <cstdlib>
#include <iostream>

using namespace std;

int n, m;
int v[1001], w[1001];
int sv[1001];

#define max(a,b) ((a)>(b)?(a):(b))

int dfs(int cv) {
	if (sv[cv] >= 0)
		return sv[cv];
	else {
		int Max = 0;
		for (int i = 1; i <= n; i++) {
			if (cv + v[i] <= m) {
				Max = max(Max, dfs(cv + v[i]) + w[i]);
			}
		}
		return sv[cv] = Max;
	}
}

int main(int argc, char* argv[]) {
	cin >> n >> m;
	for (int i = 1; i <= n; i++) {
		cin >> v[i];
	}
	for (int i = 1; i <= n; i++) {
		cin >> w[i];
	}
	memset(sv, -1, sizeof(sv));
	cout << dfs(0) << endl;
	system("PAUSE");
	return 0;
}

#endif
