/*
DOCUMENT CODE "poj1011.cpp"
CREATION DATE 2016-12-17
SIGNATURE CODE_20161217_POJ1011
TOPIC poj1011 Sticks ľ��
MODIFY DATES 2016-12-17
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161217_POJ1011

#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <algorithm>
#include <iostream>
#include <queue>
#include <map>
#include <set>
#include <vector>
using namespace std;

bool vis[65];
int tm[65];
int x;
int flag;
int n;
void dfs(int deep, int len, int num)
{
	int i;
	if (flag) return;
	if (len == 0)
	{
		i = 1;
		while (vis[i])  i++;
		vis[i] = true;
		dfs(deep + 1, len + tm[i], i + 1); 
		vis[i] = false;
		return;
	}
	if (len == x)
	{

		if (deep == n)
			flag = 1;
		else
			dfs(deep, 0, 0);
		return;
	}

	for (i = num; i <= n; i++)
	{
		if (!vis[i] && len + tm[i] <= x)
		{
			if (!vis[i - 1] && tm[i] == tm[i - 1])  continue;
			vis[i] = true;
			dfs(deep + 1, len + tm[i], i + 1);
			vis[i] = false;
			if (tm[i] + len == x)  return;
			if (flag) return;
		}
	}
	if (flag) return;
}

bool cmp(int a, int b)
{
	return a>b;
}
int main()
{
	while (cin >> n&&n)
	{

		int sum = 0;
		int i;
		for (i = 1; i <= n; i++)
		{
			scanf("%d", &tm[i]);
			sum += tm[i];
		}
		sort(tm + 1, tm + 1 + n, cmp);

		for (i = tm[1]; i <= sum; i++)
		{
			if (sum%i) continue;
			flag = 0;
			memset(vis, 0, sizeof(vis));
			x = i;
			dfs(0, 0, 1);
			if (flag)
			{
				printf("%d\n", i); break;
			}
		}

	}
	return 0;
}

#endif
