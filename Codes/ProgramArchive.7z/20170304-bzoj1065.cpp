/*
 DOCUMENT CODE "bzoj1065.cpp"
 CREATION DATE 2017-03-04
 SIGNATURE CODE_20170304_BZOJ1065
 TOPIC [NOI2008]��������
 */

#include "Overall.hpp"

#ifdef CODE_20170304_BZOJ1065

#include <cstdlib>
#include <iostream>
#include <queue>
using namespace std;

struct node {
	int v, len;
	node* next;
};

const int infinity = 1000000;

node pool[100001], *h[10001];
int top;

int n, m;
int dis[10001], s[10001];
bool flag[10001];
queue<int> Q;

void addedge(int u, int v, int len) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->len = len;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[++top];
	tmp->v = u;
	tmp->len = len;
	tmp->next = h[v];
	h[v] = tmp;
}

void spfa() {
	for (int i = 1; i <= n; i++) {
		dis[i] = -infinity;
	}
	flag[1] = true;
	s[1]++;
	dis[1] = 0;
	Q.push(1);
	while (!Q.empty()) {
		int u = Q.top(), v, len;
		Q.pop();
		for (node* p = h[u]; p != NULL; p = p->next) {

		}
	}
}

int main(int argc, char* argv[]) {
	cin >> n >> m;
	int u, v, len;
	for (int i = 1; i <= m; i++) {
		cin >> u >> v >> len;
		addedge(u, v, len);
	}

	system("PAUSE");
	return 0;
}

#endif
