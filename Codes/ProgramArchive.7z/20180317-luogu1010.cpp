/*
DOCUMENT CODE "20180317-luogu1010.cpp"
CREATION DATE 2018-03-17
SIGNATURE CODE_20180317_LUOGU1010
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20180317_LUOGU1010

#include <cstdlib>
#include <iostream>
#include <string>
#include <stack>
using namespace std;

string arr[15] = {
	"0",
	"2(0)",
	"2",
	"(2+2(0))",
	"2(2)",
	"(2(2)+2(0))",
	"(2(2)+2)",
	"(2(2)+2+2(0))",
	"(2(3))",
	"(2(3)+2(0))",
	"(2(3)+2)",
	"(2(3)+2+2(0))",
	"(2(3)+2(2))",
	"(2(3)+2(2)+2(0))",
	"(2(3)+2(2)+2)"
};

const string makeString(int x) {
	if (x <= 14)
		return arr[x];

	stack<int> exp;
	string result;
	for (int i = 1; x != 0; i *= 2, x /= 2) {
		if (x % 2 == 1)
			exp.push(i);
	}
	bool first = true;
	result.clear();
	while (!exp.empty()) {
		if (first)
			first = false;
		else {
			result += '+';
			result += makeString(exp.top());
		}
		exp.pop();
	}
	return result;
}

int main(int argc, char* argv[]) {
	int x;
	cin >> x;
	cout << makeString(x) << endl;
	return 0;
}

#endif

