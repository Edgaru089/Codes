/*
 DOCUMENT CODE "bzoj1088.cpp"
 CREATION DATE 2017-02-27
 SIGNATURE CODE_20170227_BZOJ1088
 TOPIC [SCOI2005]ɨ��Mine
 */

#include "Overall.hpp"

#ifdef CODE_20170227_BZOJ1088

#include <cstdlib>
#include <iostream>
using namespace std;

struct node {

};

int main(int argc, char* argv[]) {
	system("PAUSE");
	return 0;
}

#endif
