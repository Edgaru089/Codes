/*
 DOCUMENT CODE "zsy1.cpp"
 CREATION DATE 2017-03-02
 SIGNATURE CODE_20170302_ZSY1
 TOPIC ���ܶٻ�· ����n(n<=20)���㣬m(m<=600)���ߣ���һ����Ĺ��ܶٻ�·����
 DATA 1:
  4
  0 2 1 2
  2 0 3 1
  1 3 0 1
  2 1 1 0
 OUTPUT:
  8
 DATA 2:
  6
  0 8 5 7 1 4
  8 0 1 3 2 5
  5 1 0 9 6 3
  7 3 9 0 8 1
  1 2 6 8 0 7
  4 5 3 1 7 0
 OUTPUT:
  42
 */

#include "Overall.hpp"

#ifdef CODE_20170302_ZSY1

#include <cstdlib>
#include <iostream>
using namespace std;

#define specDigit(a)     (1<<((a)-1))
#define getDigit(a,b)    (((a)&(specDigit(b)))!=0)
#define setDigit(a,b)    ((a)|=(specDigit(b)))
#define clearDigit(a,b)  ((a)&=(fullDigit(20)-specDigit(b)))
#define fullDigit(a)     ((1<<(a))-1)

struct node {
	int v, len;
	node* next;
};

const int infinity = 1000000;

node pool[1001], *h[101];
int top;

int n;
int s[21][1050000];
int rootPathLength[21];

void addedge(int u, int v, int len, bool isDual = false) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->len = len;
	tmp->next = h[u];
	h[u] = tmp;
	if (isDual) {
		tmp = &pool[++top];
		tmp->v = u;
		tmp->len = len;
		tmp->next = h[v];
		h[v] = tmp;
	}
}

int dfs(int u, int vis) {
	setDigit(vis, u);
	if (vis == fullDigit(n) && rootPathLength[u] != 0)
		return s[u][vis] = rootPathLength[u];
	if (s[u][vis] >= 0) {
		return s[u][vis];
	}
	int Max = -infinity;
	for (node* p = h[u]; p != NULL; p = p->next) {
		int v = p->v, len = p->len;
		if (!getDigit(vis, v))
			Max = max(Max, dfs(v, vis) + len);
	}
	return s[u][vis] = Max;
}

int main(int argc, char* argv[]) {
	cin >> n;
	int len;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++) {
			cin >> len;
			if (len != 0) {
				addedge(i, j, len);
				if (i == 1 || j == 1)
					rootPathLength[(i != 1 ? i : j)] = len;
			}
		}
	for (int i = 1; i <= n; i++)
		for (int j = 0; j <= fullDigit(n); j++)
			s[i][j] = -infinity;
	cout << dfs(1, 0) << endl;
	system("PAUSE");
	return 0;
}

#endif
