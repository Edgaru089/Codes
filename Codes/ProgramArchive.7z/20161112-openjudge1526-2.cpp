/*
DOCUMENT CODE "openjudge1526-2.cpp"
CREATION DATE 2016-11-12
SIGNATURE CODE_20161108_OPENJUDGE1526_2
TOPIC ch0403 �ڽ����� ����ڶ���
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161108_OPENJUDGE1526_2

#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;

int t[50005], n, m, x, y, s = 1, a, i, u, v;

int f(int x) {
	if (t[x] == -1)
		return x;
	else
		return t[x] = f(t[x]);
}

int main() {
	while (1) {
		cin >> n >> m;
		if (!n && !m)
			break;
		memset(t, -1, sizeof(t));
		a = n;
		while (m--) {
			cin >> x >> y;
			u = f(x);
			v = f(y);
			if (u != v) {
				t[v] = u;
				a--;
			}
		}
		printf("Case %d: %d\n", s++, a);
	}
}

#endif
