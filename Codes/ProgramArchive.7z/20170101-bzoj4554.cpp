/*
DOCUMENT CODE "bzoj4554.cpp"
CREATION DATE 2017-01-01
SIGNATURE CODE_20170101_BZOJ4554
TOPIC BZOJ4554: [Tjoi2016&Heoi2016]��Ϸ
MODIFY DATES 2017-01-01
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170101_BZOJ4554

#include <cstdio>
#include<cctype>
#include<queue>
#include<cstring>
#include<algorithm>
#define rep(i,s,t) for(int i=s;i<=t;i++)
#define dwn(i,s,t) for(int i=s;i>=t;i--)
#define ren for(int i=first[x];i!=-1;i=next[i])
using namespace std;
const int maxn = 3010;
const int maxm = 50010;
const int inf = 1e9;
struct ISAP {
	struct tedge { int x, y, w, next; }adj[maxm]; int ms, fch[maxn];
	int d[maxn], s[maxn], cur[maxn], gap[maxn], n, top;
	void init() {
		ms = 0; top = 0;
		memset(d, -1, sizeof(d));
		memset(fch, -1, sizeof(fch));
	}
	void AddEdge(int u, int v, int w) {
		adj[ms] = (tedge) { u, v, w, fch[u] }; fch[u] = ms++;
		adj[ms] = (tedge) { v, u, 0, fch[v] }; fch[v] = ms++;
	}
	void bfs() {
		queue<int>Q; Q.push(n); d[n] = 0;
		while (!Q.empty()) {
			int u = Q.front(); Q.pop();
			for (int i = fch[u]; i != -1; i = adj[i].next) {
				int v = adj[i].y;
				if (d[v] == -1) d[v] = d[u] + 1, Q.push(v);
			}
		}
	}
	int solve(int S, int T) {
		n = T; bfs(); int k = S, i, flow = 0;
		for (i = 0; i <= n; i++) cur[i] = fch[i], gap[d[i]]++;
		while (d[S]<n) {
			if (k == n) {
				int mi = inf, pos;
				for (i = 0; i<top; i++) if (adj[s[i]].w<mi) mi = adj[s[i]].w, pos = i;
				for (i = 0; i<top; i++) adj[s[i]].w -= mi, adj[s[i] ^ 1].w += mi;
				flow += mi; top = pos; k = adj[s[top]].x;
			}
			for (i = cur[k]; i != -1; i = adj[i].next) {
				int v = adj[i].y;
				if (adj[i].w&&d[k] == d[v] + 1) { cur[k] = i; k = v; s[top++] = i; break; }
			}
			if (i == -1) {
				int lim = n;
				for (i = fch[k]; i != -1; i = adj[i].next) {
					int v = adj[i].y;
					if (adj[i].w&&d[v]<lim) lim = d[v], cur[k] = i;
				} if (--gap[d[k]] == 0) break;
				d[k] = lim + 1; gap[d[k]]++;
				if (k != S) k = adj[s[--top]].x;
			}
		} return flow;
	}
}sol;
char Map[55][55];
int n, m, S, T, A[55][55], B[55][55];
int main() {
	scanf("%d%d", &n, &m);
	rep(i, 1, n) scanf("%s", Map[i] + 1); sol.init();
	rep(i, 1, n) {
		S++;
		rep(j, 1, m) {
			if (Map[i][j] == '#') S++;
			A[i][j] = S;
		}
	}
	rep(j, 1, m) {
		S++;
		rep(i, 1, n) {
			if (Map[i][j] == '#') S++;
			B[i][j] = S;
		}
	}
	S++; T = S + 1; sol.n = T;
	rep(i, 1, A[n][m]) sol.AddEdge(S, i, 1);
	rep(i, A[n][m] + 1, B[n][m]) sol.AddEdge(i, T, 1);
	rep(i, 1, n) rep(j, 1, m) if (Map[i][j] == '*') sol.AddEdge(A[i][j], B[i][j], 1);
	printf("%d\n", sol.solve(S, T));
	system("PAUSE");
	return 0;
}

#endif
