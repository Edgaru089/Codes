/*
DOCUMENT CODE "poj3461.cpp"
CREATION DATE 2017-04-27
SIGNATURE CODE_20170427_POJ3461
TOPIC Poj3461 Oulipo
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170427_POJ3461

#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
using namespace std;

const int maxm = 1000005, maxn = 10005;

char str[maxm + maxn], pat[maxn];
int len, len1, len2;

int kmp()
{
	int fail[maxn];
	int i, j, k;
	memset(fail, -1, sizeof(fail));
	for (i = 1; i < len2; ++i)
	{
		for (k = fail[i - 1]; k >= 0 && pat[i] != pat[k + 1]; k = fail[k])
			;
		if (pat[k + 1] == pat[i])
			fail[i] = k + 1;
	}
	i = j = 0;
	int ans = 0;
	while (i < len)
	{
		if (pat[j] == str[i])
			++i, ++j;
		else if (j == 0)
			++i;
		else
		{
			if (j == len2)
				ans++;
			j = fail[j - 1] + 1;
		}
	}
	if (j == len2)
		ans++;
	return ans;
}

int main()
{
	int t;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%s", pat);
		scanf("%s", str);
		len1 = strlen(str);
		len2 = strlen(pat);
		len = len1;
		printf("%d\n", kmp());
	}
	return 0;
}

#endif
