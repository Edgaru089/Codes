/*
DOCUMENT CODE "poj2976.cpp"
CREATION DATE 2017-03-21
SIGNATURE CODE_20170321_POJ2976
TOPIC Poj2976 Dropping tests ZSY20170316T1
*/

#include "Overall.hpp"

#ifdef CODE_20170321_POJ2976

#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

struct node {
	double a, b, x;
};

node in[1005];

bool cmp(node p, node t) {
	return p.x > t.x;
}

int main() {
	int n, k, i;
	double l, r, sum, mid;
	int time;
	while (scanf("%d%d", &n, &k) != EOF) {
		if (n == 0 && k == 0)
			break;
		time = 17;
		for (i = 0; i < n; i++)
			scanf("%lf", &in[i].a);
		for (i = 0; i < n; i++)
			scanf("%lf", &in[i].b);
		l = 0; r = 100;
		while (time--) {
			sum = 0;
			mid = (l + r) / 2;
			for (i = 0; i < n; i++)
				in[i].x = 100 * in[i].a - mid*in[i].b;
			sort(in, in + n, cmp);
			for (i = 0; i < n - k; i++)
				sum += (100 * in[i].a - mid*in[i].b);
			if (sum > 0)
				l = mid;
			else
				r = mid;
		}
		printf("%.0lf\n", mid);
	}
	return 0;
}

#endif
