/*
DOCUMENT CODE "noip2000t4.cpp"
CREATION DATE 2017-01-24
SIGNATURE CODE_20170124_NOIP2000T4
TOPIC ����ȡ��
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170124_NOIP2000T4

#include <cstdio>
#include <iostream>

using namespace std;

int a[51][51];
int sum[51][51][51][51];
int n, i, j, h, k, x, y, z;

int main()
{
	cin >> n >> x >> y >> z;
	while (x&&y&&z)
	{
		a[x][y] = z;
		cin >> x >> y >> z;
	}
	for (i = 1; i <= n; i++)
		for (j = 1; j <= n; j++)
			for (h = 1; h <= n; h++)
				for (k = 1; k <= n; k++)
				{
					int p1 = max(sum[i - 1][j][h - 1][k], sum[i][j - 1][h][k - 1]);
					int p2 = max(sum[i - 1][j][h][k - 1], sum[i][j - 1][h - 1][k]);
					sum[i][j][h][k] = max(p1, p2) + a[i][j];
					if (i != h&&j != k) sum[i][j][h][k] += a[h][k];
				}
	printf("%d\n", sum[n][n][n][n]);
	system("PAUSE");
	return 0;
}

#endif
