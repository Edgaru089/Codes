/*
DOCUMENT CODE "ExtendEuclid2.cpp"
CREATION DATE 2016-11-13
SIGNATURE CODE_20161113_EXTENDEUCLID2
TOPIC ��չŷ�������ͬ�෽��
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161113_EXTENDEUCLID2

#include <cstdlib>
#include <iostream>

using namespace std;

int gcd(int a, int b) {
	if (a == 1 || b == 1)
		return b;
	else
		return gcd(b, a%b);
}

int x, y, t;
void extend_euclid(int a, int b)
{
	if (b == 0) {
		x = 1;
		y = 0;
	}
	else {
		extend_euclid(b, a%b);
		t = x;
		x = y;
		y = t - (a / b)*y;

	}
}

int main(int argc, char* argv[]) {
	int a, b;
	cin >> a >> b;
	extend_euclid(a, b);
	cout << y << " " << x << endl;
	system("PAUSE");
	return 0;
}

#endif
