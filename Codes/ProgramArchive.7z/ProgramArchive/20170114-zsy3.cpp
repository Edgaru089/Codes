/*
DOCUMENT CODE "zsy3.cpp"
CREATION DATE 2017-01-14
SIGNATURE CODE_20170114_ZSY3
TOPIC ����һ�����У�ÿ��ѯ������ֻɾ��һ����ʱʣ���������Լ��
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170114_ZSY3

#include <cstdlib>
#include <iostream>

using namespace std;

int n, a[100001], k;
int prefix[100001], suffix[100001];

int gcd(int m, int n) {
	if (n == 0)
		return m;
	else
		return gcd(n, m%n);
}

int main(int argc, char* argv[]) {
	cin >> n;
	prefix[1] = suffix[n + 1] = 1;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		prefix[i] = gcd(prefix[i - 1], a[i]);
	}
	for (int i = n; i >= 1; i--) {
		suffix[i] = gcd(suffix[i + 1], a[i]);
	}
	cin >> k;
	cout << gcd(prefix[k - 1], suffix[k + 1]) << endl;
	system("PAUSE");
	return 0;
}

#endif
