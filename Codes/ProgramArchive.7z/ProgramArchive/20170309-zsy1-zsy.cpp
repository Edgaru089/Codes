/*
DOCUMENT CODE "zsy1-zsy.cpp"
CREATION DATE 2017-03-09
SIGNATURE CODE_20170309_ZSY1_ZSY
TOPIC ��һ����ά����ϵ����n(n<=1000)���㣬���<=10^9����q(q<=10^5)��ѯ�ʣ�ÿ��ѯ��һ�����η�Χ���ж��ٸ���
      zsy�汾
*/

#include "Overall.hpp"

#ifdef CODE_20170309_ZSY1_ZSY

#include <stdio.h>
#include <algorithm>
using namespace std;
struct Point
{
	int x, y, nx, ny, id;
};
int n, q, dx[1001], dy[1001], sum[1001][1001];
Point pt[1000];
bool CmpX(Point a, Point b)
{
	return a.x < b.x;
}
bool CmpY(Point a, Point b)
{
	return a.y < b.y;
}
int main()
{
	scanf("%d", &n);
	for(int i = 1; i <= n; i++)
		dx[i] = dy[i] = 2147483647;
	for(int i = 0; i < n; i++)
	{
		scanf("%d%d", &pt[i].x, &pt[i].y);
		pt[i].id = i;
	}
	sort(pt, pt + n, CmpX);
	for(int i = 0, j = 0; i < n; i++)
	{
		if(!i || pt[i].x != pt[i - 1].x)
			dx[++j] = pt[i].x;
		pt[i].nx = j;
	}
	sort(pt, pt + n, CmpY);
	for(int i = 0, j = 0; i < n; i++)
	{
		if(!i || pt[i].y != pt[i - 1].y)
			dy[++j] = pt[i].y;
		pt[i].ny = j;
	}
	/*
	for(int i = 1; i <= n; i++)
		printf("%d ", dx[i]);
	printf("\n");
	for(int i = 1; i <= n; i++)
		printf("%d ", dy[i]);
	printf("\n");
	for(int i = 0; i < n; i++)
		printf("%d %d: %d %d\n", pt[i].x, pt[i].y, pt[i].nx, pt[i].ny);
	*/
	for(int i = 0; i < n; i++)
		sum[pt[i].nx][pt[i].ny]++;
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
			sum[i][j] += sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1];
	}
	scanf("%d", &q);
	for(int i = 0, ax, ay, bx, by; i < q; i++)
	{
		scanf("%d%d%d%d", &ax, &ay, &bx, &by);
		ax = lower_bound(dx, dx + n, ax) - dx - 1;
		ay = lower_bound(dy, dy + n, ay) - dy - 1;
		bx = upper_bound(dx, dx + n, bx) - dx - 1;
		by = upper_bound(dy, dy + n, by) - dy - 1;
		printf("%d\n", sum[bx][by] - sum[ax][by] - sum[bx][ay] + sum[ax][ay]);
	}
	system("pause");
	return 0;
}

#endif
