/*
 DOCUMENT CODE "lydsyTestsSeries2017D1T1.cpp"
 CREATION DATE 2017-03-08
 SIGNATURE CODE_20170308_LYDSYTESTS2017D1T1
 TOPIC BZOJʮ����2017 ��һ�� ��һ��
       Documents\2017-03-08-bzoj2017ʮ����01\problem.doc
 */

#include "Overall.hpp"

#ifdef CODE_20170308_LYDSYTESTS2017D1T1

#include <cstdlib>
#include <iostream>
using namespace std;

struct node {
	int v;
	node* next;
};

node pool[100001], *h[10001];
int top;
int n, root, father[10001];
int copCount, backupCop;
int step = 0;

void addedge(int u, int v) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->next = h[u];
	h[u] = tmp;
}

void dfs(int x) {
	if (h[x] == NULL) {

	}
	else if (h[x]->next == NULL) {
		cout << "M " << x << " " << h[x]->v << endl;
		step++;
		dfs(h[x]->v);
	}
	else if (h[x]->next->next == NULL&&h[h[x]->v] == NULL&&h[h[x]->next->v] == NULL) {
		cout << "M " << x << " " << h[x]->v << endl;
		step++;
		dfs(h[x]->v);
		cout << "M " << x << " " << h[x]->next->v << endl;
		step++;
		dfs(h[x]->next->v);
	}
	else {
		cout << "L " << x << endl;
		step++;
		if (backupCop > 0)
			backupCop--;
		else
			copCount++;
		for (node* p = h[x]; p != NULL; p = p->next) {
			cout << "M " << x << " " << p->v << endl;
			step++;
			dfs(p->v);
		}
		cout << "B " << x << endl;
		backupCop++;
	}
	if (x != root) {
		cout << "M " << x << " " << father[x] << endl;
		step++;
	}
}

int main(int argc, char* argv[]) {
	cin >> n;
	int u, v;
	for (int i = 1; i < n; i++) {
		cin >> u >> v;
		if (u > v)
			swap(u, v);
		addedge(u, v);
		father[v] = u;
	}
	for (int i = 1; i <= n; i++)
		if (father[i] == 0) {
			root = i;
			break;
		}
	cout << "L " << root << endl;
	copCount++;
	dfs(root);
	cout << "cop = " << copCount << ", step = " << step << endl;
	system("PAUSE");
	return 0;
}

#endif
