/*
DOCUMENT CODE "bzoj1924.cpp"
CREATION DATE 2017-01-30
SIGNATURE CODE_20170130_BZOJ1924
TOPIC [Sdoi2010]���������ı���
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170130_BZOJ1924

#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>

#define MAXN 110000

using namespace std;

int n, r, c, ans;

void in(int &x)
{
	char ch = getchar(); x = 0;
	while (!(ch >= '0'&&ch <= '9')) ch = getchar();
	while (ch >= '0'&&ch <= '9')    x = x * 10 + ch - '0', ch = getchar();
}

struct node
{
	int x, y, opt;
}s[MAXN];
struct edge
{
	int to, w;
	edge *next;
};
struct Map1
{
	int top;
	edge e[MAXN * 50];
	edge *prev[MAXN];
	Map1()
	{
		top = 0;
		memset(e, 0, sizeof(e));
		memset(prev, 0, sizeof(prev));
	}
	void insert(int u, int v, int w)
	{
		if (u == v)   return;
		e[++top].to = v; e[top].next = prev[u]; prev[u] = &e[top]; e[top].w = w;
	}
}m1;
struct Map2
{
	int top;
	edge e[MAXN * 10];
	edge *prev[MAXN];
	Map2()
	{
		top = 0;
		memset(e, 0, sizeof(e));
		memset(prev, 0, sizeof(prev));
	}
	void insert(int u, int v, int w)
	{
		if (u == v)   return;
		e[++top].to = v; e[top].next = prev[u]; prev[u] = &e[top]; e[top].w = w;
	}
}m2;

struct Map3 {
	int top;
	edge e[MAXN * 10];

};

int raw[MAXN * 10], pre_raw[MAXN * 10], col[MAXN * 10], pre_col[MAXN * 10];
bool vis[MAXN];
int dis[MAXN], In[MAXN], Out[MAXN], sum[MAXN];
int dfn[MAXN], stack[MAXN], low[MAXN], ind, scc, block[MAXN];

void dfs(int x)
{
	vis[x] = 1; stack[++stack[0]] = x;
	low[x] = dfn[x] = ++ind;
	for (edge *i = m1.prev[x]; i; i = i->next)
		if (block[i->to] == 0)
		{
			if (!vis[i->to])    dfs(i->to);
			low[x] = min(low[x], low[i->to]);
		}
	if (low[x] == dfn[x])
	{
		scc++;
		while (stack[stack[0] + 1] != x)    block[stack[stack[0]--]] = scc;
	}
}

void SPFA()
{
	memset(vis, 0, sizeof(vis));
	queue<int>  que;
	for (int i = 1; i <= scc; i++)
	{
		dis[i] = -1;
		if (In[i] == 0)   que.push(i), vis[i] = 1, dis[i] = 0;
	}
	while (!que.empty())
	{
		int x = que.front(); que.pop();
		for (edge *i = m2.prev[x]; i; i = i->next)
			if (dis[x] + i->w>dis[i->to])
			{
				dis[i->to] = dis[x] + i->w;
				if (!vis[i->to])
				{
					vis[i->to] = 1;
					que.push(i->to);
				}
			}
		vis[x] = 0;
	}
	for (int i = 1; i <= scc; i++)
		if (!Out[i])    dis[i] += sum[i];
	for (int i = 1; i <= scc; i++)    ans = max(ans, dis[i]);
}

int main()
{
	in(n); in(r); in(c);
	for (int i = 1; i <= n; i++)
	{
		in(s[i].x); in(s[i].y); in(s[i].opt);
		raw[i] = pre_raw[s[i].x]; pre_raw[s[i].x] = i;
		col[i] = pre_col[s[i].y]; pre_col[s[i].y] = i;
	}
	for (int i = 1; i <= n; i++)
	{
		if (s[i].opt == 1)
			for (int x = pre_raw[s[i].x]; x; x = raw[x])  m1.insert(i, x, 0);
		else
			if (s[i].opt == 2)
				for (int x = pre_col[s[i].y]; x; x = col[x])  m1.insert(i, x, 0);
			else
				if (s[i].opt == 3)
				{
					for (int x = pre_raw[s[i].x + 1]; x; x = raw[x])
						if (s[x].y >= s[i].y - 1 && s[x].y <= s[i].y + 1) m1.insert(i, x, 0);
					for (int x = pre_raw[s[i].x]; x; x = raw[x])
						if (s[x].y >= s[i].y - 1 && s[x].y <= s[i].y + 1) m1.insert(i, x, 0);
					for (int x = pre_raw[s[i].x - 1]; x; x = raw[x])
						if (s[x].y >= s[i].y - 1 && s[x].y <= s[i].y + 1) m1.insert(i, x, 0);
				}
	}
	for (int i = 1; i <= n; i++)
		if (block[i] == 0)    dfs(i);
	for (int i = 1; i <= n; i++)  sum[block[i]]++;
	for (int j = 1; j <= n; j++)
		for (edge *i = m1.prev[j]; i; i = i->next)
			if (block[i->to] != block[j]) m2.insert(block[j], block[i->to], sum[block[j]]), In[block[i->to]]++, Out[block[j]]++;
	SPFA();
	printf("%d\n", ans);
}

#endif
