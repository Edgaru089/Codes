/*
DOCUMENT CODE "5-noip-t1.cpp"
CREATION DATE 2016-11-12
SIGNATURE CODE_20161112_5_NOIP_T1
TOPIC 10-31noip������ ���롱
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161112_5_NOIP_T1

#include <cstdlib>
#include <iostream>

using namespace std;

int n, a[300001];
int s[50];

int main(int argc, char* argv[]) {
	int sum = 0;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 0; i < 32; i++) {
		for (int j = 1; j <= n; j++)
			if (a[j] & (1 << i))
				s[i]++;
		cout << s[i] << endl;
	}
	for (int i = 0; i < 32; i++) {
		if (s[i] >= 1)
			sum += 1 << i;
	}
	cout << sum << endl;
	system("PAUSE");
	return 0;
}

#endif
