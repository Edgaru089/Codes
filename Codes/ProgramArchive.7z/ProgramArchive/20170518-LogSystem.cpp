/*
DOCUMENT CODE "LogSystem.cpp"
CREATION DATE 2017-05-18
SIGNATURE CODE_20170518_LOGSYSTEM
TOPIC Logϵͳ
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170518_LOGSYSTEM

#include <cstdlib>
#include <iostream>
#include <string>
#include <ctime>
#include <cstring>
#include <cstdio>
using namespace std;

class StringPraser {
public:

	static const string toString(bool               data) { char buff[48]; sprintf(buff, "%d", data);   return string(buff); }
	static const string toString(short              data) { char buff[48]; sprintf(buff, "%d", data);   return string(buff); }
	static const string toString(unsigned short     data) { char buff[48]; sprintf(buff, "%d", data);   return string(buff); }
	static const string toString(int                data) { char buff[48]; sprintf(buff, "%d", data);   return string(buff); }
	static const string toString(unsigned int       data) { char buff[48]; sprintf(buff, "%u", data);   return string(buff); }
	static const string toString(long long          data) { char buff[48]; sprintf(buff, "%lld", data); return string(buff); }
	static const string toString(unsigned long long data) { char buff[48]; sprintf(buff, "%llu", data); return string(buff); }
	static const string toString(float              data) { char buff[48]; sprintf(buff, "%f", data);   return string(buff); }
	static const string toString(double             data) { char buff[48]; sprintf(buff, "%lf", data);  return string(buff); }

};

class Log {
public:

	const string logLevelName[3] = { "INFO","WARN"," ERR" };

	enum LogLevel {
		Info,
		Warning,
		Error
	};

	Log(ostream& output) :out(&output) {}
	Log(ostream* output) :out(output) {}

	void log(string content, LogLevel level = Info) {
		time_t curtime = time(NULL);
		char buffer[64];
		strftime(buffer, 63, "[%T", localtime(&curtime));
		string final = string(buffer) + " " + logLevelName[level] + "]: " + content;
		(*out) << final << endl;
	}

	void operator() (string content, LogLevel level = Info) {
		log(content, level);
	}

	void setOutputStream(ostream& output) { out = &output; }
	void setOutputStream(ostream* output) { out = output; }

private:
	ostream* out;
};

Log defaultLog(clog);

class LogMessage {
public:

	LogMessage& operator <<(bool               data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(char               data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(unsigned char      data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(short              data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(unsigned short     data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(int                data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(unsigned int       data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(long long          data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(unsigned long long data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(float              data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(double             data) { buffer += StringPraser::toString(data); return *this; }
	LogMessage& operator <<(const char*        data) { buffer += string(data);                 return *this; }
	LogMessage& operator <<(const std::string& data) { buffer += data;                         return *this; }

	LogMessage& operator <<(Log::LogLevel     level) { this->level = level;                    return *this; }
	LogMessage& operator <<(Log&                log) { flush(log);                             return *this; }

public:

	void setLevel(Log::LogLevel level) { this->level = level; }
	void flush(Log& log) { logout(log); clear(); }
	void logout(Log& log) { log(buffer, level); }
	void clear() { buffer = ""; }

private:
	string buffer;
	Log::LogLevel level;
};

int main(int argc, char* argv[]) {

	LogMessage message;

	message << Log::Info << "[TEST] This is a log message!! " << "WAHAHA!";
	message.flush(defaultLog);
	message << Log::Info << 123 << " " << 456.7899 << "WAHAHA!" << defaultLog;

	return 0;
}

#endif
