/*
DOCUMENT CODE "HeavyLightDecomposition.cpp"
CREATION DATE 2016-12-24
SIGNATURE CODE_20161224_HLDECOMPOSITION
TOPIC �����ʷ�ģ��
MODIFY DATES 2016-12-24
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161224_HLDECOMPOSITION

#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

class SegmentTree {
public:
	struct st {
		int Max;
		int lazy;
		int left, right;
		st* lson, *rson;
	};
	//static st pool[100001];
	//static int top;
	static st* newNode() {
		//return &pool[++top];
		return new st();
	}
	void create(int n, int* data) { /*top = 0;*/ root = _create(n, data, 1, n); }
	st* _create(int n, int* data, int left, int right) {
		st* tmp = newNode();
		tmp->lazy = 0;
		tmp->left = left;
		tmp->right = right;
		if (left == right) {
			tmp->Max = data[left];
			tmp->lson = tmp->rson = NULL;
		}
		else {
			tmp->lson = _create(n, data, left, (left + right) / 2);
			tmp->rson = _create(n, data, (left + right) / 2 + 1, right);
			tmp->Max = max(tmp->lson->Max, tmp->rson->Max);
		}
		return tmp;
	}
	void pushDown(st* p) {
		if (p == NULL)
			return;
		p->Max += p->lazy;
		if (p->lson != NULL)
			p->lson->lazy += p->lazy;
		if (p->rson != NULL)
			p->rson->lazy += p->lazy;
		p->lazy = 0;
	}
	int query(int left, int right) { return _query(left, right, root); }
	int _query(int left, int right, st* p) {
		if (p->left == left&&p->right == right) {
			return p->Max;
		}
		pushDown(p);
		pushDown(p->lson);
		pushDown(p->rson);
		if (p->lson->right >= right)
			return _query(left, right, p->lson);
		else if (p->rson->left <= left)
			return _query(left, right, p->rson);
		else {
			return max(_query(left, p->lson->right, p->lson),
				_query(p->rson->left, right, p->rson));
		}
	}
	void change(int left, int right, int add) { _change(left, right, add, root); }
	void _change(int left, int right, int add, st* p) {
		if (p->left == left&&p->right == right) {
			p->lazy += add;
			return;
		}
		pushDown(p);
		pushDown(p->lson);
		pushDown(p->rson);
		if (p->lson->right >= right)
			_change(left, right, add, p->lson);
		else if (p->rson->left <= left)
			_change(left, right, add, p->rson);
		else {
			_change(left, p->lson->right, add, p->lson);
			_change(p->rson->left, right, add, p->rson);
		}
		p->Max = max(p->lson->Max + p->lson->lazy, p->rson->Max + p->rson->Max);
	}

	int n;
	st* root;
};

struct node {
	int u, v, len;
	node* next;
};

node* h[100001];
node pool[100001];
int top;

int father[100001];
int Size[100001], dep[100001];
int root;
vector<int> chains[100001];
int Hson[100001], chainCount = 1, chainNo[100001], inChainNo[100001], chainHead[100001]/*CHAIN NUMBER CODED*/;
SegmentTree chainsPro[100001];
int n, m;

void addedge(int u, int v, int len) {
	node* tmp = &pool[++top];
	tmp->u = u;
	tmp->v = v;
	tmp->len = len;
	tmp->next = h[u];
	h[u] = tmp;
	father[v] = u;
}

int dfs1(int u, int dep) { //Compute size[], dep[].
	::dep[u] = dep;
	Size[u] = 1;
	for (node* i = h[u]; i != NULL; i = i->next) {
		int v = i->v, len = i->len;
		Size[u] += dfs1(v, dep + 1);
	}
	return Size[u];
}

void dfs2(int u) {  //Actural HLD. Compute Hson.
	int HsonSize = 0;
	for (node* i = h[u]; i != NULL; i = i->next) {
		int v = i->v, len = i->len;
		if (Size[v] > HsonSize) {
			HsonSize = Size[v];
			Hson[u] = v;
		}
	}
	if (HsonSize == 0)
		return;
	if (chains[chainCount].size() == 0)
		chainHead[chainCount] = Hson[u];
	chains[chainCount].push_back(Hson[u]);
	chainNo[Hson[u]] = chainCount;
	inChainNo[Hson[u]] = chains[chainCount].size();
	dfs2(Hson[u]);
	for (node* i = h[u]; i != NULL; i = i->next) {
		int v = i->v, len = i->len;
		if (v != Hson[u]) {
			chainCount++;
			dfs2(v);
		}
	}
}

void dfs3() { //Process CHAINS INTO SEGMENT TREES.
	for (int i = 1; i <= chainCount; i++) {
		chainsPro[i].create(chains[i].size(), chains[i].data());
	}
}

int main(int argc, char* argv[]) {
	int u, v, len;
	cin >> n >> m;
	for (int i = 1; i <= m; i++) {
		cin >> u >> v >> len;
		addedge(u, v, len);
	}
	dfs1(1, 0);
	for (int i = 1; i <= n; i++)
		cout << dep[i] << " " << ::Size[i] << endl;
	cout << "----------------" << endl;
	dfs2(1);
	for (int i = 1; i <= n; i++) {
		cout << chainNo[i] << " " << Hson[i] << endl;
	}
	cout << "----------------" << endl;
	for (int i = 1; i <= chainCount; i++) {
		cout << chainHead[i] << " |";
		for (int j : chains[i]) {
			cout << " " << j;
		}
		cout << endl;
	}
	system("PAUSE");
	return 0;
}

#endif
