/*
 DOCUMENT CODE "zsy1.cpp"
 CREATION DATE 2017-03-09
 SIGNATURE CODE_20170309_ZSY1
 TOPIC ��һ����ά����ϵ����n(n<=1000)���㣬���<=10^9����q(q<=10^5)��ѯ�ʣ�ÿ��ѯ��һ�����η�Χ���ж��ٸ���
 */

#include "Overall.hpp"

#ifdef CODE_20170309_ZSY1

#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;

struct Point {
	int x, y;
	int dx, dy;
};

Point pnt[1001];
int n, q, sum[1001][1001];
int dx[1001], dy[1001];

bool cmpX(Point x, Point y) {
	return x.x < y.x;
}

bool cmpY(Point x, Point y) {
	return x.y < y.y;
}

int main(int argc, char* argv[]) {
	cin >> n;
	for (int i = 1; i <= n; i++)
		dx[i] = dy[i] = INT_MAX;
	for (int i = 1; i <= n; i++)
		cin >> pnt[i].x >> pnt[i].y;
	sort(pnt + 1, pnt + n + 1, cmpX);
	int j = 0;
	for (int i = 1; i <= n; i++) {
		if (i != 1 || pnt[i].x != pnt[i - 1].x)
			dx[++j] = pnt[i].x;
		pnt[i].dx = j;
	}
	sort(pnt + 1, pnt + n + 1, cmpY);
	j = 0;
	for (int i = 1; i <= n; i++) {
		if (i != 1 || pnt[i].y != pnt[i - 1].y)
			dy[++j] = pnt[i].y;
		pnt[i].dy = j;
	}
	for (int i = 1; i <= n; i++)
		cout << dx[i] << " ";
	cout << endl;
	for (int i = 1; i <= n; i++)
		cout << dy[i] << " ";
	cout << endl;
	for (int i = 1; i <= n; i++)
		sum[pnt[i].dx][pnt[i].dy]++;
	for (int i = 2; i <= n; i++)
		for (int j = 2; j <= n; j++)
			sum[i][j] += sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1];
	cin >> q;
	int ax, ay, bx, by;
	for (int i = 1; i <= q; i++) {
		cin >> ax >> ay >> bx >> by;
		ax = lower_bound(dx + 1, dx + n + 1, ax) - dx;
		ay = lower_bound(dy + 1, dy + n + 1, ay) - dy;
		bx = upper_bound(dx + 1, dx + n + 1, bx) - dx;
		by = upper_bound(dx + 1, dx + n + 1, by) - dy;
		cout << sum[bx][by] - sum[ax][by] - sum[bx][ay] + sum[ax][ay];
	}
	system("PAUSE");
	return 0;
}

#endif
