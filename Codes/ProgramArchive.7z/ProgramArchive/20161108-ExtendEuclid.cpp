/*
DOCUMENT CODE "ExtendEuclid.cpp"
CREATION DATE 2016-11-08
SIGNATURE CODE_20161108_EXTENDEUCLID
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161108_EXTENDEUCLID

#include <cstdlib>
#include <iostream>

using namespace std;

int gcd(int a, int b) {
	if (a == 1 || b == 1)
		return b;
	else
		return gcd(b, a%b);
}

int main(int argc, char* argv[]) {
	int a, b;
	cin >> a >> b;
	cout << gcd(a, b) << endl;
	system("PAUSE");
	return 0;
}

#endif
