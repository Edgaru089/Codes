/*
DOCUMENT CODE "noip2016t4.cpp"
CREATION DATE 20170124
SIGNATURE CODE_20170124_NOIP2016T4
TOPIC NOIP2016�ռ�������� ħ���� magic
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170124_NOIP2016T4

#include <cstdio>  
#include <iostream>  
#include <algorithm>  

using namespace std;

int n, m, x, y;
int a[15005], b[15005], c[15005], d[15005], w[15005], h[40005];

int main()
{
	cin >> n >> m;
	/*if (n<11)
	{
		for (int i = 1; i <= m; i++) printf("0 0 0 0\n");
		return 0;
	}*/
	for (int i = 1; i <= m; i++)
	{
		scanf("%d", &h[i]);
		w[h[i]]++;
	}
	for (int i = 1; i <= n / 9; i++)
	{
		x = 1 + 9 * i, y = 0;
		for (int j = 2 + 9 * i; j <= n; j++)
		{
			y += w[j - x] * w[j - x + i + i];
			d[j] += y*w[j - i];
			c[j - i] += y*w[j];
		}
		x = 8 * i + 1, y = 0;
		for (int j = n - 9 * i - 1; j >= 1; j--)
		{
			y += w[j + x] * w[j + x + i];
			a[j] += y*w[j + i + i];
			b[j + i + i] += y*w[j];
		}
	}
	for (int i = 1; i <= m; i++)
		cout << a[h[i]] << ' ' << b[h[i]] << ' ' << c[h[i]] << ' ' << d[h[i]] << endl;
	cout << endl;
	system("PAUSE");
	return 0;
}

#endif
