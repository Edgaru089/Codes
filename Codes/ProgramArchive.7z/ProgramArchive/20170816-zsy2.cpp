/*
DOCUMENT CODE "zsy2.cpp"
CREATION DATE 2017-08-16
SIGNATURE CODE_20170816_ZSY2
TOPIC �� (a/1��ȡ�� + a/2��ȡ�� + ... + a/+����ȡ��)(b/2��ȡ�� + b/4��ȡ�� + ... + b/+����ȡ��)(c/3��ȡ�� + c/6��ȡ�� + ... + c/+����ȡ��)
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170816_ZSY2

#include <cstdlib>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

#define max(a,b) ((a)>(b)?(a):(b))

int a, b, c;
long long ans;
vector<int> segments;

int main(int argc, char* argv[]) {
	cin >> a >> b >> c;
	int sqra = sqrt(a), sqrb = sqrt(b), sqrc = sqrt(c);

	// ���ܵĶϵ�
	for (int i = max(sqra, max(sqrb, sqrc)); i >= 1; i--)
		segments.push_back(i);

	// ϡ��Ķϵ�
	for (int i = 1; i <= sqra; i++)
		segments.push_back(a / i);
	for (int i = 1; i <= sqrb; i++)
		segments.push_back(b / i / 2);
	for (int i = 1; i <= sqrc; i++)
		segments.push_back(c / i / 3);

	sort(segments.begin(), segments.end());

	int last = 0;
	for (int i : segments) {
		ans += (long long)(a / i)*(b / i / 2)*(c / i / 3)*(i - last);
		last = i;
	}

	cout << ans << endl;



	return 0;
}

#endif
