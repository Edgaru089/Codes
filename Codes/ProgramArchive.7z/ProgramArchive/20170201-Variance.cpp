/*
DOCUMENT CODE "Variance.cpp"
CREATION DATE 2017-02-01
SIGNATURE CODE_20170201_VARIANCE
TOPIC ����ƽ��������λ��������������
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170201_VARIANCE

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;

const double invaild = -1324585923.0;

double sqr(double a) {
	return a*a;
}

bool isSame(double a, double b) {
	return abs(a - b) < 1e-5;
}

double average(const vector<int>& vec) {  //ƽ����
	double n = vec.size();
	double sum = 0.0;
	for (auto i : vec) {
		sum += i;
	}
	return sum / n;
}

double median(const vector<int>& vec) {    //��λ��
	int n = vec.size();
	vector<int> _vec = vec;
	sort(_vec.begin(), _vec.end());
	if (n % 2 == 0)
		return ((double)_vec[n / 2 - 1] + _vec[n / 2]) / 2.0;
	else
		return _vec[n / 2];
}

double mode(const vector<int>& vec) {       //����
	int count[100001];
	int maxCount = 0, maxPos;
	bool flag = false;
	memset(count, 0, sizeof(count));
	for (auto i : vec) {
		count[i]++;
	}
	for (int i = 0; i <= 100000; i++) {
		if (count[i] > maxCount) {
			maxCount = count[i];
			maxPos = i;
		}
	}
	for (int i = 0; i <= 100000; i++) {
		if (count[i] == maxCount) {
			if (flag)
				return invaild;
			else
				flag = true;
		}
	}
	return maxPos;
}

double variance(const vector<int>& vec) {   //����
	double n = vec.size();
	double sum = 0.0, avg = average(vec);
	for (auto i : vec) {
		sum += sqr(i - avg);
	}
	return sum / n;
}

int main(int argc, char* argv[]) {
	int n, a;
	vector<int> vec;
	cout << "Count: ";
	cin >> n;
	cout << "Data: ";
	for (int i = 1; i <= n; i++) {
		cin >> a;
		vec.push_back(a);
	}
	printf("Average: %.3lf; Median: %.1lf; ", average(vec), median(vec));
	double Mode;
	if (isSame(Mode = mode(vec), invaild))
		printf("Mode: <Invaild>; Variance: %.3lf\n", variance(vec));
	else
		printf("Mode: %.0lf; Variance: %.3lf\n", Mode, variance(vec));
	system("PAUSE");
	return 0;
}

#endif
