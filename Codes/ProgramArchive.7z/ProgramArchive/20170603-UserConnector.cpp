/*
DOCUMENT CODE "UserConnector.cpp"
CREATION DATE 2017-06-03
SIGNATURE CODE_20170603_USERCONNECTOR
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170603_USERCONNECTOR

#include <cstdlib>
#include <iostream>
#include <thread>
#include <SFML/Network.hpp>
using namespace std;
using namespace sf;

void socketReceivingLoop(TcpSocket* socket) {
	Packet pack;
	string cache;
	bool isDone;
	Socket::Status status;
	while ((status = socket->receive(pack)) != Socket::Disconnected&&status != Socket::Error) {
		cout << "Server: ";
		pack >> cache;
		if (cache == "SESSIONPASS") {
			pack >> isDone;
			cout << " " << isDone ? "TRUE" : "FALSE";
		}
		while (pack >> cache)
			cout << " " << cache;
		cout << "\n > ";
	}
}

int main(int argc, char* argv[]) {
	TcpSocket mainSocket;
	string input;
	char ch;
	IpAddress target;
	Uint16 port;
	Packet pack;
	cout << "Target Address: ";
	cin >> input;
	target = IpAddress(input);
	cout << "Port: ";
	cin >> port;
	cout << "Connecting..." << endl;

	Socket::Status status = mainSocket.connect(target, port, seconds(10));
	if (status == Socket::Disconnected || status == Socket::Error) {
		cout << "Networking Error: Target unreachable" << endl << "Press any key to exit...";

		return 0;
	}

	cout << "\n > ";
	thread loop(socketReceivingLoop, &mainSocket);

	do {
		pack.clear();
		input = "";
		do {
			ch = getchar();
			if (ch != '\n'&&ch != '\r') {
				if (ch == ' '&&input != "") {
					pack << input;
					input = "";
				}
				else
					input += ch;
			}
		} while (ch != '\n'&&ch != '\r');

	} while ((status = mainSocket.send(pack)) != Socket::Disconnected&&status != Socket::Error);


	return 0;
}

#endif
