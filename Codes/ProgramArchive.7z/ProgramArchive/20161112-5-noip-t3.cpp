/*
DOCUMENT CODE "5-noip-t3.cpp"
CREATION DATE 2016-11-12
SIGNATURE CODE_20161112_5_NOIP_T3
TOPIC 10-31noip������ �ж����ж���
TODO: δ��ɵĴ���
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.

#ifdef CODE_20161112_5_NOIP_T3

#include <cstdlib>
#include <iostream>
#include <queue>

using namespace std;

struct node {
	int v, len;
	node* next;
};

int n, m, k;
int s, t;
node pool[300001], *h[100001];
int top;

queue<int> Q;
int dis[10001][11];

void addedge(int u, int v, int len) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->len = len;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[++top];
	tmp->v = u;
	tmp->len = len;
	tmp->next = h[v];
	h[v] = tmp;
}

void spfa() {
	int u = Q.front();
	for (node* p = h[u]; p != NULL; p = p->next) {
		int v = p->v, len = p->len;
	}
}

int main(int argc, char* argv[]) {
	int u, v, len;
	cin >> n >> m >> k;
	cin >> s >> t;
	for (int i = 1; i <= n; i++) {
		cin >> u >> v >> len;
		addedge(u, v, len);
	}

	system("PAUSE");
	return 0;
}

#endif
