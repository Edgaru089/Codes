/*
DOCUMENT CODE "GraphBisection.cpp"
CREATION DATE 2017-05-11
SIGNATURE CODE_20170511_GRAPHBISECTION
TOPIC �ж϶���ͼ
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170511_GRAPHBISECTION

#include <cstdlib>
#include <iostream>
using namespace std;

#define UNDEFINED   0
#define BLACK       1
#define WHITE       2

struct node {
	int v, len;
	node* next;
};

int top;
node pool[10001], *h[1001];
int n, m;
int color[1001];

void addedge(int u, int v, int len = 1) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->len = len;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[++top];
	tmp->v = u;
	tmp->len = len;
	tmp->next = h[v];
	h[v] = tmp;
}

bool dfs(int u, int prevColor) {
	color[u] = 3 - prevColor;
	for (node* p = h[u]; p != NULL; p = p->next) {
		int v = p->v;
		if (color[v] == UNDEFINED) {
			if (!dfs(v, color[u]))
				return false;
		}
		else if (color[v] == color[u])
			return false;
		else
			return true;
	}
	return true;
}

int main(int argc, char* argv[]) {
	cin >> n >> m;
	int u, v;
	for (int i = 1; i <= m; i++) {
		cin >> u >> v;
		addedge(u, v);
	}
	color[1] = BLACK;
	if (dfs(1, BLACK))
		cout << "Yes" << endl;
	else
		cout << "No" << endl;
	system("PAUSE");
	return 0;
}

#endif
