/*
DOCUMENT CODE "LargestCompleteSubgraph.cpp"
CREATION DATE 2016-12-15
SIGNATURE CODE_20161215_LCOMPLETESUBGRAPH
TOPIC �����ȫ��ͼ
MODIFY DATES 2016-12-15
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161215_LCOMPLETESUBGRAPH

#include <cstdlib>
#include <iostream>

using namespace std;

struct node {
	int v;
	node* next;
};

node pool[51];
int top;
node* h[51];
bool used[50], connected[50][50];
int n, m, ans;

void addedge(int u, int v) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[++top];
	tmp->v = u;
	tmp->next = h[v];
	h[v] = tmp;
	connected[u][v] = connected[v][u] = true;
}

bool check(int u) {
	for (int i = 1; i <= n; i++) {
		if (used[i] && !connected[u][i])
			return false;
	}
	return true;
}

int dfs(int i) {
	int ans = 0;
	for (int j = i + 1; j <= n; j++) {
		if (!used[j] && check(j)) {
			used[j] = true;
			ans = max(ans, dfs(j) + 1);
			used[j] = false;
		}
	}
	return ans;
}

int main(int argc, char* argv[]) {
	int u, v;
	cin >> n >> m;
	for (int i = 1; i <= m; i++) {
		cin >> u >> v;
		addedge(u, v);
	}
	cout << dfs(0) << endl;
	system("PAUSE");
	return 0;
}

#endif
