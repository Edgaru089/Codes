/*
DOCUMENT CODE "poj1088.cpp"
CREATION DATE 2016-12-01
SIGNATURE CODE_20161201_POJ1088
TOPIC poj1088 ��ѩ ���仯����
MODIFY DATES 2016-12-01
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161201_POJ1088

#include <cstdlib>
#include <iostream>
#include <cstring>

using namespace std;

#define max(a,b) ((a)>(b)?(a):(b))

int n, m;
int map[101][101];
int s[101][101];

int dfs(int x, int y) {
	if (s[x][y] != -1)
		return s[x][y];
	else {
		int Max = 1;
		if (x < n && map[x + 1][y] < map[x][y])
			Max = max(Max, dfs(x + 1, y) + 1);
		if (x > 1 && map[x - 1][y] < map[x][y])
			Max = max(Max, dfs(x - 1, y) + 1);
		if (y < m && map[x][y + 1] < map[x][y])
			Max = max(Max, dfs(x, y + 1) + 1);
		if (y > 1 && map[x][y - 1] < map[x][y])
			Max = max(Max, dfs(x, y - 1) + 1);
		return s[x][y] = Max;
	}
}

int main(int argc, char* argv[]) {
	memset(s, -1, sizeof(s));
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			cin >> map[i][j];
	int Max = 0;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			Max = max(Max, dfs(i, j));
	cout << Max << endl;
	system("PAUSE");
	return 0;
}

#endif
