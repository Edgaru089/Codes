/*
DOCUMENT CODE "Floyd.cpp"
CREATION DATE 2017-02-15
SIGNATURE CODE_20170215_FLOYD
TOPIC Floyd
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170215_FLOYD

#include <cstdlib>
#include <iostream>
using namespace std;

struct node {
	int v, len;
	node* next;
};

const int infinity = 1000000;

node pool[100001], *h[10001];
int top;

int n, m;
int dis[10001][10001];

void addedge(int u, int v, int len) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->len = len;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[++top];
	tmp->v = u;
	tmp->len = len;
	tmp->next = h[v];
	h[v] = tmp;
	dis[u][v] = dis[v][u] = len;
}

void floyd() {
	for (int k = 1; k <= n; k++)
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= n; j++) {
				if (dis[i][j] > dis[i][k] + dis[k][j])
					dis[i][j] = dis[i][k] + dis[k][j];
			}
}

int main(int argc, char* argv[]) {
	cin >> n >> m;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			dis[i][j] = infinity;
		}
		dis[i][i] = 0;
	}
	int u, v, len;
	for (int i = 1; i <= m; i++) {
		cin >> u >> v >> len;
		addedge(u, v, len);
	}
	floyd();
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= i; j++) {
			cout << i << ", " << j << ": " << dis[i][j]<< endl;
		}
	}
	system("PAUSE");
	return 0;
}

#endif
