/*
DOCUMENT CODE "poj2481.cpp"
CREATION DATE 2017-02-09
SIGNATURE CODE_20170209_POJ2481
TOPIC Cows
TODO: δ��ɵĴ���
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170209_POJ2481

#include <cstdlib>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Cow {
	Cow() {}
	Cow(int s, int e, int num) :S(s), E(e), Num(num), ans(0) {}
	int S, E;
	int Num;
	int ans;
};

vector<Cow> vec;
int n;

bool cmp(Cow x, Cow y) {
	if (x.S <= y.S&&x.E >= y.E&&x.E - x.S > y.E - y.S)
		return true;
	else
		return false;
}

int main(int argc, char* argv[]) {
	int s, e;
	int curS=-1, curE=-1,curCount=0,segCount=0;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> s >> e;
		vec.push_back(Cow(s, e, i));
	}
	sort(vec.begin(), vec.end(), cmp);
	for (auto& i : vec) {
		if (i.S != curS || i.E != curE) {
			curCount += segCount;
			
		}
	}
	system("PAUSE");
	return 0;
}

#endif
