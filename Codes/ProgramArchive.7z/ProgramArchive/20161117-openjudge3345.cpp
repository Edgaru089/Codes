/*
DOCUMENT CODE "openjudge3345.cpp"
CREATION DATE 2016-11-17
SIGNATURE CODE_20161117_OPENJUDGE3345
TOPIC priority_queue��ϰ��
MODIFY DATES 2016-11-17
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161117_OPENJUDGE3345

#include <cstdlib>
#include <iostream>
#include <queue>

using namespace std;

struct st {
	int v, count;
};

priority_queue<int> Q;

int n, m;

void summon() {
	int i;
	int vt = 0;
	cin >> vt;
	vt = i;
}

int main(int argc, char* argv[]) {
	system("PAUSE");
	return 0;
}

#endif
