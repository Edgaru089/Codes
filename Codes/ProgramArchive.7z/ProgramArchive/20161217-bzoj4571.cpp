/*
DOCUMENT CODE "bzoj4571.cpp"
CREATION DATE 2016-12-17
SIGNATURE CODE_20161217_BZOJ4571
TOPIC bzoj4571 [Scoi2016]��ζ
MODIFY DATES 2016-12-17
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161217_BZOJ4571

#include<cstdio>
#include<cctype>
#include<queue>
#include<cstring>
#include<algorithm>

#define rep(i,s,t) for(int i=s;i<=t;i++)
#define dwn(i,s,t) for(int i=s;i>=t;i--)
#define ren for(int i=first[x];i;i=next[i])

using namespace std;

const int BufferSize = 1 << 16;
char buffer[BufferSize], *head, *tail;

inline char Getchar() {
	if (head == tail) {
		int l = fread(buffer, 1, BufferSize, stdin);
		tail = (head = buffer) + l;
	}
	return *head++;
}
inline int read() {
	int x = 0, f = 1; char c = Getchar();
	for (; !isdigit(c); c = Getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = Getchar()) x = x * 10 + c - '0';
	return x*f;
}
const int maxn = 200010;
const int maxnode = 5000010;
int ls[maxnode], rs[maxnode], s[maxnode], ToT;
void insert(int& y, int x, int l, int r, int p) {
	s[y = ++ToT] = s[x] + 1; if (l == r) return;
	int mid = l + r >> 1; ls[y] = ls[x]; rs[y] = rs[x];
	if (p <= mid) insert(ls[y], ls[x], l, mid, p);
	else insert(rs[y], rs[x], mid + 1, r, p);
}
int query(int x, int y, int l, int r, int ql, int qr) {
	if (ql>qr) return 0;
	if (ql <= l&&r <= qr) return s[y] - s[x];
	int mid = l + r >> 1;
	if (ql <= mid&&query(ls[x], ls[y], l, mid, ql, qr)) return 1;
	if (qr>mid&&query(rs[x], rs[y], mid + 1, r, ql, qr)) return 1;
}
int n, m, root[maxn], A[maxn];
int main() {
	n = read(); m = read(); rep(i, 1, n) A[i] = read();
	rep(i, 1, n) insert(root[i], root[i - 1], 0, 100000, A[i]);
	while (m--) {
		int b = read(), x = read(), ql = read(), qr = read(), ans = 0, a = 0;
		dwn(i, 17, 0) {
			int c = b >> i & 1;
			if (c&&query(root[ql - 1], root[qr], 0, 100000, max(0, a - x), min(100000, (a ^ (1 << i)) - x - 1))) ans |= 1 << i;
			else if (c) a ^= 1 << i;
			if (!c&&query(root[ql - 1], root[qr], 0, 100000, max(0, (a ^ (1 << i)) - x), min(100000, (a + (1 << i + 1)) - x - 1))) ans |= 1 << i, a ^= 1 << i;
		}
		printf("%d\n", ans);
	}
	return 0;
}

#endif
