/*
DOCUMENT CODE "noi2007day1t1.cpp"
CREATION DATE 2017-02-13
SIGNATURE CODE_20170213_NOI2007DAY1T1
TOPIC �罻���� network
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170213_NOI2007DAY1T1

#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n, m;
double mp[101][101];
double a[101][101];
double ans[101];
int main()
{
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			mp[i][j] = 1e15;
	int x, y; double z;
	for (int i = 1; i <= m; i++)
	{
		scanf("%d%d%lf", &x, &y, &z);
		mp[x][y] = mp[y][x] = z;
		a[x][y] = a[y][x] = 1;
	}
	for (int k = 1; k <= n; k++)
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= n; j++)
			{
				if (mp[i][k] + mp[k][j] < mp[i][j]) { mp[i][j] = mp[i][k] + mp[k][j]; a[i][j] = 0; }
				if (mp[i][k] + mp[k][j] == mp[i][j])a[i][j] += a[i][k] * a[k][j];
			}
	for (int i = 1; i <= n; i++)a[i][i] = 0;
	for (int k = 1; k <= n; k++)
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= n; j++)
			{
				if (mp[i][k] + mp[k][j] == mp[i][j] && a[i][j] > 0)
					ans[k] += a[i][k] * a[k][j] / a[i][j];
			}
	for (int i = 1; i <= n; i++)printf("%.3lf\n", ans[i]);
	system("PAUSE");
	return 0;
}

#endif
