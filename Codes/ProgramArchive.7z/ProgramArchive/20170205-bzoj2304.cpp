/*
DOCUMENT CODE "bzoj2304.cpp"
CREATION DATE 2017-02-05
SIGNATURE CODE_20170205_bzoj2304
TOPIC
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170205_bzoj2304

#include<iostream>
#include<cstdio>
#include<iostream>
#include<cstring>
#include<cstdlib>
#define ll long long
#define llinf 8000000000000000000LL
#define inf 0x7fffffff
#define p(i,j) (i-1)*4+j+2
using namespace std;
inline int read()
{
	char ch = getchar();
	int f = 1, x = 0;
	while (!(ch >= '0'&&ch <= '9')) { if (ch == '-')f = -1; ch = getchar(); }
	while (ch >= '0'&&ch <= '9') { x = x * 10 + (ch - '0'); ch = getchar(); }
	return x*f;
}
int T, n, m, cnt;
int xs, ys, xt, yt;
int head[2000005], q[4000005];
bool inq[4000005];
ll dis[4000005];
struct re { int x1, x2, y1, y2; }r[1005];
struct edge { int to, next, v; }e[10000005];
struct data { int x, y; }p[4000005];
void ins(int u, int v, int w)
{
	e[++cnt].to = v; e[cnt].next = head[u]; head[u] = cnt; e[cnt].v = w;
}
void insert(int u, int v, int w)
{
	ins(u, v, w); ins(v, u, w);
}
int spfa()
{
	int t = 0, w = 1, now;
	for (int i = 1; i <= m; i++)dis[i] = llinf;
	dis[1] = 0; inq[1] = 1; q[0] = 1;
	while (t != w)
	{
		now = q[t]; t++; if (t == 4000005)t = 0;
		for (int i = head[now]; i; i = e[i].next)
			if (e[i].v + dis[now]<dis[e[i].to])
			{
				dis[e[i].to] = dis[now] + e[i].v;
				if (!inq[e[i].to])
				{
					inq[e[i].to] = 1;
					q[w++] = e[i].to;
					if (w == 4000005)w = 0;
				}
			}
		inq[now] = 0;
	}
}
void add(int x, int y) { p[++m].x = x; p[m].y = y; }
void find1(int x, int y, int k)
{
	int mn1 = inf, mn2 = inf;
	int tmp1 = -1, tmp2 = -1;
	for (int i = 1; i <= m; i++)
	{
		if (p[i].y != y || k == i)continue;
		if (p[i].x <= x&&x - p[i].x<mn1) { tmp1 = i; mn1 = x - p[i].x; }
		if (p[i].x >= x&&p[i].x - x<mn2) { tmp2 = i; mn2 = p[i].x - x; }
	}
	if (tmp1 != -1)insert(k, tmp1, mn1); if (tmp2 != -1)insert(k, tmp2, mn2);
}
void find2(int x, int y, int k)
{
	int mn1 = inf, mn2 = inf;
	int tmp1 = -1, tmp2 = -1;
	for (int i = 1; i <= m; i++)
	{
		if (p[i].x != x || k == i)continue;
		if (p[i].y <= y&&y - p[i].y<mn1) { tmp1 = i; mn1 = y - p[i].y; }
		if (p[i].y >= y&&p[i].y - y<mn2) { tmp2 = i; mn2 = p[i].y - y; }
	}
	if (tmp1 != -1)insert(k, tmp1, mn1); if (tmp2 != -1)insert(k, tmp2, mn2);
}
void build1(int x, int y, int mark)
{
	int mn = inf, tmp = -1;
	for (int i = 1; i <= n; i++)
		if (r[i].x1 <= x&&r[i].x2 >= x&&r[i].y1>y&&r[i].y1 - y<mn)
			mn = r[i].y1 - y, tmp = i;
	if (tmp != -1)
	{
		add(x, r[tmp].y1);
		insert(mark, m, mn);
		find1(x, r[tmp].y1, m);
	}
}
void build2(int x, int y, int mark)
{
	int mn = inf, tmp = -1;
	for (int i = 1; i <= n; i++)
		if (r[i].x1 <= x&&r[i].x2 >= x&&r[i].y2<y&&y - r[i].y2<mn)
			mn = y - r[i].y2, tmp = i;
	if (tmp != -1)
	{
		add(x, r[tmp].y2);
		insert(mark, m, mn);
		find1(x, r[tmp].y2, m);
	}
}
void build3(int x, int y, int mark)
{
	int mn = inf, tmp = -1;
	for (int i = 1; i <= n; i++)
		if (r[i].y1 <= y&&r[i].y2 >= y&&r[i].x1>x&&r[i].x1 - x<mn)
			mn = r[i].x1 - x, tmp = i;
	if (tmp != -1)
	{
		add(r[tmp].x1, y);
		insert(mark, m, mn);
		find2(r[tmp].x1, y, m);
	}
}
void build4(int x, int y, int mark)
{
	int mn = inf, tmp = -1;
	for (int i = 1; i <= n; i++)
		if (r[i].y1 <= y&&r[i].y2 >= y&&r[i].x2<x&&x - r[i].x2<mn)
			mn = x - r[i].x2, tmp = i;
	if (tmp != -1)
	{
		add(r[tmp].x2, y);
		insert(mark, m, mn);
		find2(r[tmp].x2, y, m);
	}
}
void build(int x)
{
	insert(p(x, 1), p(x, 2), r[x].x2 - r[x].x1);
	insert(p(x, 1), p(x, 3), r[x].y2 - r[x].y1);
	insert(p(x, 4), p(x, 3), r[x].x2 - r[x].x1);
	insert(p(x, 2), p(x, 4), r[x].y2 - r[x].y1);
	build2(r[x].x1, r[x].y1, p(x, 1)); build4(r[x].x1, r[x].y1, p(x, 1));
	build2(r[x].x2, r[x].y1, p(x, 2)); build3(r[x].x2, r[x].y1, p(x, 2));
	build1(r[x].x1, r[x].y2, p(x, 3)); build4(r[x].x1, r[x].y2, p(x, 3));
	build1(r[x].x2, r[x].y2, p(x, 4)); build3(r[x].x2, r[x].y2, p(x, 4));
}
int main()
{
	T = read();
	while (T--)
	{
		cnt = m = 0;
		memset(head, 0, sizeof(head));
		xs = read(); ys = read(); add(xs, ys);
		xt = read(); yt = read(); add(xt, yt);
		n = read();
		for (int i = 1; i <= n; i++)
		{
			r[i].x1 = read(); r[i].y1 = read();
			r[i].x2 = read(); r[i].y2 = read();
			add(r[i].x1, r[i].y1); add(r[i].x2, r[i].y1);
			add(r[i].x1, r[i].y2); add(r[i].x2, r[i].y2);
		}
		for (int i = 1; i <= n; i++)build(i);
		build1(xs, ys, 1); build2(xs, ys, 1); build3(xs, ys, 1); build4(xs, ys, 1);
		build1(xt, yt, 2); build2(xt, yt, 2); build3(xt, yt, 2); build4(xt, yt, 2);
		find1(xs, ys, 1); find2(xs, ys, 1);
		spfa();
		if (dis[2] != llinf)printf("%lld\n", dis[2]);
		else printf("No Path\n");
	}
	return 0;
}

#endif
