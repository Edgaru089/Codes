/*
DOCUMENT CODE "poj3468.cpp"
CREATION DATE 2017-05-06
SIGNATURE CODE_20170506_POJ3468
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170506_POJ3468

#include <cstdlib>
#include <iostream>
using namespace std;

struct st {
	int left, right;
	st* lson, *rson;
	long long sum, lazy;
};

st pool[200001], *root;
int top;

long long n, a[100001];

void pushDown(st* p) {
	if (p == NULL)
		return;
	if (p->lson != NULL)
		p->lson->lazy += p->lazy;
	if (p->rson != NULL)
		p->rson->lazy += p->lazy;
	p->sum += p->lazy*(p->right - p->left + 1);
	p->lazy = 0;
}

st* buildTree(int left, int right) {
	st* tmp = &pool[++top];
	tmp->left = left;
	tmp->right = right;
	tmp->lazy = 0;
	if (left == right) {
		tmp->sum = a[left];
		tmp->lson = tmp->rson = NULL;
	}
	else {
		int mid = (left + right) / 2;
		tmp->lson = buildTree(left, mid);
		tmp->rson = buildTree(mid + 1, right);
		tmp->sum = tmp->lson->sum + tmp->rson->sum;
	}
	return tmp;
}

void change(int left, int right, int add, st* p = root) {
	if (p->left == left&&p->right == right) {
		p->lazy += add;
		pushDown(p);
		return;
	}
	pushDown(p);
	pushDown(p->lson);
	pushDown(p->rson);
	if (p->lson->right >= right) {
		change(left, right, add, p->lson);
	}
	else if (p->rson->left <= left) {
		change(left, right, add, p->rson);
	}
	else {
		change(left, p->lson->right, add, p->lson);
		change(p->rson->left, right, add, p->rson);
	}
	pushDown(p);
	pushDown(p->lson);
	pushDown(p->rson);
	p->sum = p->lson->sum + p->rson->sum;
}

long long query(int left, int right, st* p = root) {
	if (p->left == left&&p->right == right)
		return p->sum + p->lazy*(p->right - p->left + 1);
	pushDown(p);
	pushDown(p->lson);
	pushDown(p->rson);
	if (p->lson->right >= right)
		return query(left, right, p->lson);
	else if (p->rson->left <= left)
		return query(left, right, p->rson);
	else
		return query(left, p->lson->right, p->lson) + query(p->rson->left, right, p->rson);
}

int main(int argc, char* argv[]) {
	int q, k, m, l;
	char c;
	cin >> n >> q;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	root = buildTree(1, n);
	for (int i = 1; i <= q; i++) {
		cin >> c;
		if (c == 'Q') {
			cin >> k >> m;
			cout << query(k, m) << endl;
		}
		else if (c == 'C') {
			cin >> k >> m >> l;
			change(k, m, l);
		}
	}
	system("PAUSE");
	return 0;
}

#endif
