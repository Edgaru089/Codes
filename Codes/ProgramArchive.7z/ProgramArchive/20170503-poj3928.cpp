/*
DOCUMENT CODE ".cpp"
CREATION DATE 2017-05-03
SIGNATURE CODE_20170503_POJ3928
TOPIC Poj3928 Ping pong
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170503_POJ3928

#include <cstdlib>
#include <iostream>
using namespace std;

int p[100001];
long long vleft[100001], vright[100001];  //Smaller
long long tleft[100001], tright[100001];  //Larger
int a[100001];
int n;

int lowbit(int x) {
	return (x&(-x));
}

int get(int x) {
	int sum = 0;
	while (x > 0) {
		sum += p[x];
		x -= lowbit(x);
	}
	return sum;
}

void add(int x, int y, int Add) {
	while (x < y) {
		p[x] += Add;
		x += lowbit(x);
	}
}

int main(int argc, char* argv[]) {
	int t;
	cin >> t;
	while (t--) {
		int Max = 0;
		long long Ans = 0;
		memset(p, 0, sizeof(p));
		cin >> n;
		for (int i = 1; i <= n; i++) {
			cin >> a[i];
			Max = max(Max, a[i]);
		}
		for (int i = 2; i <= n; i++) {
			add(a[i], Max, 1);
			vleft[i] = get(a[i] - 1);
			tleft[i] = i - 1 - vleft[i];
		}
		memset(a, 0, sizeof(a));
		for (int i = n - 1; i >= 1; i--) {
			add(a[i], Max, 1);
			vright[i] = get(a[i]);
			tright[i] = n - i - vright[i];
		}
		Ans = 0;
		for (int i = 2; i < n; i++) {
			Ans += vleft[i] * tright[i] + tleft[i] * vright[i];
		}
		cout << Ans << endl;
	}
	system("PAUSE");
	return 0;
}

#endif
