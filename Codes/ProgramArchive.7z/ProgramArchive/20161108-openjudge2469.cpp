/*
DOCUMENT CODE "openjudge2469.cpp"
CREATION DATE 2016-11-08
SIGNATURE CODE_20161107_OPENJUDGE2469
TOPIC ch0406 ��ص�����
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161107_OPENJUDGE2469

#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <iomanip>

using namespace std;

int a[10001];
int n;
double sum, top;

int main(int argc, char* argv[]) {
	while (cin >> n) {
		for (int i = 1; i <= n; i++)
			cin >> a[i];
		sort(a + 1, a + n + 1);
		top = a[n];
		sum = 0;
		for (int i = 1; i <= n - 1; i++) {
			sum += a[i];
		}
		if (sum < top)
			printf("%.1lf\n", sum);
		else
			printf("%.1lf\n", (sum + top) / 2.0);
	}
	system("PAUSE");
	return 0;
}

#endif
