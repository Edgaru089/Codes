/*
DOCUMENT CODE "spoj-gss3.cpp"
CREATION DATE 2017-08-07
SIGNATURE CODE_20170807_SPOJ_GSS3
TOPIC	GSS8 - Can you answer these queries VIII
		http://www.spoj.com/problems/GSS8/
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170807_SPOJ_GSS3

#include <cstdlib>
#include <iostream>
using namespace std;

#define max(a,b) ((a)>(b)?(a):(b))

const int maxN = 51000;

struct info {
	int sum, ls, rs, all;
};

struct node {
	int l, r;
	info t;
	node* lson, *rson;
};

node pool[2 * maxN], *t;
int top;

int n, q;
int a[maxN];

void input() {
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	cin >> q;
}

info merge(info x1, info x2) {
	info y;
	y.all = x1.all + x2.all;
	y.ls = max(x1.ls, x1.all + x2.ls);
	y.rs = max(x2.rs, x2.all + x1.rs);
	y.sum = max(max(x1.sum, x2.sum), x1.rs + x2.ls);
	return y;
}

void buildtree(node* id, int l, int r) {
	id->l = l;
	id->r = r;
	if (l == r) {
		id->t.all = a[l];
		if (a[l] > 0) {
			id->t.ls = id->t.rs = id->t.sum = a[l];
		}
		else {
			id->t.ls = id->t.rs = id->t.sum = 0;
		}
	}
	else {
		int mid = (l + r) / 2;
		id->lson = &pool[++top];
		id->rson = &pool[++top];
		buildtree(id->lson, l, mid);
		buildtree(id->rson, mid + 1, r);
		id->t = merge(id->lson->t, id->rson->t);
	}
}

void change(node* id, int l, int x) {
	if (id->l == id->r) {
		id->t.all = x;
		if (x > 0)
			id->t.ls = id->t.rs = id->t.sum = x;
		else
			id->t.ls = id->t.rs = id->t.sum = 0;
	}
	else {
		int mid = (id->l + id->r) / 2;
		if (x <= mid)
			change(id->lson, l, x);
		else
			change(id->rson, l, x);
		id->t = merge(id->lson->t, id->rson->t);
	}
}

info query(node* id, int l, int r) {
	if (id->l == l&&id->r == r)
		return id->t;
	int mid = (id->l + id->r) / 2;
	if (r <= mid)
		return query(id->lson, l, r);
	else if (l > mid)
		return query(id->rson, l, r);
	else
		return merge(query(id->lson, l, mid), query(id->rson, mid + 1, r));
}

void work() {

	t = &pool[++top];
	buildtree(t, 1, n);

	int op, l, r;
	for (int i = 1; i <= q; i++) {
		cin >> op >> l >> r;
		if (op == 1)
			change(t, l, r);
		else
			cout << query(t, l, r).sum << endl;
	}

}

int main(int argc, char* argv[]) {

	input();
	work();


	return 0;
}

#endif
