/*
 DOCUMENT CODE "noi2008day1t1.cpp"
 CREATION DATE 2017-02-16
 SIGNATURE CODE_20170216_NOI2008DAY1T1
 TOPIC ������� party
 */

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170216_NOI2008DAY1T1

#include <cstdio>  
#include <cstdlib>  
#include <algorithm>  
#include <string>  
#include <cstring>  

#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))

const int maxN = 200010, INF = 0x3f3f3f3f;
struct Edge
{
	int v, d; Edge *next; Edge() {}
	Edge(int v, int d, Edge *next) : v(v), d(d), next(next) {}
} *edge[maxN]; bool marked[maxN];
int Belong[maxN], col[maxN], cyc[maxN];
int Ccnt, Pcnt, n, m, ans_min = 3, ans_max;

inline int getint()
{
	int res = 0; char tmp;
	while (!isdigit(tmp = getchar()));
	do res = (res << 3) + (res << 1) + tmp - '0';
	while (isdigit(tmp = getchar()));
	return res;
}

void Dfs(int u, int c)
{
	col[u] = c; marked[u] = 1; Belong[u] = Pcnt;
	for (Edge *p = edge[u]; p; p = p->next)
		if (!marked[p->v]) Dfs(p->v, c + p->d);
		else if (c + p->d - col[p->v])
			cyc[++Ccnt] = std::abs(c + p->d - col[p->v]);
	return;
} //�ҳ���ͨ�������������������������ڣ����л����ڣ���  

inline int gcd(int a, int b)
{
	for (int tmp; b; a = b, b = tmp) tmp = a % b; return a;
}

inline void work1()
{
	ans_max = cyc[1];
	for (int i = 1; i < Ccnt + 1; ++i)
		ans_max = gcd(ans_max, cyc[i]);
	if (ans_max < 3) { ans_min = ans_max = -1; return; }
	for (; ans_min < ans_max + 1; ++ans_min)
	{
		bool flag = 1;
		for (int i = 1; i < Ccnt + 1; ++i)
			if (cyc[i] % ans_min) { flag = 0; break; }
		if (flag) break;
	}
	return;
} //There exists circles.  

inline void work2()
{
	static int min_col[maxN], max_col[maxN];
	memset(min_col, 0x3f, sizeof min_col);
	for (int i = 1; i < n + 1; ++i)
		min_col[Belong[i]] = min(min_col[Belong[i]], col[i]),
		max_col[Belong[i]] = max(max_col[Belong[i]], col[i]);
	for (int i = 1; i < Pcnt + 1; ++i)
		ans_max += max_col[i] - min_col[i] + 1;
	if (ans_max < 3) ans_min = ans_max = -1;
	return;
} //There exists no circle.  

int main()
{
	n = getint(); m = getint();
	while (m--)
	{
		int u = getint(), v = getint();
		edge[u] = new Edge(v, 1, edge[u]);
		edge[v] = new Edge(u, -1, edge[v]);
	}
	for (int i = 1; i < n + 1; ++i)
		if (!marked[i]) ++Pcnt, Dfs(i, 1);
	Ccnt ? work1() : work2();
	printf("%d %d\n", ans_max, ans_min); return 0;
}

#endif
