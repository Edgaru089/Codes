/*
DOCUMENT CODE "TaskScheduler.cpp"
CREATION DATE 2017-07-28
SIGNATURE CODE_20170728_TASKSCHEDULER
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170728_TASKSCHEDULER

#include <cstdlib>
#include <iostream>

#include <thread>
#include <mutex>
#include <map>
#include <utility>
#include <SFML/System.hpp>

using namespace std;
using namespace sf;

#define AUTOLOCK(a) lock_guard<mutex> lock(a)

static mutex taskIdTopLock;
static int taskIdTop;

class TaskScheduler {
public:

	TaskScheduler() {}
	~TaskScheduler() {}

	int callAfter(Time duration, function<void()> function) {
		int id = _newTaskId();
		isReady[id] = true;

		thread waiting(&TaskScheduler::_runWaitingThread1, this, duration, function, id);
		waiting.detach();

		return id;
	}

	template<class... Args>
	int callAfter(Time duration, function<void(Args...)> function, Args... args) {
		int id = _newTaskId();
		isReady[id] = true;

		thread waiting(&TaskScheduler::_runWaitingThread2, this, duration, function, id, args...);
		waiting.detach();

		return id;
	}

	template<class Owner>
	int callAfter(Time duration, function<void(Owner*)> function, Owner* owner) {
		int id = _newTaskId();
		isReady[id] = true;

		thread waiting(&TaskScheduler::_runWaitingThread3<Owner>, this, duration, function, owner, id);
		waiting.detach();

		return id;
	}

	int callEvery(Time cycleDuration, function<void()> function) {
		int id = _newTaskId();
		isReady[id] = true;

		thread cycle(&TaskScheduler::_runCycleThread1, this, cycleDuration, function, id);
		cycle.detach();

		return id;
	}

	template<class... Args>
	int callEvery(Time cycleDuration, function<void(Args...)> function, Args... args) {
		int id = _newTaskId();
		isReady[id] = true;

		thread cycle(&TaskScheduler::_runCycleThread2, this, cycleDuration, function, id, args...);
		cycle.detach();

		return id;
	}

	template <class Owner>
	int callEvery(Time cycleDuration, function<void(Owner*)> function, Owner* owner) {
		int id = _newTaskId();
		isReady[id] = true;

		thread cycle(&TaskScheduler::_runCycleThread3<Owner>, this, cycleDuration, function, owner, id);
		cycle.detach();

		return id;
	}

	//True:  exists (in progress)
	//False: doesn't exist or already executed
	bool isTaskVaild(int taskId) {
		map<int, bool>::const_iterator it = isReady.find(taskId);
		if (it != isReady.end()) {
			if (it->second)           //isReady[taskId] == true
				return true;
			else
				return false;
		}
		else
			return false;
	}

	//True:  exists, canceled
	//False: doesn't exist or already executed
	bool cancelTask(int taskId) {
		AUTOLOCK(isReadyLock);
		map<int, bool>::iterator it = isReady.find(taskId);
		if (it != isReady.end()) {
			it->second = false;
			return true;
		}
		else
			return false;
	}

private:

	int _newTaskId() {
		AUTOLOCK(taskIdTopLock);
		return ++taskIdTop;
	}

	void _deleteTaskId(int taskId) {
		AUTOLOCK(isReadyLock);
		isReady.erase(taskId);
	}

	void _runWaitingThread1(Time duration, function<void()> function, int taskId) {
		sleep(duration);
		if (isReady[taskId])
			function();
		_deleteTaskId(taskId);
	}

	template<class... Args>
	void _runWaitingThread2(Time duration, function<void(Args...)> function, int taskId, Args... args) {
		sleep(duration);
		if (isReady[taskId])
			function(args...);
		_deleteTaskId(taskId);
	}

	template <class Owner>
	void _runWaitingThread3(Time duration, function<void(Owner*)> function, Owner* owner, int taskId) {
		sleep(duration);
		if (isReady[taskId])
			function(owner);
		_deleteTaskId(taskId);
	}

	void _runCycleThread1(Time cycleDuration, function<void()> function, int taskId) {
		Clock cycleRuntimeClock;
		Time cycleRuntime;
		sleep(cycleDuration);
		while (true) {
			cycleRuntimeClock.restart();
			if (!isReady[taskId])
				break;
			else
				function();
			cycleRuntime = cycleRuntimeClock.restart();
			if (cycleRuntime < cycleDuration)
				sleep(cycleDuration - cycleRuntime);
			else
				printf("TaskScheduler can't keep up! The task takes too much time! Duration: %d/%dms, Task id: %d\n",
					cycleRuntime.asMilliseconds(), cycleDuration.asMilliseconds(), taskId);
		}
		_deleteTaskId(taskId);
	}

	template<class... Args>
	void _runCycleThread2(Time cycleDuration, function<void(Args...)> function, int taskId, Args... args) {
		Clock cycleRuntimeClock;
		Time cycleRuntime;
		sleep(cycleDuration);
		while (true) {
			cycleRuntimeClock.restart();
			if (!isReady[taskId])
				break;
			else
				function(args...);
			cycleRuntime = cycleRuntimeClock.restart();
			if (cycleRuntime < cycleDuration)
				sleep(cycleDuration - cycleRuntime);
			else
				printf("TaskScheduler can't keep up! The task takes too much time! Duration: %d/%dms, Task id: %d\n",
					cycleRuntime.asMilliseconds(), cycleDuration.asMilliseconds(), taskId);
		}
		_deleteTaskId(taskId);
	}

	template <class Owner>
	void _runCycleThread3(Time cycleDuration, function<void(Owner*)> function, Owner* owner, int taskId) {
		Clock cycleRuntimeClock;
		Time cycleRuntime;
		sleep(cycleDuration);
		while (true) {
			cycleRuntimeClock.restart();
			if (!isReady[taskId])
				break;
			else
				function(owner);
			cycleRuntime = cycleRuntimeClock.restart();
			if (cycleRuntime < cycleDuration)
				sleep(cycleDuration - cycleRuntime);
			else
				printf("TaskScheduler can't keep up! The task takes too much time! Duration: %d/%dms, Task id: %d\n",
					cycleRuntime.asMilliseconds(), cycleDuration.asMilliseconds(), taskId);
		}
		_deleteTaskId(taskId);
	}

	mutex isReadyLock;
	map<int, bool> isReady;
};

TaskScheduler taskScheduler;


int main(int argc, char* argv[]) {

	int a = 5;

	taskScheduler.callAfter(milliseconds(1500), [&a]() {cout << endl << "Lambda: " << a << endl; a += 2; });
	cout << a << endl;


	cout << a << endl;

	return 0;
}

#endif
