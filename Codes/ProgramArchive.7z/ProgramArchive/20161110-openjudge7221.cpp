/*
DOCUMENT CODE "openjudge7221.cpp"
CREATION DATE 2016-11-10
SIGNATURE CODE_20161110_OPENJUDGE7221
TOPIC ch0205 ���ȹ���
TODO: δ��ɵĴ���
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161110_OPENJUDGE7221

#include <cstdlib>
#include <iostream>
#include <queue>
#include <string>
#include <climits>

using namespace std;

#define ENTER       (1<<0)
#define NOENTER     (0<<0)
#define START       (1<<1)
#define END         (1<<2)
#define PORTAL      (1<<3)
#define MARBLE      (1<<4)

#define marble(a)   (1<<(a))
#define allMarbles  ((1<<(k))-1)

struct Pair {
	Pair() {}
	Pair(int x, int y) { this->x = x; this->y = y; }
	int x, y;
};

struct que {
	que() {}
	que(int x, int y, int marble = 0, int step = 0) {
		this->x = x;
		this->y = y;
		this->marble = marble;
		this->step = step;
	}
	int x, y;
	int marble;
	int step;
};

int dp[300][300][40];
char map[300][300];
int portalCount;
Pair portal[20];
queue<que> Q;

int n, m, k;
int startX, startY, endX, endY;

int getState(int x, int y) {
	if (x<1 || x>n || y<1 || y>m)
		return NOENTER;
	else if (map[x][y] == '.')
		return ENTER;
	else if (map[x][y] == '#')
		return NOENTER;
	else if (map[x][y] == 'S')
		return ENTER | START;
	else if (map[x][y] == 'E')
		return ENTER | END;
	else if (map[x][y] == '$')
		return ENTER | PORTAL;
	else if (map[x][y] >= '0'&&map[x][y] <= '9')
		return ENTER | MARBLE | ((map[x][y] - '0') << 5);
	else
		return NOENTER;
}

string getIndent(int x) {
	string ans = "";
	for (int i = 1; i <= x; i++) {
		ans += '\t';
	}
	return ans;
}

void goAround(int x, int y, int marble, int step, bool portalUsable = true) {
	//cout << getIndent(step);
	//if (!portalUsable)
	//	cout << "OVER PORTAL";
	//cout << "Looking around at X = " << x << ", Y = " << y << ", Marble = " << marble << ", Step = " << step << endl;
	int newMarble = marble;
	if (getState(x, y) & MARBLE) {
		newMarble = marble | marble(map[x][y] - '0');
	}
	if (getState(x + 1, y) & ENTER) { //Look up; move if possible.
		if (dp[x][y][marble] + 1 < dp[x + 1][y][newMarble]) {
			dp[x + 1][y][newMarble] = dp[x][y][marble] + 1;
			Q.push(que(x + 1, y, newMarble, step + 1));
		}
	}
	if (getState(x - 1, y) & ENTER) { //Look down; move if possible.
		if (dp[x][y][marble] + 1 < dp[x - 1][y][newMarble]) {
			dp[x - 1][y][newMarble] = dp[x][y][marble] + 1;
			Q.push(que(x - 1, y, newMarble, step + 1));
		}
	}
	if (getState(x, y + 1) & ENTER) { //Look right; move if possible.
		if (dp[x][y][marble] + 1 < dp[x][y + 1][newMarble]) {
			dp[x][y + 1][newMarble] = dp[x][y][marble] + 1;
			Q.push(que(x, y + 1, newMarble, step + 1));
		}
	}
	if (getState(x, y - 1) & ENTER) { //Look left; move if possible.
		if (dp[x][y][marble] + 1 < dp[x][y - 1][newMarble]) {
			dp[x][y - 1][newMarble] = dp[x][y][marble] + 1;
			Q.push(que(x, y - 1, newMarble, step + 1));
		}
	}
	if ((getState(x, y)&PORTAL) && portalUsable) {
		for (int i = 1; i <= portalCount; i++) {
			goAround(portal[i].x, portal[i].y, newMarble, step, false);
		}
	}
}

void bfs() {
	que q = Q.front();
	Q.pop();
	int x = q.x, y = q.y;
	int marble = q.marble;
	int step = q.step;
	//cout << getIndent(step) << "BFS() Call on X = " << x << ", Y = " << y << endl;
	goAround(x, y, marble, step, true);
}

int main(int argc, char* argv[]) {
	int t;
	cin >> t;
	while (t--) {
		cin >> n >> m >> k;
		portalCount = 0;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				for (int k = 0; k <= 32; k++)
					dp[i][j][k] = INT_MAX;
				cin >> map[i][j];
				if (map[i][j] == 'S') {
					startX = i;
					startY = j;
				}
				else if (map[i][j] == 'E') {
					endX = i;
					endY = j;
				}
				else if (map[i][j] == '$') {
					portalCount++;
					portal[portalCount] = Pair(i, j);
				}
			}
		}
		dp[startX][startY][0] = 0;
		Q.push(que(startX, startY));
		while (!Q.empty()) {
			if (Q.front().x == endX&&Q.front().y == endY&&Q.front().marble == allMarbles) {
				cout << Q.front().step << endl;
				break;
			}
			bfs();
		}
	}
	system("PAUSE");
	return 0;
}

#endif
