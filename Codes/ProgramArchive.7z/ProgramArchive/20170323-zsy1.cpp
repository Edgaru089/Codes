/*
DOCUMENT CODE "zsy1.cpp"
CREATION DATE 2017-03-23
SIGNATURE CODE_20170323_ZSY1
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170323_ZSY1

#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;

const int leftTerminal = 1, rightTerminal = 2;

struct quest {
	int l, r;
};

struct st {
	st(){}
	st(int X,int Pos,int term):x(X),pos(Pos),terminal(term){}
	int x;
	int pos,terminal;
};

quest comp[10001];
int n,q;
st stborder[10001];
int stbordercount,border[10001],borderCount,sums[10001];
int a[10001];

bool cmp(st x, st y) {
	if (x.x < y.x)
		return true;
	else
		return false;
}

int main(int argc, char* argv[]) {
	cin >> n >> q;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	for (int i = 1; i <= q; i++) {
		int l, r;
		cin >> l >> r;
		stborder[++stbordercount] = st(l, i,leftTerminal);
		stborder[++stbordercount] = st(r, i,rightTerminal);
	}
	sort(stborder + 1, stborder + stbordercount + 1, cmp);
	for (int i = 1; i <= stbordercount; i++) {
		border[++borderCount] = stborder[i].x;
		if (stborder[i].terminal == leftTerminal) {
			comp[stborder[i].pos].l = stborder[i].x;
		}
		else {
			comp[stborder[i].pos].r = stborder[i].x;
		}
	}
	for (int i = 1; i <= n; i++) {
	}
	system("PAUSE");
	return 0;
}

#endif
