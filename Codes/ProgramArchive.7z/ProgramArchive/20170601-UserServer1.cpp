/*
 DOCUMENT CODE "UserServer.cpp"
 CREATION DATE 2017-06-01
 SIGNATURE CODE_20170601_USERSERVER
 TOPIC �û�������
 */

#include "Overall.hpp"

 //Check if this code file is enabled for testing.
#ifdef CODE_20170601_USERSERVER

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <thread>
#include <mutex>
#include <set>
#include <map>
using namespace std;

struct User {
	User() {}
	User(string userName, string passwordHashed) :
		username(userName), passwordHashed(passwordHashed) {}

	void changePassword(string newHashed) const { passwordHashed = newHashed; }

	const bool operator == (User& right) { return username == right.username&&passwordHashed == right.passwordHashed; }

	mutable string username, passwordHashed;
};

class UserCredentialHandler {
public:

	const bool loadFromFile(const string& filename) {
		lock_guard<mutex> lock(dataLock);
		ifstream in(filename);
		string username, passwordHashed;
		userData.clear();
		if (!in)
			return false;
		while (in >> username >> passwordHashed)
			userData.insert(User(username, passwordHashed));
		return true;
	}

	const bool saveToFile(const string& filename) {
		lock_guard<mutex> lock(dataLock);
		ofstream fout(filename);
		if (!fout)
			return false;
		for (User i : userData) {
			fout << i.username << " " << i.passwordHashed << endl;
		}
		fout.flush();
		if (fout)
			return true;
		else
			return false;
	}

	const bool addUser(const string& username, const string& passwordHashed) {
		lock_guard<mutex> lock(dataLock);
		return userData.insert(User(username, passwordHashed)).second;
	}

	const bool deleteUser(const string& username, const string& passwordHashed) {
		lock_guard<mutex> lock(dataLock);
		set<User>::iterator iter = userData.find(User(username, passwordHashed));
		if (iter == userData.end())
			return false;
		userData.erase(iter);
		return true;
	}

	const bool changePassword(const string& username, const string& oldPasswordH, const string& newPasswordH) {
		lock_guard<mutex> lock(dataLock);
		set<User>::iterator iter = userData.find(User(username, oldPasswordH));
		if (iter == userData.end())
			return false;
		iter->changePassword(newPasswordH);
		return true;
	}

private:
	mutex dataLock;
	set<User> userData;
};

class UserSessionHandler {
public:

	const bool loadFromFile(const string& filename) {
		lock_guard<mutex> lock(dataLock);
		ifstream in(filename);
		string username, passwordHashed, session;
		sessionMapper.clear();
		sessionsInUse.clear();
		if (!in)
			return false;
		while (in >> username >> passwordHashed >> session) {
			sessionMapper[User(username, passwordHashed)] = session;
			sessionsInUse.insert(session);
		}
		return true;
	}

	const bool saveToFile(const string& filename) {
		lock_guard<mutex> lock(dataLock);
		ofstream fout(filename);
		if (!fout)
			return false;
		for (map<User, string>::iterator i = sessionMapper.begin(); i != sessionMapper.end(); i++) {
			fout << i->first.username << " " << i->first.passwordHashed << " " << i->second << endl;
		}
		fout.flush();
		if (fout)
			return true;
		else
			return false;
	}

	const string getSession(const User& user) {
		lock_guard<mutex> lock(dataLock);
		map<User, string>::iterator iter = sessionMapper.find(user);
		if (iter != sessionMapper.end())
			return iter->second;
		else
			return sessionMapper[user] = _generateSession();
	}

	const bool dismissSession(const User& user) {
		lock_guard<mutex> lock(dataLock);
		map<User, string>::iterator iter = sessionMapper.find(user);
		if (iter == sessionMapper.end())
			return false;
		else {
			_releaseSession(iter->second);
			sessionMapper.erase(iter);
			return true;
		}
	}

private:

	const string _generateSession() {
		string str;
		while (true) {
			str = "";
			for (int i = 0; i < 12; i++)
				str += '0' + rand() % 10;
			if (sessionsInUse.find(str) == sessionsInUse.end())
				break;
		}
		sessionsInUse.insert(str);
		return str;
	}

	const bool _releaseSession(const string& session) {
		set<string>::iterator iter = sessionsInUse.find(session);
		if (iter == sessionsInUse.end())
			return false;
		else {
			sessionsInUse.erase(iter);
			return true;
		}
	}

	mutex dataLock;
	map<User, string> sessionMapper;
	set<string> sessionsInUse;
};



int main(int argc, char* argv[]) {
	system("PAUSE");
	return 0;
}

#endif
