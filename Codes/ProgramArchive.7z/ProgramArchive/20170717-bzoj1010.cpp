/*
DOCUMENT CODE "bzoj1010.cpp"
CREATION DATE 2017-07-17
SIGNATURE CODE_20170717_BZOJ1010
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170717_BZOJ1010

#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

int MIN(int a, int b) { if (a<b) return a; else return b; }
int MAX(int a, int b) { if (a>b) return a; else return b; }

#define CLR(NAME,VALUE) memset(NAME,VALUE,sizeof(NAME))

using namespace std;


typedef __int64 LL;
const int N = 50000 + 10;
LL f[N];
LL dp[N];
int q[N];

LL G(int k, int j, int& c) {
	return dp[k] + (f[k] + c)*(f[k] + c) - dp[j] - (f[j] + c)*(f[j] + c);
}


LL S(int k, int j) {
	return 2 * (f[k] - f[j]);
}

int main() {
	int n, l, c, i, j, x, y, z, tmp;
	while (scanf("%d%d", &n, &l) != EOF) {
		f[0] = 0;
		for (i = 1; i <= n; ++i) {
			scanf("%d", &tmp);
			f[i] = f[i - 1] + tmp;
		}
		for (i = 1; i <= n; ++i) {
			f[i] += i;
		}
		c = 1 + l;
		dp[0] = 0;
		int head = 0, tail = 0;
		q[tail++] = 0;
		for (i = 1; i <= n; ++i) {
			while (head<tail - 1 && G(q[head + 1], q[head], c) <= f[i] * S(q[head + 1], q[head])) {
				++head;
			}
			x = q[head];
			dp[i] = dp[x] + (f[i] - f[x] - c)*(f[i] - f[x] - c);
			q[tail++] = i;
			for (j = tail - 2; j>head; --j) {
				z = q[j + 1];
				y = q[j];
				x = q[j - 1];
				if (!(G(y, x, c)*S(z, y)<G(z, y, c)*S(y, x))) {
					q[j] = q[--tail];
				}
				else {
					break;
				}
			}
		}
		printf("%I64d\n", dp[n]);
	}

	return 0;
}

#endif
