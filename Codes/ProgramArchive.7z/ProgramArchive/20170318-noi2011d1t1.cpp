/*
DOCUMENT CODE "noi2011d1t1.cpp"
CREATION DATE 2017-03-18
SIGNATURE CODE_20170318_NOI2011D1T1
TOPIC [NOI2011] ��ũ
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170318_NOI2011D1T1

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <climits>
using namespace std;

typedef long long s64;

const s64 S64_MAX = 9223372036854775807ll;

const int MaxNG = 1000000;

inline int rev(const int &a, const int &m) {
	int x1 = 1, x2 = 0, x3 = a;
	int y1 = 0, y2 = 1, y3 = m;

	while (y3 != 0) {
		int k = x3 / y3;
		int t1 = x1 - y1 * k, t2 = x2 - y2 * k, t3 = x3 - y3 * k;
		x1 = y1, x2 = y2, x3 = y3;
		y1 = t1, y2 = t2, y3 = t3;
	}
	if (x3 != 1)
		return 0;
	return x1 >= 0 ? x1 : x1 + m;
}

s64 n;
int nG, mod;

int fib[MaxNG * 6 + 1];
int firstPos[MaxNG];

inline void calcFirstPos()
{
	fill(firstPos, firstPos + nG, -1);

	fib[0] = 1, fib[1] = 1;

	int i = 2;
	do {
		int c = fib[i - 1] + fib[i - 2];
		if (c >= nG)
			c -= nG;

		fib[i] = c;
		if (firstPos[c] == -1)
			firstPos[c] = i;

		i++;
	} while (!(fib[i - 1] == 1 && fib[i - 2] == 1));
}

struct matrix {
	int a[3][3];

	inline int& operator()(const int &x, const int &y) {
		return a[x][y];
	}
	inline int operator()(const int &x, const int &y) const {
		return a[x][y];
	}

	inline matrix &operator*=(const matrix &rhs) {
		static s64 c[3][3];
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++) {
				c[i][j] = 0;
				for (int k = 0; k < 3; k++)
					c[i][j] += (s64)a[i][k] * rhs.a[k][j] % mod;
				c[i][j] %= mod;
			}
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
				a[i][j] = c[i][j];
		return *this;
	}
};

inline matrix _genMatI() {
	matrix mat;
	mat(0, 0) = 1, mat(0, 1) = 0, mat(0, 2) = 0;
	mat(1, 0) = 0, mat(1, 1) = 1, mat(1, 2) = 0;
	mat(2, 0) = 0, mat(2, 1) = 0, mat(2, 2) = 1;
	return mat;
}

matrix matI = _genMatI();

inline matrix matpow(const matrix &b, const s64 &n) {
	matrix res = matI;
	matrix t = b;

	for (s64 i = n; i > 0; i >>= 1) {
		if (i & 1)
			res *= t;
		t *= t;
	}
	return res;
}

int main() {
	cin >> n >> nG >> mod;

	calcFirstPos();

	static int preRev[MaxNG];
	for (int i = 0; i < nG; i++)
		preRev[i] = rev(i, nG);

	static int next[MaxNG];
	static s64 aL[MaxNG];
	for (int i = 0; i < nG; i++) {
		if (!preRev[i] || !firstPos[preRev[i]])
			next[i] = -1, aL[i] = S64_MAX;
		else {
			int k = firstPos[preRev[i]];
			next[i] = (s64)fib[k - 1] * i % nG, aL[i] = k + 1;
		}
	}

	matrix matA, matB;
	matA(0, 0) = 1, matA(0, 1) = 1, matA(0, 2) = 0;
	matA(1, 0) = 1, matA(1, 1) = 0, matA(1, 2) = 0;
	matA(2, 0) = 0, matA(2, 1) = 0, matA(2, 2) = 1;

	matB(0, 0) = 1, matB(0, 1) = 1, matB(0, 2) = 0;
	matB(1, 0) = 1, matB(1, 1) = 0, matB(1, 2) = 0;
	matB(2, 0) = mod - 1, matB(2, 1) = 0, matB(2, 2) = 1;

	static bool book[MaxNG + 1];
	int cirS;
	for (cirS = 1; cirS != -1 && !book[cirS]; cirS = next[cirS])
		book[cirS] = true;

	matrix matR = matI;
	for (int i = 1; i != cirS; i = next[i])
		if (n < aL[i]) {
			matR *= matpow(matA, n);
			n = 0;
			break;
		}
		else {
			matR *= matpow(matA, aL[i] - 1);
			matR *= matB;
			n -= aL[i];
			if (n == 0)
				break;
		}
		if (n > 0) {
			int cur = cirS;
			s64 totL = 0;
			matrix matC = matI;
			do {
				matC *= matpow(matA, aL[cur] - 1);
				matC *= matB;
				totL += aL[cur];
				cur = next[cur];
			} while (cur != cirS);

			while (cur != cirS) {
				cout << "ERROR!!!!" << endl;
			}

			matR *= matpow(matC, n / totL);
			n %= totL;

			for (int i = cirS; ; i = next[i])
				if (n < aL[i])
				{
					matR *= matpow(matA, n);
					break;
				}
				else
				{
					matR *= matpow(matA, aL[i] - 1);
					matR *= matB;
					n -= aL[i];
					if (n == 0)
						break;
				}
		}
		static int vec[3] = { 0, 1, 1 };
		s64 res = 0;
		for (int k = 0; k < 3; k++)
			res += (s64)vec[k] * matR(k, 0);
		res %= mod;
		cout << res << endl;
		return 0;
}

#endif
