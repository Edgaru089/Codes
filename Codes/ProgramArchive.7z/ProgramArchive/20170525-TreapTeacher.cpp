#include <cstdio>
#include <cstdlib>
#include <iostream>
using namespace std;
#define LSON 0
#define RSON 1
#define Max(a,b) ((a)>(b)?(a):(b))
struct Treap
{
    int d;
    int rnd;
    int dep;
    Treap *ch[2];
    Treap* parent;
}pool[100100],*t,*root;
int n,cnt;
void left_rotate(Treap *p) {
	Treap *rson=p->ch[RSON],*parent=p->parent,*gparent=p->parent->parent;
	parent->ch[LSON]=rson;
	if(rson!=NULL)
		rson->parent=parent;
	p->ch[RSON]=parent;
	parent->parent=p;
	if(gparent!=NULL)
		if(gparent->ch[LSON]==parent)
			gparent->ch[LSON]=p;
		else
			gparent->ch[RSON]=p;
	p->parent=gparent;
}
void right_rotate(Treap *p) {
	Treap *lson=p->ch[LSON],*parent=p->parent,*gparent=p->parent->parent;
	parent->ch[RSON]=lson;
	if(lson!=NULL)
		lson->parent=parent;
	p->ch[LSON]=parent;
	parent->parent=p;
	if(gparent!=NULL)
		if(gparent->ch[LSON]==parent)
			gparent->ch[LSON]=p;
		else
			gparent->ch[RSON]=p;
	p->parent=gparent;
}
void insert(Treap *&r,Treap *p)
{
    if(r==NULL){r=p;return ;}
    if(r->d>=p->d)
    {
	    if(r->ch[LSON]==NULL)
	    {
		    r->ch[LSON]=p;
		    p->parent=r;
		}
		else
		    insert(r->ch[LSON],p);
	}
	else
	{
	    if(r->ch[RSON]==NULL)
	    {
		    r->ch[RSON]=p;
		    p->parent=r;
		}
		else
		    insert(r->ch[RSON],p);
	}
}

void rotate(Treap *p)
{
    Treap *parent=p->parent;
    if(parent==NULL) return ;
    if(parent->rnd<=p->rnd) return ;
    if(parent->ch[LSON]==p) left_rotate(p);
    else right_rotate(p);
    rotate(p);
}
int ans;
void dfs(Treap *p)
{
    if(p->ch[LSON])
    {
	    p->ch[LSON]->dep=p->dep+1;
	    if(ans<p->ch[LSON]->dep) ans=p->ch[LSON]->dep;
		dfs(p->ch[LSON]);
	}
	if(p->ch[RSON])
    {
	    p->ch[RSON]->dep=p->dep+1;
	    if(ans<p->ch[RSON]->dep) ans=p->ch[RSON]->dep;
		dfs(p->ch[RSON]);
	}
}
int main()
{
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
	    t=&pool[++cnt];
	    t->d=i;
	    t->rnd=rand();
	    insert(root,t);
	    rotate(t);
	}
	root->dep=1;
	dfs(root);
	cout<<ans<<endl;
	system("PAUSE");
	return 0;
	}
