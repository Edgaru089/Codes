/*
DOCUMENT CODE "bzojbegin1151.cpp"
CREATION DATE 2017-02-01
SIGNATURE CODE_20170201_BZOJBEGIN1151
TOPIC ��ʿ��
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170201_BZOJBEGIN1151

#include<cstdio>
#include<algorithm>
using namespace std;
int i, j, n, r, q;
int w[200001], Size;
struct qq
{
	int s, p;
} a[200001], x[100001], y[100001];
int comp(qq a, qq b)
{
	if (a.s != b.s)
		return a.s > b.s;
	return a.p < b.p;
}
void merge()
{
	int p = 1, q = 1, s = 1;
	while (s <= n)
	{
		if (p > Size)
		{
			for (int i = q; i <= Size; i++)
				a[s++] = y[i];
			break;
		}
		if (q > Size)
		{
			for (int i = p; i <= Size; i++)
				a[s++] = x[i];
			break;
		}
		if (x[p].s < y[q].s || x[p].s == y[q].s && x[p].p > y[q].p)
			a[s++] = y[q++];
		else a[s++] = x[p++];
	}
}
int main()
{
	scanf("%d%d%d", &n, &r, &q);
	n = (n << 1);
	for (i = 1; i <= n; i++)
	{
		scanf("%d", &a[i].s);
		a[i].p = i;
	}
	for (i = 1; i <= n; i++)
		scanf("%d", &w[i]);
	sort(a + 1, a + n + 1, comp);
	for (i = 1; i <= r; i++)
	{
		Size = 0;
		for (j = 1; j <= n; j += 2)
			if (w[a[j].p] > w[a[j + 1].p])
			{
				a[j].s++;
				x[++Size] = a[j];
				y[Size] = a[j + 1];
			}
			else
			{
				a[j + 1].s++;
				x[++Size] = a[j + 1];
				y[Size] = a[j];
			}
		merge();
	}
	printf("%d", a[q].p);
	system("PAUSE");
	return 0;
}

#endif
