/*
DOCUMENT CODE "poj3067.cpp"
CREATION DATE 2017-02-09
SIGNATURE CODE_20170209_POJ3067
TOPIC Japan
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170209_POJ3067

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;

#define maxn 2005

struct Highway {
	int a, b;
} way[maxn * maxn];

int n, m, k, c[maxn];
long long ans;

void input() {
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 0; i < k; i++)
		scanf("%d%d", &way[i].a, &way[i].b);
}

bool cmp(const Highway &a, const Highway &b) {
	if (a.a != b.a)
		return a.a < b.a;
	return a.b < b.b;
}

long long cal(int a) {
	long long sum = 0;
	while (a > 0) {
		sum += c[a];
		a -= (a & -a);
	}
	return sum;
}

void modify(int a, int x) {
	while (a <= m) {
		c[a] += x;
		a += (a & -a);
	}
}

void work() {
	ans = 0;
	for (int i = 0; i < k; i++) {
		ans += i - cal(way[i].b);
		modify(way[i].b, 1);
	}
}

int main() {
	//freopen("D:\\t.txt", "r", stdin);
	int t;
	scanf("%d", &t);
	for (int i = 0; i < t; i++) {
		memset(c, 0, sizeof(c));
		input();
		sort(way, way + k, cmp);
		work();
		printf("Test case %d: %I64d\n", i + 1, ans);
	}
#ifdef LOCAL
	system("PAUSE");
#endif
	return 0;
}

#endif
