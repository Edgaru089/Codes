/*
DOCUMENT CODE "ExtendEucild.cpp"
CREATION DATE 2017-01-09
SIGNATURE CODE_20170109_EXTENDEUCILD
TOPIC ��չŷ�����ģ��
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170109_EXTENDEUCILD

#include <cstdlib>
#include <iostream>

using namespace std;

int gcd(int m, int n) {
	if (n != 1)
		return gcd(n, m%n);
	else
		return m;
}

int x, y;
int gcdEx(int a, int b)
{
	if (b == 0)
	{
		x = 1;
		y = 0;
		return a;
	}
	else
	{
		int r = gcdEx(b, a%b);
		int t = x;
		x = y;
		y = t - a / b * y;
		return r;
	}
}

int main(int argc, char* argv[]) {
	int a, b;
	cin >> a >> b;
	cout << gcdEx(a, b) << endl;
	cout << x << " " << y << endl;
	system("PAUSE");
	return 0;
}

#endif
