/*
DOCUMENT CODE "zsy1.cpp"
CREATION DATE 2016-12-01
SIGNATURE CODE_20161201_ZSY1
TOPIC ��һ��N (M<=10) x M (M<=1000)��������һЩ�㲻�ܷţ���k(k<=10)�����ӣ�����ͬ�в���ͬ�У��󷽰���%10^9+7
MODIFY DATES 2016-12-01
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161201_ZSY1

#include <cstdlib>
#include <iostream>

using namespace std;

#define MOD 1000000007

#define digit(x)       (1<<(x))
#define addDigit(x,y)  ((x)|(y))
#define exists(x,y)    (((x)&(y))!=0)
#define allDigits(n)   ((1<<((n)+1))-2)

int n, m, k;
int s[1000][2048];
bool able[11][1001];

int dfs(int x, int state) {  //���� ÿһ��(M, M<=1000) ö��. State��ʾ ÿһ��(N, N<=10) �Ƿ�ʹ�ù�
	if (x > m)
		if (state == allDigits(n))
			return 1;
		else
			return 0;
	if (s[x][state] != -1)
		return s[x][state];
	int sum = 0;
	for (int i = 1; i <= n; i++) {
		if (!exists(state, digit(i)) && able[i][x]) {
			sum += dfs(x + 1, addDigit(state, digit(i)));
			sum %= MOD;
		}
	}
	sum += dfs(x + 1, state);
	sum %= MOD;
	return s[x][state] = sum;
}

int main(int argc, char* argv[]) {
	memset(s, -1, sizeof(s));
	cin >> n >> m;
	k = n;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) {
			bool b;
			cin >> b;
			able[i][j] = !b;
		}
	cout << dfs(1, 0) << endl;
	system("PAUSE");
	return 0;
}

#endif
