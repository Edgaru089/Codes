/*
 DOCUMENT CODE "Treap.cpp"
 CREATION DATE 2017-05-25
 SIGNATURE CODE_20170525_TREAP
 TOPIC treap
 */

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170525_TREAP

#include <cstdlib>
#include <iostream>
#include <cstdlib>
using namespace std;

#define LSON 0
#define RSON 1

struct node{
	int d;
	int rand;
	node* child[2];
};

int n,cnt;
node pool[100001],*t,*root;
int top;

void leftRotate(node* p){
	//TODO
}

void rightRotate(node* p){
	//TODO
}

void rotateToMaintainHeap(node* p){
	node* parent=p->parent;
	if(parent==NULL)
		return;
	else if(parent->rand<=p->rand)
		return;
	else{
		if(parent->ch[LSON]==p)
			left_rotate(p);
		else
			right_rotate(p);
		rotateToMaintainHeap(p);
	}
}

void insert(node*& p,node* parent,node*& r=root){
	if(r==NULL){
		r=p;
		return;
	}else if(r->d >= p->d){    //���� 
		if(r->ch[LSON]==NULL){
			r->ch[LSON]=p;
			p->parent=r;
		}else
			insert(p,p->ch[LSON]);
	}
	
}

int main(int argc, char* argv[]) {
	cin>>n;
	for(int i=1;i<=n;i++){
		t=&pool[++cnt];
		t->d=i;
		t->rand=rand();
		insert(t);
		rotateToMaintainHeap(t);
	}
	system("PAUSE");
	return 0;
}

#endif
