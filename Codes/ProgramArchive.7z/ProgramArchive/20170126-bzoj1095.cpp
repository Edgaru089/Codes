/*
DOCUMENT CODE "bzoj1095.cpp"
CREATION DATE 2017-01-26
SIGNATURE CODE_20170126_BZOJ1095
TOPIC [ZJOI2007]Hide ׽�Բ�
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170126_BZOJ1095

#include<cstdio>
#include<cctype>
#include<queue>
#include<cstring>
#include<algorithm>
#define rep(s,t) for(int i=s;i<=t;i++)
#define ren for(int i=first[x];i;i=Next[i])
using namespace std;
inline int read() {
	int x = 0, f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	return x*f;
}
const int maxn = 200010;
struct Heap {
	priority_queue<int> A, del;
	void push(int x) { A.push(x); }
	void erase(int x) { del.push(x); }
	void pop() {
		while (del.size() && A.top() == del.top()) A.pop(), del.pop();
		A.pop();
	}
	int top() {
		while (del.size() && A.top() == del.top()) A.pop(), del.pop();
		return !A.size() ? 0 : A.top();
	}
	int size() { return A.size() - del.size(); }
	int stop() {
		if (size()<2) return 0;
		int t1 = top(); pop();
		int t2 = top(); push(t1);
		return t2;
	}
}A, B[maxn], C[maxn];
int n, m, clo[maxn], first[maxn], Next[maxn], to[maxn], es;
void AddEdge(int u, int v) {
	to[++es] = v; Next[es] = first[u]; first[u] = es;
	to[++es] = u; Next[es] = first[v]; first[v] = es;
}
int Log[maxn], mn[19][maxn], dep[maxn], pos[maxn], dfs_clock;
void dfs(int x, int fa) {
	mn[0][++dfs_clock] = dep[x]; pos[x] = dfs_clock;
	ren if (to[i] != fa) {
		dep[to[i]] = dep[x] + 1;
		dfs(to[i], x);
		mn[0][++dfs_clock] = dep[x];
	}
}
void init() {
	Log[0] = -1; rep(1, 200000) Log[i] = Log[i >> 1] + 1;
	for (int i = 1; (1 << i) <= dfs_clock; i++)
		for (int j = 1; j + (1 << i) - 1 <= dfs_clock; j++)
			mn[i][j] = min(mn[i - 1][j], mn[i - 1][j + (1 << (i - 1))]);
}
int dist(int x, int y) {
	int ans = dep[x] + dep[y];
	x = pos[x]; y = pos[y]; if (x>y) swap(x, y);
	int k = Log[y - x + 1];
	return ans - 2 * min(mn[k][x], mn[k][y - (1 << k) + 1]);
}
int root, Size, vis[maxn], f[maxn], s[maxn];
void getroot(int x, int fa) {
	int maxs = 0; s[x] = 1;
	ren if (to[i] != fa && !vis[to[i]]) getroot(to[i], x), maxs = max(maxs, s[to[i]]), s[x] += s[to[i]];
	f[x] = max(maxs, Size - s[x]);
	if (f[root]>f[x]) root = x;
}
int fa[maxn];
void solve(int x, int F) {
	fa[x] = F; vis[x] = 1;
	ren if (!vis[to[i]]) {
		Size = f[0] = s[to[i]]; getroot(to[i], root = 0);
		solve(root, x);
	}
}
void turn_off(int u, int v) {
	if (u == v) {
		B[u].push(0);
		if (B[u].size() == 2) A.push(B[u].top());
	}
	if (!fa[u]) return;
	int f = fa[u], D = dist(f, v), tmp = C[u].top(); C[u].push(D);
	if (D>tmp) {
		int mx = B[f].top() + B[f].stop(), Size = B[f].size();
		if (tmp) B[f].erase(tmp);
		B[f].push(D);
		int now = B[f].top() + B[f].stop();
		if (now>mx) {
			if (Size >= 2) A.erase(mx);
			if (B[f].size() >= 2) A.push(now);
		}
	}
	turn_off(f, v);
}
void turn_on(int u, int v) {
	if (u == v) {
		if (B[u].size() == 2) A.erase(B[u].top());
		B[u].erase(0);
	}
	if (!fa[u]) return;
	int f = fa[u], D = dist(f, v), tmp = C[u].top();
	C[u].erase(D);
	if (D == tmp) {
		int mx = B[f].top() + B[f].stop(), Size = B[f].size();
		B[f].erase(D);
		if (C[u].top()) B[f].push(C[u].top());
		int now = B[f].top() + B[f].stop();
		if (now<mx) {
			if (Size >= 2) A.erase(mx);
			if (B[f].size() >= 2) A.push(now);
		}
	}
	turn_on(f, v);
}
int main() {
	n = read();
	rep(2, n) AddEdge(read(), read());
	dfs(1, 0); init();
	Size = f[0] = n; getroot(1, root = 0);
	solve(root, 0);
	rep(1, n) clo[i] = 1, C[i].push(0), turn_off(i, i);
	char ch[2];
	m = read(); int cnt = n;
	while (m--) {
		scanf("%s", ch);
		if (ch[0] == 'G') printf("%d\n", cnt<2 ? -1 : A.top());
		else {
			int x = read();
			if (clo[x]) turn_on(x, x), cnt--;
			else turn_off(x, x), cnt++;
			clo[x] ^= 1;
		}
	}
	system("PAUSE");
	return 0;
}

#endif
