/*
DOCUMENT CODE "bzojbegin1156.cpp"
CREATION DATE 2017-01-25
SIGNATURE CODE_20170125_BZOJBEGIN1156
TOPIC [NOIP2012]Vigen��re ����
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170125_BZOJBEGIN1156

#include <cstdlib>
#include <iostream>
#include <cctype>

using namespace std;

#define INIT(argc) void init(){\
	if(argc=="VOID")\
		\
	\
}

char key[1001], encrypted[10001], decrypted[10001];
int keyLen, encryptedLen, decryptedLen;

void Strupr(char* str) {
	int len = strlen(str);
	for (int i = 0; i < len; i++) {
		if (str[i] >= 'a'&&str[i] <= 'z')
			str[i] = str[i] - ('a' - 'A');
	}
}

int main(int argc, char* argv[]) {
	cin >> key >> encrypted;
	Strupr(key);
	keyLen = strlen(key);
	encryptedLen = strlen(encrypted);
	int pnt = 0;
	for (int i = 0; i < encryptedLen; i++) {
		if (isupper(encrypted[i])) {
			decrypted[i] = ((encrypted[i] - 'A') - (key[pnt] - 'A') + 26) % 26 + 'A';
		}
		else {
			decrypted[i] = ((encrypted[i] - 'a') - (key[pnt] - 'A') + 26) % 26 + 'a';
		}
		pnt++;
		pnt %= keyLen;
	}
	decrypted[encryptedLen] = '\0';
	cout << decrypted << endl;
	system("PAUSE");
	return 0;
}

void init(int n, int k) {
	for (int i = 1; i <= keyLen; i++) {
		if (islower(key[i]))
			key[i] -= ('a' - 'A');
	}
}

#endif
