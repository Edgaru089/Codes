/*
DOCUMENT CODE "bzoj1095-2.cpp"
CREATION DATE 2017-01-26
SIGNATURE CODE_20170126_BZOJ1095_2
TOPIC [ZJOI2007]Hide ׽�Բ�
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170126_BZOJ1095_2

#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;

struct edge {
	edge() {}
	edge(int u, int v, int len) {
		this->u = u;
		this->v = v;
		this->len = len;
	}
	int u, v, len;
};

struct node {
	int v, len;
	node* next;
};

struct st {
	int left, right;
	st* lson, *rson;
	int Max, lazy;
};

node pool[300001], *h[100001];
int top;
int n, m, Count;
edge a[300001];

int p[100001];

st stpool[300001], *root;
int sttop;

bool cmp(edge x, edge y) {
	if (x.len < y.len)
		return true;
	else
		return false;
}

void addedge(int u, int v, int len) {
	node* tmp = &pool[top];
	top++;
	tmp->v = v;
	tmp->len = len;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[top];
	top++;
	tmp->v = u;
	tmp->len = len;
	tmp->next = h[v];
	h[v] = tmp;
}

int Find(int x) {
	if (p[x] < 0)
		return x;
	else
		return p[x] = Find(p[x]);
}

void Union(int x, int y) {
	x = p[x];
	y = p[y];
	p[x] += p[y];
	p[y] = x;
}

void kruskal() {
	Count = 1;
	for (int i = 1; i <= m&&Count < n; i++) {
		if (Find(a[i].u) != Find(a[i].v)) {
			Union(a[i].u, a[i].v);
			Count++;
			addedge(a[i].u, a[i].v, a[i].len);
		}
	}
}

st* build(int left = 1, int right = n) {
	st* tmp = &stpool[++sttop];
	tmp->lazy = tmp->Max = 0;
	if (left == right) {
		tmp->lson = tmp->rson = NULL;
		tmp->left = tmp->right = left;
	}
	else {
		int mid = (left + right) / 2;
		tmp->lson = build(left, mid);
		tmp->rson = build(mid + 1, right);
		tmp->left = left;
		tmp->right = right;
	}
	return tmp;
}

void pushDown(st* p) {
	if (p == NULL)
		return;
	if (p->lson != NULL)
		p->lson->lazy += p->lazy;
	if (p->rson != NULL)
		p->rson->lazy += p->lazy;
	p->Max += p->lazy;
	p->lazy = 0;
}

void change(int left, int right, int add, st* p = root) {
	if (p->left == left&&p->right == right) {
		p->lazy += add;
		return;
	}
	pushDown(p);
	pushDown(p->lson);
	pushDown(p->rson);
	if (p->lson->right >= right)
		change(left, right, add, p->lson);
	else if (p->rson->left <= left)
		change(left, right, add, p->rson);
	else {
		change(left, p->lson->right, add, p->lson);
		change(p->rson->left, right, add, p->rson);
	}
	p->Max = max(p->lson->Max + p->lson->lazy, p->rson->Max + p->rson->lazy);
}

int query(int left, int right, st* p = root) {
	if (p->left == left&&p->right == right) {
		return p->Max + p->lazy;
	}
	pushDown(p);
	pushDown(p->lson);
	pushDown(p->rson);
	if (p->lson->right >= right)
		return query(left, right, p->lson);
	else if (p->rson->left <= left)
		return query(left, right, p->rson);
	else {
		return max(query(left, p->lson->right, p->lson),
			query(p->rson->left, right, p->rson));
	}
}

int main() {
	memset(p, -1, sizeof(p));
	int u, v, len;
	cin >> n >> m;
	for (int i = 1; i <= m; i++) {
		cin >> u >> v >> len;
		a[i] = edge(u, v, len);
	}
	sort(a + 1, a + m + 1, cmp);
	kruskal();
	root = build();
	return 0;
}

#endif
