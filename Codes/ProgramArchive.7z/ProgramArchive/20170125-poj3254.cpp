/*
DOCUMENT CODE "poj3254.cpp"
CREATION DATE 2017-01-25
SIGNATURE CODE_20170125_POJ3254
TOPIC poj3254 Corn Fields
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170125_POJ3254

#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

#define mod 100000000

int n, m, a[15];
int dp[13][1 << 13];

int judge(int x, int y)
{
	if ((a[x] & y) != y)
		return 0;
	if ((y&(y << 1)) != 0)
		return 0;
	return 1;
}

int main()
{
	while (~scanf("%d%d", &n, &m))
	{
		for (int i = 1; i <= n; i++)
		{
			a[i] = 0;
			for (int j = 1; j <= m; j++)
			{
				int k;
				scanf("%d", &k);
				a[i] = (a[i] << 1) + k;
			}
		}
		memset(dp, 0, sizeof(dp));
		dp[0][0] = 1;
		for (int i = 1; i <= n; i++)
		{
			for (int j = 0; j<(1 << m); j++)
			{
				if (judge(i, j) == 0)
					continue;
				for (int k = 0; k<(1 << m); k++)
				{
					if ((j&k) != 0)
						continue;
					dp[i][j] = dp[i][j] + dp[i - 1][k];
					dp[i][j] %= mod;
				}
			}
		}
		int output = 0;
		for (int i = 0; i<(1 << m); i++)
		{
			output += dp[n][i];
			output %= mod;
		}
		printf("%d\n", output);
	}
}


#endif
