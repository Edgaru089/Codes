/*
DOCUMENT NAME "20180803-luoguT39604.cpp"
CREATION DATE 2018-08-03
SIGNATURE CODE_20180803_LUOGUT39604
COMMENT ̽Ů�����˼ƻ�(�����������ṩ From bb��) / �߶���
*/

#include "Overall.hpp"

// Check if this code file is enabled for testing
#ifdef CODE_20180803_LUOGUT39604

#include <cstdlib>
#include <iostream>
using namespace std;

constexpr int MaxN = 100000 + 10, MaxM = 100000 + 10, MaxK = 100000 + 10;


int main(int argc, char* argv[]) {

	return 0;
}

#endif

