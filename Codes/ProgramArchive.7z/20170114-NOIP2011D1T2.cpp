/*
DOCUMENT CODE "NOIP2011D1T2.cpp"
CREATION DATE 2017-01-14
SIGNATURE CODE_20170114_NOIP2011D1T2
TOPIC NOIP2011 day1 T2 hotel ѡ���ջ luogu-1311
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170114_NOIP2011D1T2

#include<iostream>
#include<cstring>
#include<cstdio>

using namespace std;

int n, ans, k, p, a[51], c[51];
bool b[51];

int main()
{
	scanf("%d%d%d", &n, &k, &p);
	for (int i = 1; i <= n; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		if (y <= p)
		{
			memset(b, 0, sizeof(b));
			c[x] = a[x];
		}
		else
			if (!b[x])
			{
				c[x] = a[x];
				b[x] = 1;
			}
		ans += c[x];
		a[x]++;
	}
	printf("%d\n", ans);
	system("PAUSE");
	return 0;
}

#endif
