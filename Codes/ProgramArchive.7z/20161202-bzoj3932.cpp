/*
DOCUMENT CODE "bzoj3932.cpp"
CREATION DATE 2016-12-02
SIGNATURE CODE_20161202_BZOJ3932
TOPIC bzoj3932 [CQOI2015]�����ѯϵͳ
MODIFY DATES 2016-12-02
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161202_BZOJ3932

#include <cstdio>
#include <algorithm>

using namespace std;
typedef long long ll;
const int N = 1e5 + 5;
const int P = 1e7;

inline int read();

struct chair_tree {
	chair_tree *ls, *rs;
	int sz;
	ll sum;

#define Len (1 << 16)
	void* operator new(size_t, int x, ll y, chair_tree *L = NULL, chair_tree *R = NULL) {
		static chair_tree *mempool, *c;
		if (c == mempool)
			mempool = (c = new chair_tree[Len]) + Len;
		c->ls = L, c->rs = R, c->sz = x, c->sum = y;
		return c++;
	}
	void* operator new(size_t, chair_tree *p) {
		static chair_tree *mempool, *c;
		if (c == mempool)
			mempool = (c = new chair_tree[Len]) + Len;
		*c = *p;
		return c++;
	}
#undef Len

#define mid (l + r >> 1)
	void modify(int l, int r, int pos, int d_sz, ll d_sum) {
		this->sz += d_sz, this->sum += d_sum;
		if (l == r) return;
		if (pos <= mid) this->ls = new(this->ls)chair_tree, this->ls->modify(l, mid, pos, d_sz, d_sum);
		else this->rs = new(this->rs)chair_tree, this->rs->modify(mid + 1, r, pos, d_sz, d_sum);
	}

	ll kth(int l, int r, int k) {
		if (l == r) return 1ll * mid * min(k, this->sz);
		if (k <= this->ls->sz) return this->ls->kth(l, mid, k);
		else return this->rs->kth(mid + 1, r, k - this->ls->sz) + this->ls->sum;
	}
#undef mid
} *chair[N];

struct Data {
	int t, v, del;
	Data(int _t = 0, int _v = 0, int _d = 0) : t(_t), v(_v), del(_d) {}

	inline bool operator < (const Data &p) const {
		return t < p.t;
	}
} a[N << 1];

int n, m, k;
ll ans;

int main() {
	int i, j, A, B, C, x, y, z;
	m = read(), n = read();
	for (i = 1; i <= m; ++i) {
		x = read(), y = read(), z = read();
		a[i * 2 - 1] = Data(x, z, 1);
		a[i * 2] = Data(y + 1, z, -1);
	}
	sort(a + 1, a + m * 2 + 1);
	chair[0] = new(0, 0)chair_tree;
	chair[0]->ls = chair[0]->rs = chair[0];

	for (i = j = 1; i <= n; ++i) {
		chair[i] = new(chair[i - 1])chair_tree;
		for (; j <= m << 1 && a[j].t == i; ++j)
			chair[i]->modify(1, P, a[j].v, a[j].del, a[j].v * a[j].del);
	}
	for (i = ans = 1; i <= n; ++i) {
		x = read(), A = read(), B = read(), C = read();
		k = (A * ans + B) % C + 1;
		printf("%lld\n", ans = chair[x]->kth(1, P, k));
	}
	return 0;
}

inline int read() {
	static int x;
	static char ch;
	x = 0, ch = getchar();
	while (ch < '0' || '9' < ch)
		ch = getchar();
	while ('0' <= ch && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x;
}

#endif
