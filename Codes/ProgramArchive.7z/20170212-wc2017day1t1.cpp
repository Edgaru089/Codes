/*
DOCUMENT CODE "wc2017day1t1.cpp"
CREATION DATE 2017-02-12
SIGNATURE CODE_20170212_WC2017DAY1T1
TOPIC ���� chess
��� Documents\2017-02-12-WinterCamp2017\day1.pdf
TODO: δ��ɵĴ��� �����30��
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170212_WC2017DAY1T1

#include <cstdlib>
#include <iostream>
#include <cstring>
using namespace std;

struct node {
	int v;
	node* next;
};

int n, m, q;
node pool[1000001], *h[1001];
int top;

bool success[9][9][9][9][9][9][9][9];
int state[9], curstate[9];

int p[10001];

void addedge(int u, int v) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[++top];
	tmp->v = u;
	tmp->next = h[v];
	h[v] = tmp;
}

int Find(int x) {
	if (p[x] < 0)
		return x;
	else
		return p[x] = Find(p[x]);
}

void Union(int x, int y) {
	x = Find(x);
	y = Find(y);
	p[x] += p[y];
	p[y] = x;
}

bool beenTo(int* state = ::state) {
	return success[state[1]][state[2]][state[3]][state[4]][state[5]][state[6]][state[7]][state[8]];
}

void setFlag(int* state = ::state) {
	success[state[1]][state[2]][state[3]][state[4]][state[5]][state[6]][state[7]][state[8]] = true;
}

void dfs(int zeroPos) {
	for (node* p = h[zeroPos]; p != NULL; p = p->next) {
		int u = zeroPos, v = p->v;
		swap(state[u], state[v]);
		if (!beenTo()) {
			setFlag();
			dfs(v);
		}
		else
			swap(state[u], state[v]);
	}
}

int main(int argc, char* argv[]) {
	int zeroPos;
	int u, v;
	memset(p, -1, sizeof(p));
	cin >> n >> m >> q;
	for (int i = 1; i <= m; i++) {
		cin >> u >> v;
		addedge(u, v);
	}
	for (int i = 1; i <= n; i++) {
		cin >> state[i];
		if (state[i] == 0)
			zeroPos = i;
	}
	dfs(zeroPos);
	for (int i = 1; i <= q; i++) {
		for (int j = 1; j <= n; j++)
			cin >> curstate[j];
		if (beenTo(curstate))
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
	system("PAUSE");
	return 0;
}

#endif
