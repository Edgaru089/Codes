/*
DOCUMENT CODE "CL-Day1T2.cpp"
CREATION DATE 2016-11-15
SIGNATURE CODE_20161115_CL_DAY1T2
TOPIC ����һ��ģ��Day1�ڶ���
MODIFY DATES 2016-11-16
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161115_CL_DAY1T2

#include <cstdlib>
#include <iostream>

using namespace std;

int dp[100001];
unsigned char vram[640][480];

int gcd(int a, int b) {
	if (a == 1 || b == 1)
		return b;
	else
		return gcd(b, a%b);
}

int x, y, t;
void extend_euclid(int a, int b)
{
	if (b == 0) {
		x = 1;
		y = 0;
	}
	else {
		extend_euclid(b, a%b);
		t = x;
		x = y;
		y = t - (a / b)*y;

	}
}

int main(int argc, char* argv[]) {
	int a, b;
	cin >> a >> b;
	extend_euclid(a, b);
	cout << y << " " << x << endl;
	system("PAUSE");
	return 0;
}


#endif
