/*
DOCUMENT CODE "SegmentTree.cpp"
CREATION DATE 2016-12-25
SIGNATURE CODE_20161225_SEGMENTTREE
TOPIC �߶���
MODIFY DATES 2016-12-25
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161225_SEGMENTTREE

#include <cstdlib>
#include <iostream>

using namespace std;

class SegmentTree {
public:
	struct st {
		int Max;
		int lazy;
		int left, right;
		st* lson, *rson;
	};
	//static st pool[100001];
	//static int top;
	static st* newNode() {
		//return &pool[++top];
		return new st();
	}
	void create(int n, int* data) { /*top = 0;*/ root = _create(n, data, 1, n); }
	st* _create(int n, int* data, int left, int right) {
		st* tmp = newNode();
		tmp->lazy = 0;
		tmp->left = left;
		tmp->right = right;
		if (left == right) {
			tmp->Max = data[left];
			tmp->lson = tmp->rson = NULL;
		}
		else {
			tmp->lson = _create(n, data, left, (left + right) / 2);
			tmp->rson = _create(n, data, (left + right) / 2 + 1, right);
			tmp->Max = max(tmp->lson->Max, tmp->rson->Max);
		}
		return tmp;
	}
	void pushDown(st* p) {
		if (p == NULL)
			return;
		p->Max += p->lazy;
		if (p->lson != NULL)
			p->lson->lazy += p->lazy;
		if (p->rson != NULL)
			p->rson->lazy += p->lazy;
		p->lazy = 0;
	}
	int query(int left, int right) { return _query(left, right, root); }
	int _query(int left, int right, st* p) {
		if (p->left == left&&p->right == right) {
			return p->Max;
		}
		pushDown(p);
		pushDown(p->lson);
		pushDown(p->rson);
		if (p->lson->right >= right)
			return _query(left, right, p->lson);
		else if (p->rson->left <= left)
			return _query(left, right, p->rson);
		else {
			return max(_query(left, p->lson->right, p->lson),
				_query(p->rson->left, right, p->rson));
		}
	}
	void change(int left, int right, int add) { _change(left, right, add, root); }
	void _change(int left, int right, int add, st* p) {
		if (p->left == left&&p->right == right) {
			p->lazy += add;
			return;
		}
		pushDown(p);
		pushDown(p->lson);
		pushDown(p->rson);
		if (p->lson->right >= right)
			_change(left, right, add, p->lson);
		else if (p->rson->left <= left)
			_change(left, right, add, p->rson);
		else {
			_change(left, p->lson->right, add, p->lson);
			_change(p->rson->left, right, add, p->rson);
		}
		p->Max = max(p->lson->Max + p->lson->lazy, p->rson->Max + p->rson->lazy);
	}

	int n;
	st* root;
};

int main(int argc, char* argv[]) {
	system("PAUSE");
	return 0;
}

#endif
