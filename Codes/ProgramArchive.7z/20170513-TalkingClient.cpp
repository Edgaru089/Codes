/*
DOCUMENT CODE "TalkingClient.cpp"
CREATION DATE 2017-05-13
SIGNATURE CODE_20170513_TALKINGCLIENT
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170513_TALKINGCLIENT

#include <cstdlib>
#include <iostream>
#include <SFML/Network.hpp>
#include <thread>
using namespace std;
using namespace sf;

TcpSocket mainSocket;
bool connected;
IpAddress target;
unsigned short port;

void listener() {
	Packet pack;
	string name, content;
	while (connected&&mainSocket.receive(pack) != Socket::Disconnected) {
		pack >> name >> content;
		cout << "\r" << name << ": " << content << endl << " > ";
	}
	connected = false;
}

int main(int argc, char* argv[]) {
	string ips;
	string username, id;
	cout << "Starting..." << endl;
	cout << "Username: ";
	cin >> username;
	cout << "Identifier: ";
	cin >> id;
	cout << "Target Address: ";
	cin >> ips;
	target = IpAddress(ips);
	cout << "Port: ";
	cin >> port;
	if (mainSocket.connect(target, port, seconds(10)) == Socket::Error) {
		TcpListener listen;
		listen.listen(port);
		listen.accept(mainSocket);
		listen.close();
	}
	connected = true;
	Packet pack;
	pack << username << id;
	mainSocket.send(pack);
	thread listen(listener);
	while (connected) {
		getline(cin, ips);
		cout << " > ";
		if (ips == "disconnect") {
			connected = false;
			mainSocket.disconnect();
		}
		pack.clear();
		pack << username << ips;
		if (mainSocket.send(pack) == Socket::Disconnected)
			connected = false;
	}
	system("PAUSE");
	return 0;
}

#endif
