/*
DOCUMENT CODE "noi2006d1t1.cpp"
CREATION DATE 2017-02-11
SIGNATURE CODE_20170211_NOI2016D1T1
TOPIC �����շ� network
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170211_NOI2016D1T1

#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <utility>

using namespace std;

#define rep(i,a,b) for(int i=a,tt=b;i<=tt;++i)  
#define drep(i,a,b) for(int i=a,tt=b;i>=tt;--i)  
#define erep(i,e,x) for(int i=x;i;i=e[i].next)  
#define irep(i,x) for(__typedef(x.begin()) i=x.begin();i!=x.end();i++)  
#define read() (strtol(ipos,&ipos,10))  
#define sqr(x) ((x)*(x))  
#define pb push_back  
#define PS system("pause");  
typedef long long ll;
typedef pair<int, int> pii;
const int oo = ~0U >> 1;
const double inf = 1e100;
const double eps = 1e-6;

int n, m, ans = oo;
int c[1100], flow[1100][1100], cost[1100][1100], fa[1100][1100];
bool type[1100];
struct T
{
	int v[2100], base;
	int& operator ()(int i, int j) { return v[i*base + j]; }
}f[2100];
void Init()
{
	scanf("%d", &n); m = 1 << n; int a;
	rep(i, 1, m)scanf("%d", &a), type[i] = a == 0;
	rep(i, 1, m)scanf("%d", c + i);
	rep(i, 1, m)
		rep(j, i + 1, m)
		scanf("%d", &a), flow[i][j] = flow[j][i] = a;
}
int Calc(int x, int j, int k)
{
	int ca = 0, cb = 0;
	rep(i, 1, n)
	{
		if (k & 1) ca += cost[i][x];
		else    cb += cost[i][x];
		k >>= 1;
	}
	if (j)return ca + (type[x] ? 0 : c[x]);
	else return cb + (type[x] ? c[x] : 0);
}
int TDP(int i, int j, int k, int h)
{
	int ret = f[i](j, k);
	if (ret)return ret;
	if (h)
	{
		ret = oo;
		int tmp, now, ls, tk;
		now = j<((1 << h) - j);
		tk = (k << 1) + now;
		ls = 1 << h - 1;
		for (int l = j - ls<0 ? 0 : j - ls; l <= j&&l <= ls; l++)
		{
			tmp = TDP(i << 1, l, tk, h - 1) + TDP(i << 1 ^ 1, j - l, tk, h - 1);
			ret = min(ret, tmp);
		}
	}
	else ret = Calc(i - m + 1, j, k);
	f[i](j, k) = ret;
	return ret;
}
void Work()
{
	rep(i, 1, m)
	{
		int k = i + m - 1;
		rep(j, 1, n) { k >>= 1; fa[j][i] = k; }
	}
	rep(i, 1, n + 1)
		rep(j, 1 << i - 1, (1 << i) - 1)f[j].base = 1 << i - 1;
	rep(i, 1, m)rep(j, i + 1, m)rep(k, 1, n)
		if (fa[k][i] == fa[k][j])
		{
			cost[k][i] += flow[i][j],
				cost[k][j] += flow[i][j];
			break;
		}
	rep(i, 0, m)
		ans = min(ans, TDP(1, i, 0, n));
	cout << ans << endl;
}
int main()
{
	Init();
	Work();
	return 0;
}

#endif
