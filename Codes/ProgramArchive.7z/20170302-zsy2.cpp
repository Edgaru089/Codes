/*
 DOCUMENT CODE "zsy2.cpp"
 CREATION DATE 2017-03-02
 SIGNATURE CODE_20170302_ZSY2
 TOPIC һ������0����1������ �������һ��1��λ��
 */

#include "Overall.hpp"

#ifdef CODE_20170302_ZSY2

#include <cstdlib>
#include <iostream>
using namespace std;

int n, a[1000001];

int main(int argc, char* argv[]) {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	int left = 1, right = n;
	while (left < right - 1) {
		int mid = (left + right) / 2;
		if (a[mid] == 1)
			right = mid;
		else
			left = mid;
	}
	if (a[left] == 1)
		cout << left << endl;
	else
		cout << right << endl;
	system("PAUSE");
	return 0;
}

#endif
