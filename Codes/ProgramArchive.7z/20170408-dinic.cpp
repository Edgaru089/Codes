/*
DOCUMENT CODE "dinic.cpp"
CREATION DATE 2017-04-08
SIGNATURE CODE_20170408_DINIC
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170408_DINIC

#include <cstdlib>
#include <iostream>
using namespace std;

struct node {
	int v, len;
	node* next,*reverse;
};

int top;
node pool[100001], *h[10001];
int level[10001];

int n, m;

void addedge(int u, int v, int len) {
	node* p = &pool[++top], *q = &pool[++top];
	p->v = v; p->len = len; p->reverse = q; p->next = h[u]; h[u] = p;
	q->v = u; q->len = 0; q->reverse = p; q->next = h[v]; h[v] = q;
}

void makelevel(int i) {
	level[i] = 1;
	for (int i = 1; i <= n; i++) {
		
	}
}



int main(int argc, char* argv[]) {
	cin >> n >> m;
	int u, v, len;
	for (int i = 1; i <= n; i++) {
		cin >> u >> v >> len;
		addedge(u, v, len);
	}
	system("PAUSE");
	return 0;
}

#endif
