/*
DOCUMENT CODE "zsy2-2.cpp"
CREATION DATE 2017-01-12
SIGNATURE CODE_20170112_ZSY2_2
TOPIC ��N������ѡ��K���� ʹ���ܺʹ��ڵ���M
N<=1000   K<=N               M<=100
����1	N=3 K=2 M=4
A[]={1, 2, 3}
��		Count=2
����2	N=5 K=3 M=7
A[]={1, 2, 3, 4, 5}
��		Count=2

TODO: δ��ɵĴ���
δ��� ���д���
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170112_ZSY2_2

#include <cstdlib>
#include <iostream>

using namespace std;

int n, k, m;
int a[1001];
int mem[1001][101][101];

int dfs(int sum, int p, int count) {
	if (mem[sum][p][count] >= 0)
		return mem[sum][p][count];
	else if (sum >= m&&count == k)
		return 1;
	else if ((count >= k&&sum < m) || p >= n)
		return 0;
	else
		return dfs(sum, p + 1, count) + dfs(sum + a[p], p + 1, count + 1);
}

int main(int argc, char* argv[]) {
	memset(mem, -1, sizeof(mem));
	cin >> n >> k >> m;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	cout << dfs(0, 1, 0) << endl;
	system("PAUSE");
	return 0;
}

#endif
