/*
DOCUMENT NAME "20180702-luogu2146.cpp"
CREATION DATE 2018-07-02
SIGNATURE CODE_20180702_LUOGU2146
COMMENT
*/

#include "Overall.hpp"

// Check if this code file is enabled for testing
#ifdef CODE_20180702_LUOGU2146

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {

	return 0;
}

#endif

