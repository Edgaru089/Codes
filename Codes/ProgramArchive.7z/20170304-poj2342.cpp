/*
 DOCUMENT CODE "poj2342.cpp"
 CREATION DATE 2017-03-04
 SIGNATURE CODE_2017_POJ2342
 TOPIC Anniversary party
 */

#include "Overall.hpp"

#ifdef CODE_2017_POJ2342

#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>
using namespace std;
long long dp[6666][2];
int cnt;
int head[6666];
int v[6666];
int in[6666];
struct edge
{
	int to, next;
}E[6666];
void addedge(int from, int to)
{
	E[cnt].to = to;
	E[cnt].next = head[from];
	head[from] = cnt++;
}
void dfs(int now)
{
	for (int i = head[now]; i != -1; i = E[i].next)
	{
		int to = E[i].to;
		dfs(to);
		dp[now][0] += max(dp[to][1], dp[to][0]);
		dp[now][1] += dp[to][0];
	}
	return;
}
int main()
{
	int N;
	ios::sync_with_stdio(false);
	cin >> N;
	memset(dp, 0, sizeof(dp));
	for (int i = 1; i <= N; i++)
		cin >> dp[i][1];
	int a, b;
	cnt = 0;
	memset(head, -1, sizeof head);
	long long start = N*(N + 1) / 2;
	while (cin >> a >> b &&a != 0 && b != 0)
	{
		addedge(b, a);
		start -= (long long)a;
	}
	dfs((int)start);
	cout << max(dp[start][1], dp[start][0]) << endl;
	system("PAUSE");
}

#endif
