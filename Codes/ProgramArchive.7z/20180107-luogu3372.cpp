/*
DOCUMENT CODE "20180107-luogu3372.cpp"
CREATION DATE 2018-01-07
SIGNATURE CODE_20180107_LUOGU3372
TOPIC �߶��� 1
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20180107_LUOGU3372

#include <cstdlib>
#include <iostream>
using namespace std;

struct st {
	int left, right;
	long long sum, lazy;
	st* lson, *rson;
};

st pool[200002], *root;
int top;



int main(int argc, char* argv[]) {

	return 0;
}

#endif

