/*
DOCUMENT CODE "AscendingSubSequence.cpp"
CREATION DATE 2016-12-15
SIGNATURE CODE_20161215_ASCENDINGSEQUENCE
TOPIC �����������
MODIFY DATES 2016-12-15
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161215_ASCENDINGSEQUENCE

#include <cstdlib>
#include <iostream>

using namespace std;

int n, a[1001];
int mem[1001];

int dfs(int i) {
	if (mem[i] >= 0)
		return mem[i];
	int Max = 0;
	for (int j = i + 1; j <= n; j++) {
		if (a[j] > a[i])
			Max = max(Max, dfs(j) + 1);
	}
	return mem[i] = Max;
}

int main(int argc, char* argv[]) {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	memset(mem, -1, sizeof(mem));
	cout << dfs(0) << endl;
	system("PAUSE");
	return 0;
}

#endif
