/*
DOCUMENT CODE "ChunkyList.cpp"
CREATION DATE 2017-05-18
SIGNATURE CODE_20170518_CHUNKYLIST
TOPIC ��״����
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170518_CHUNKYLIST

#include <cstdlib>
#include <iostream>
#include <vector>
#include <list>
using namespace std;

template<typename Type>
class ChunkyList {
public:

	struct Chunk {
		vector<Type> data;
		int leading, ending;
	};

	ChunkyList() {data.push_back()}

	void insert(Type x, int pos) {
		for (list<Chunk>::iterator i = data.begin()); i != data.end();){

}
	}

private:

	Chunk _getEmptyChunk() {
		Chunk c;
	}

private:
	list<Chunk> data;
	int size;
};

int main(int argc, char* argv[]) {
	system("PAUSE");
	return 0;
}

#endif
