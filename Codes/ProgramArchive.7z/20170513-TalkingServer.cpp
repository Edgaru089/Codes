/*
DOCUMENT CODE "TalkingServer.cpp"
CREATION DATE 2017-05-13
SIGNATURE CODE_20170513_TALKINGSERVER
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170513_TALKINGSERVER

#include <cstdlib>
#include <iostream>
#include <SFML/Network.hpp>
#include <thread>
#include <mutex>
#include <list>
using namespace std;
using namespace sf;

struct Connection {
	Connection(){}
	Connection(TcpSocket* Sock, string& Username, string& identifier) {
		sock = Sock;
		username = Username;
		this->identifier = identifier;
	}
	TcpSocket* sock;
	string username, identifier;
};

recursive_mutex connLock;
list<Connection> conns;
bool isListening;

void threadReceive(Connection conn) {
	Packet pack;
	while (conn.sock->receive(pack) != Socket::Disconnected) {
		connLock.lock();
		
	}
}

void threadListen(int port) {
	isListening = true;
	TcpListener listen;
	listen.listen(port);
	TcpSocket* sock;
	while (isListening) {
		sock = new TcpSocket();
		listen.accept(*sock);
		Packet pack;
		sock->receive(pack);
		string username, identifier;
		pack >> username >> identifier;
		connLock.lock();
		conns.push_back(Connection(sock, username, identifier));
		connLock.unlock();
	}
}

int main(int argc, char* argv[]) {
	int port;
	cout << "Target Port: ";
	cin >> port;
	cout << "Starting..." << endl;
	return 0;
}

#endif
