/*
DOCUMENT CODE "bzoj3173.cpp"
CREATION DATE 2017-01-01
SIGNATURE CODE_20170101_BZOJ3173
TOPIC BZOJ3173: [Tjoi2013]�����������
MODIFY DATES 2017-01-01
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170101_BZOJ3173

#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<string>
#include<cmath>
#include<ctime>
#include<queue>
#include<stack>
#include<map>
#include<set>
#define rre(i,r,l) for(int i=(r);i>=(l);i--)
#define re(i,l,r) for(int i=(l);i<=(r);i++)
#define Clear(a,b) memset(a,b,sizeof(a))
#define inout(x) printf("%d",(x))
#define douin(x) scanf("%lf",&x)
#define strin(x) scanf("%s",(x))
#define LLin(x) scanf("%lld",&x)
#define op operator
#define CSC main
typedef unsigned long long ULL;
typedef const int cint;
typedef long long LL;
using namespace std;
cint inf = 2147483647;
void inin(int &ret)
{
	ret = 0; int f = 0; char ch = getchar();
	while (ch<'0' || ch>'9') { if (ch == '-')f = 1; ch = getchar(); }
	while (ch >= '0'&&ch <= '9')ret *= 10, ret += ch - '0', ch = getchar();
	ret = f ? -ret : ret;
}
int ch[100010][2], r[100010], s[100010], ed, root;
void maintain(int k) { if (k)s[k] = 1 + s[ch[k][0]] + s[ch[k][1]]; }
void rotate(int &k, int d) { int p = ch[k][d ^ 1]; ch[k][d ^ 1] = ch[p][d], ch[p][d] = k; maintain(k), maintain(p); k = p; }
void add(int &k, int x)
{
	if (!k)
	{
		k = ++ed; s[k] = 1; r[k] = rand();
		return;
	}
	s[k]++;
	if (s[ch[k][0]]<x)
	{
		add(ch[k][1], x - s[ch[k][0]] - 1);
		if (r[ch[k][1]]<r[k])rotate(k, 0);
	}
	else
	{
		add(ch[k][0], x);
		if (r[ch[k][0]]<r[k])rotate(k, 1);
	}
}
int a[100010], tot;
void dfs(int x)
{
	if (!x)return;
	dfs(ch[x][0]);
	a[++tot] = x;
	dfs(ch[x][1]);
}
int b[100010], ans[100010], Max;
int CSC()
{
	int n;
	inin(n);
	re(i, 1, n) { int x; inin(x); add(root, x); }
	dfs(root);
	Clear(b, 127);
	b[0] = -inf;
	for (int i = 1; i <= n; i++)
	{
		int t = upper_bound(b, b + Max + 1, a[i]) - b;
		if (b[t - 1] <= a[i])
		{
			b[t] = min(b[t], a[i]);
			ans[a[i]] = t;
			Max = max(t, Max);
		}
	}
	re(i, 1, n)
	{
		ans[i] = max(ans[i], ans[i - 1]);
		printf("%d\n", ans[i]);
	}
	system("PAUSE");
	return 0;
}

#endif
