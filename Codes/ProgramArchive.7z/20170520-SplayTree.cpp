/*
DOCUMENT CODE "SplayTree.cpp"
CREATION DATE 2017-05-20
SIGNATURE CODE_20170520_SPLAYTREE
TOPIC Splay Tree
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170520_SPLAYTREE

#include <cstdlib>
#include <iostream>
using namespace std;

struct node {
	node* lson, *rson;
	node* parent;
	int x;
	int sum;
};

node pool[100001], *root;
int top;

void updateSum(node* p);
void leftRotate(node* p);
void rightRotate(node* p);
void insert(int x, node* p, node* parent);
void deleteNode(node* p);
void splay(node* p, node* target);      //Splayed as a child of target; NULL means root
node* findNode(int x, node* p);

bool find(int x, node* p);
int getSum(int start, int end);

int main(int argc, char* argv[]) {

	return 0;
}

void updateSum(node* p) {
	p->sum = p->lson->sum + p->rson->sum;
}

void rightRotate(node* p) {
	node* parent = p->parent;
	node* rson = p->rson;
	parent->lson = rson;
	rson->parent = parent;
	p->rson = parent;
	parent->parent = p;
	updateSum(p);
	updateSum(parent);
}

void leftRotate(node* p) {
	node* parent = p->parent;
	node* lson = p->lson;
	parent->rson = lson;
	lson->parent = parent;
	p->lson = parent;
	parent->parent = p;
	updateSum(p);
	updateSum(parent);
}

void insert(int x, node* p = root, node* parent = NULL) {
	if (p == NULL) {
		p = &pool[++top];
		p->x = x;
		p->lson = p->rson = NULL;
		p->parent = parent;
		p->sum = p->x;
		splay(p);
	}
	else if (x < p->x) {
		p->sum += x;
		insert(x, p->lson, p);
	}
	else {  //  x >= p->x
		p->sum += x;
		insert(x, p->rson, p);
	}
}

void deleteNode(int x, node* p = root) {
	if (p->x == x) {
		insert(x);
	}
	else if (x < p->x)
		deleteNode(x, p->lson);
	else  //  x >= p->x
		deleteNode(x, p->rson);
}

void splay(node* p, node* target = NULL) {
	while (p->parent != target) {
		if (p->parent->parent == target) {
			if (p->parent->lson == p)		//Zig
				rightRotate(p);
			else if (p->parent->rson == p)	//Zag
				leftRotate(p);
		}
		else if (p->parent->lson == p&&p->parent->parent->lson == p->parent) {	//Zig-Zig
			rightRotate(p);
			rightRotate(p);
		}
		else if (p->parent->rson == p&&p->parent->parent->rson == p->parent) {	//Zag-Zag
			leftRotate(p);
			leftRotate(p);
		}
		else if (p->parent->lson == p&&p->parent->parent->rson == p->parent) {	//Zig-Zag
			rightRotate(p);
			leftRotate(p);
		}
		else if (p->parent->rson == p&&p->parent->parent->lson == p->parent) {	//Zag-Zig
			leftRotate(p);
			rightRotate(p);
		}
	}
}

node* findNode(int x, node* p = root) {
	if (p == NULL)
		return NULL;
	else if (p->x == x)
		return p;
	else if (x < p->x)
		return findNode(x, p->lson);
	else  //  x >= p->x
		return findNode(x, p->rson);
}

bool find(int x, node* p) {
	if (p == NULL)
		return false;
	else if (p->x == x)
		return true;
	else if (x < p->x)
		return find(x, p->lson);
	else  //  x >= p->x
		return find(x, p->rson);
}

int getSum(int start, int end) {
	splay(findNode(start), NULL);
	splay(findNode(end + 1), root);
	return findNode(end + 1)->lson->sum + start;
}

#endif
