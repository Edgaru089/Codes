/*
DOCUMENT CODE "gcd.cpp"
CREATION DATE 2017-01-05
SIGNATURE CODE_20170105_GCD
TOPIC ���Լ��
MODIFY DATES 2017-01-05
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170105_GCD

#include <cstdlib>
#include <iostream>

using namespace std;

int gcd(int m, int n) {
	if (n != 1)
		return gcd(n, m%n);
	else
		return m;
}

int main(int argc, char* argv[]) {
	int a, b;
	cin >> a >> b;
	cout << gcd(a, b) << endl;
	system("PAUSE");
	return 0;
}

#endif
