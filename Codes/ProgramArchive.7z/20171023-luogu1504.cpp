/*
DOCUMENT CODE "luogu1504.cpp"
CREATION DATE 2017-10-23
SIGNATURE CODE_20171023_LUOGU1504
TOPIC P1504 ��ľ�Ǳ�
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20171023_LUOGU1504

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {
	 
	return 0;
}

#endif
