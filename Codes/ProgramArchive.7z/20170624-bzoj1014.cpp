/*
DOCUMENT CODE "bzoj1014.cpp"
CREATION DATE 2017-06-24
SIGNATURE CODE_20170624_BZOJ1014
TOPIC [JSOI2008]������prefix
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170624_BZOJ1014

#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<iostream>

using namespace std;

template<typename Q> Q read(Q& x) {
	static char c, f;
	for (f = 0; c = getchar(), !isdigit(c); ) if (c == '-') f = 1;
	for (x = 0; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	if (f) x = -x;
	return x;
}
template<typename Q> Q read() {
	static Q x; read(x); return x;
}

typedef unsigned uLL;
const int N = 150000 + 10;

uLL powers[N];

struct Node *null, *pis;
struct Node {
	int v, sz;
	uLL h;
	Node *ch[2];

	Node(int v = 0) : v(v) {
		h = v;
		sz = 1;
		ch[0] = ch[1] = null;
	}

	int size() const {
		return this ? sz : 0;
	}

	void maintain() {
		sz = ch[0]->sz + ch[1]->sz + 1;
		h = ch[0]->h * powers[ch[1]->sz + 1] + (uLL)v * powers[ch[1]->sz] + ch[1]->h;
	}

	int cmp(int k) const {
		int s = ch[0]->sz + 1;
		if (s == k) return -1;
		return k < s ? 0 : 1;
	}

	void *operator new(size_t) {
		return pis++;
	}
}pool[N], *root;

void rotate(Node *&o, int d) {
	Node *t = o->ch[d];
	o->ch[d] = t->ch[d ^ 1];
	t->ch[d ^ 1] = o;
	o->maintain();
	(o = t)->maintain();
}

void splay(Node *&o, int k) {
	int d = o->cmp(k);
	if (d == -1) return;
	if (d == 1) k -= o->ch[0]->sz + 1;
	Node *&c = o->ch[d];
	int d2 = c->cmp(k);
	if (d2 != -1) {
		if (d2 == 1) k -= c->ch[0]->sz + 1;
		splay(c->ch[d2], k);
		if (d == d2) rotate(o, d);
		else rotate(c, d2);
	}
	rotate(o, d);
}

void split(Node *o, int k, Node *&l, Node *&r) {
	splay(o, k);
	l = o;
	r = o->ch[1];
	o->ch[1] = null;
	o->maintain();
}

Node *merge(Node *l, Node *r) {
	splay(l, l->sz);
	l->ch[1] = r;
	return l->maintain(), l;
}

char s[N];

void build(Node*& o, int l, int r) {
	if (l > r) return o = null, void();
	int mid = (l + r) >> 1;
	o = new Node(s[mid]);
	build(o->ch[0], l, mid - 1);
	build(o->ch[1], mid + 1, r);
	o->maintain();
}

void splay_init() {
	pis = pool;
	null = new Node(0);
	null->ch[0] = null->ch[1] = null;
	null->sz = 0;
}

Node *segment(int l, int r) {
	splay(root, l);
	splay(root->ch[1], r + 1);
	return root->ch[1]->ch[0];
}

void update() {
	root->ch[1]->ch[0]->maintain();
	root->ch[1]->maintain();
	root->maintain();
}

void print(Node *o) {
	if (o == null) return;
	print(o->ch[0]);
	fprintf(stderr, "%c", (char)o->v);
	print(o->ch[1]);
}

const uLL xx[] = { 53, 1313, 1003 };

int main() {
	powers[0] = 1;
	for (int j = 1; j < N; j++) powers[j] = powers[j - 1] * 1313;

	scanf("%s", s + 1);
	int n = strlen(s + 1);

	splay_init();
	build(root, 0, n + 1);

	char opt[10];
	int m, x, y;
	scanf("%d", &m);
	while (m--) {
		scanf("%s%d", opt, &x);
		if (opt[0] == 'Q') {
			scanf("%d", &y);
			int L = 1, R = n - max(x, y) + 1, res = 0;
			while (L <= R) {
				int mid = (L + R) >> 1;
				static uLL tmp;
				tmp = segment(x, mid)->h;
				if (tmp == segment(y, mid)->h)
					res = mid, L = mid + 1; else R = mid - 1;
			}
			printf("%d\n", res);
		}
		else if (opt[0] == 'R') {
			scanf("%s", opt);
			segment(x, 1)->v = opt[0];
			update();
			//            print(root);
		}
		else {
			scanf("%s", opt);
			static Node *lft, *rgt;
			split(root, x + 1, lft, rgt);
			root = merge(merge(lft, new Node(opt[0])), rgt);
			n++;
		}
	}

	return 0;
}

#endif
