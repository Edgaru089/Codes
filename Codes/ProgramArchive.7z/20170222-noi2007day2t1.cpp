
#include <cstdio>  
#include <algorithm>  

using namespace std;

const int maxN = 1000010;
int col[maxN], n, C, T;

class SegTree
{
private:
	struct Node { int L, R, col, cnt, colL, colR; } tr[maxN];
	int lc[maxN], rc[maxN], tot, st, dir;
	int pos(int x) { return (st + dir * (x - 1) + n - 1) % n + 1; }
	void passdown(int p)
	{
		tr[lc[p]].col = tr[rc[p]].col
			= tr[lc[p]].colL = tr[lc[p]].colR
			= tr[rc[p]].colL = tr[rc[p]].colR = tr[p].col;
		tr[lc[p]].cnt = tr[rc[p]].cnt = 1;
		return;
	}
	void update(Node &ths, Node &lc, Node &rc)
	{
		ths.colL = lc.colL; ths.colR = rc.colR;
		if (lc.col == rc.col) ths.col = lc.col; else ths.col = -1;
		ths.cnt = lc.cnt + rc.cnt - (lc.colR == rc.colL);
		return;
	}
	void build(int L, int R)
	{
		int p = ++tot; tr[p].L = L, tr[p].R = R;
		if (L == R)
		{
			tr[p].colL = tr[p].colR = tr[p].col = col[L];
			tr[p].cnt = 1; return;
		}
		int Mid = (L + R) >> 1;
		lc[p] = tot + 1; build(L, Mid);
		rc[p] = tot + 1; build(Mid + 1, R);
		update(tr[p], tr[lc[p]], tr[rc[p]]); return;
	}
	int color(int p, int x)
	{
		if (tr[p].L <= x && tr[p].R >= x && tr[p].col > -1) return tr[p].col;
		int Mid = (tr[p].L + tr[p].R) >> 1;
		return color((x <= Mid) ? lc[p] : rc[p], x);
	}
	void chg(int p, int x, int c)
	{
		if (tr[p].L == tr[p].R && tr[p].L == x)
		{
			tr[p].col = tr[p].colL = tr[p].colR = c, tr[p].cnt = 1; return;
		}
		if (tr[p].col > -1) passdown(p), tr[p].col = -1; //  
		int Mid = (tr[p].L + tr[p].R) >> 1;
		chg((x <= Mid) ? lc[p] : rc[p], x, c);
		update(tr[p], tr[lc[p]], tr[rc[p]]); return;
	}
	void paint(int p, int L, int R, int c)
	{
		if (L <= tr[p].L && R >= tr[p].R)
		{
			tr[p].col = tr[p].colL = tr[p].colR = c, tr[p].cnt = 1; return;
		}
		int Mid = (tr[p].L + tr[p].R) >> 1;
		if (tr[p].col > -1) passdown(p), tr[p].col = -1;
		if (L <= Mid) paint(lc[p], L, R, c);
		if (Mid < R) paint(rc[p], L, R, c);
		update(tr[p], tr[lc[p]], tr[rc[p]]); return;
	}
	Node query(int p, int L, int R)
	{
		if (L <= tr[p].L && R >= tr[p].R) return tr[p];
		if (tr[p].col > -1) passdown(p);
		int Mid = (tr[p].L + tr[p].R) >> 1;
		if (R <= Mid) return query(lc[p], L, R);
		if (Mid < L) return query(rc[p], L, R);
		Node _lc = query(lc[p], L, R), _rc = query(rc[p], L, R), ans;
		update(ans, _lc, _rc); return ans;
	}
public:
	SegTree() : tot(0), st(1), dir(1) {}
	void build() { build(1, n); return; }
	void Rot(int x) { st = (st - x * dir + n - 1) % n + 1; return; }
	void Flip() { dir = -dir; return; }
	void swap(int i, int j)
	{
		if (i == j) return; i = pos(i), j = pos(j);
		int ci = color(1, i), cj = color(1, j); if (ci == cj) return;
		chg(1, i, cj), chg(1, j, ci);
		return;
	}
	void paint(int L, int R, int c)
	{
		L = pos(L), R = pos(R); if (dir < 0) std::swap(L, R);
		if (L <= R) paint(1, L, R, c);
		else paint(1, L, n, c), paint(1, 1, R, c);
		return;
	}
	int query()
	{
		return std::max(1, query(1, 1, n).cnt - (tr[1].colL == tr[1].colR));
	}
	int query(int L, int R)
	{
		L = pos(L), R = pos(R); if (dir < 0) std::swap(L, R);
		if (L <= R) return query(1, L, R).cnt;
		else return std::max(1, query(1, L, n).cnt
			+ query(1, 1, R).cnt - (tr[1].colL == tr[1].colR));
	}
} Tr;

int main()
{
	scanf("%d%d", &n, &C);
	for (int i = 1; i < n + 1; ++i) scanf("%d", col + i);
	Tr.build(); scanf("%d", &T);
	for (int i, j, x; T--;) switch (scanf("\n"), getchar())
	{
	case 'R': scanf("%d", &x); Tr.Rot(x); break;
	case 'F': Tr.Flip(); break;
	case 'S': scanf("%d%d", &i, &j); Tr.swap(i, j); break;
	case 'P':
		scanf("%d%d%d", &i, &j, &x); Tr.paint(i, j, x); break;
	case 'C':
		if (getchar() == 'S')
		{
			scanf("%d%d", &i, &j);
			printf("%d\n", Tr.query(i, j));
		}
		else printf("%d\n", Tr.query());
		break;
	}
	return 0;
}