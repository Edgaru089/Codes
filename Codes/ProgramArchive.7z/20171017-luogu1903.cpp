/*
DOCUMENT CODE "luogu1903.cpp"
CREATION DATE 2017-10-17
SIGNATURE CODE_20171017_LUOGU1903
TOPIC ��ģ�塿�ֿ�/���޸�Ī�ӣ�����ɫ��
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20171017_LUOGU1903

#include <cstdlib>
#include <iostream>
using namespace std;

struct query {

};

int main(int argc, char* argv[]) {

	return 0;
}

#endif
