/*
 DOCUMENT CODE "FindCycleInGraph.cpp"
 CREATION DATE 2017-05-11
 SIGNATURE CODE_20170511_FINDCYCLEINGRAPH
 TOPIC ��һ��n����n���ߵ�ͼ���һ��ĳ��� 
 */

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170511_FINDCYCLEINGRAPH

#include <cstdlib>
#include <iostream>
using namespace std;

struct node {
	int v, len;
	node* next;
};

int top;
node pool[10001], *h[1001];
int n, m;

int visit[1001];
int ans;

void addedge(int u, int v, int len = 1) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->len = len;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[++top];
	tmp->v = u;
	tmp->len = len;
	tmp->next = h[v];
	h[v] = tmp;
}

void dfs(int u, int from) {
	if(ans!=0)
		return;
	visit[u]=visit[from]+1;
	for (node* p = h[u]; p != NULL; p = p->next) {
		int v = p->v;
		if(v==from)
			continue;
		if(visit[v]!=0){
			ans=visit[u]-visit[v]+1;
			return;
		}
		dfs(v,u);
		if(ans!=0)
			return;
	}
}

int main(int argc, char* argv[]) {
	cin>>n;
	m=n;
	int u,v;
	for(int i=1;i<=n;i++){
		cin>>u>>v;
		addedge(u,v);
	}
	dfs(1,0);
	if(ans==0)
		cout<<"FAILED"<<endl;
	else
		cout<<ans<<endl;
	system("PAUSE");
	return 0;
}

#endif
