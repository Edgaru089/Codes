/*
DOCUMENT NAME "20180907-luogu3953.cpp"
CREATION DATE 2018-09-07
SIGNATURE CODE_20180907_LUOGU3953
COMMENT [NOIP2017]�乫԰
*/

#include "Overall.hpp"

// Check if this code file is enabled for testing
#ifdef CODE_20180907_LUOGU3953

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {

	return 0;
}

#endif

