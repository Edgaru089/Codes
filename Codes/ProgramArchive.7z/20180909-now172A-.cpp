/*
 DOCUMENT NAME "20180909-now172A-.cpp"
 CREATION DATE 2018-09-09
 SIGNATURE CODE_20180909_NOW172A_
 COMMENT A-��λ�� / ����
*/

#include "Overall.hpp"

// Check if this code file is enabled for testing
#ifdef CODE_20180909_NOW172A_

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {
	


	return 0;
}

#endif

