/*
DOCUMENT CODE "openjudge1526.cpp"
CREATION DATE 2016-11-08
SIGNATURE CODE_20161108_OPENJUDGE1526
TOPIC ch0403 �ڽ�����
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20161108_OPENJUDGE1526

#include <cstdlib>
#include <iostream>
#include <cstring>

using namespace std;

struct node {
	int v;
	node* next;
};

int n, m;
node pool[300001], *h[100001];
int top;

int f[100001];

int Find(int x) {
	if (f[x] < 0)
		return x;
	else
		return f[x] = Find(f[x]);
}

void Union(int x, int y) {
	x = Find(x);
	y = Find(y);
	f[x] += f[y];
	f[y] = x;
}

void addedge(int u, int v) {
	node* tmp = &pool[++top];
	tmp->v = v;
	tmp->next = h[u];
	h[u] = tmp;
	tmp = &pool[++top];
	tmp->v = u;
	tmp->next = h[v];
	h[v] = tmp;
}

void search(int u) {
	for (node* p = h[u]; p != NULL; p = p->next) {
		int v = p->v;
		if (Find(u) != Find(v)) {
			Union(u, v);
			search(v);
		}
	}
}

int main(int argc, char* argv[]) {
	int u, v;
	int casen = 1;
	while (cin >> n >> m) {
		memset(f, -1, sizeof(f));
		memset(h, 0, sizeof(h));
		if (n == m&&m == 0)
			break;
		/*
		for (int i = 1; i <= n; i++) {
			if (f[i] < 0)
				search(i);
		}*/
		for (int i = 1; i <= m; i++) {
			cin >> u >> v;
			Union(u, v);
		}
		int sum = 0;
		for (int i = 1; i <= n; i++)
			if (f[i] < 0)
				sum++;
		cout << "Case " << casen << ": " << sum << endl;
		casen++;
	}
	system("PAUSE");
	return 0;
}

#endif
