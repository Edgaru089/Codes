/*
DOCUMENT CODE "poj2352.cpp"
CREATION DATE 201702009
SIGNATURE CODE_20170209_POJ2352
TOPIC Stars
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170209_POJ2352

#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#define MAXN 15005
#define MAXS 32005
using namespace std;
int f[MAXN];
int c[MAXS];
int n;
int lowbit(int x)
{
	return x&-x;
}
void add(int x, int d)
{
	while (x <= MAXS)
	{
		c[x] += d;
		x += lowbit(x);
	}
}
int sum(int x)
{
	int ret = 0;
	while (x>0)
	{
		ret += c[x];
		x -= lowbit(x);
	}
	return ret;
}
int main(void)
{
	int i, x, y;
	cin >> n;
	memset(c, 0, sizeof(c));
	memset(f, 0, sizeof(f));
	for (i = 1; i <= n; i++)
	{
		scanf("%d%d", &x, &y);
		x++;
		f[sum(x)]++;
		add(x, 1);
	}
	for (i = 0; i<n; i++)
		printf("%d\n", f[i]);
	return 0;
}

#endif
