/*
DOCUMENT CODE "poj2155.cpp"
CREATION DATE 2017-05-06
SIGNATURE CODE_20170506_POJ2155
TOPIC ��ά�߶���
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170506_POJ2155

#include <cstdlib>
#include <iostream>
using namespace std;

/*
	Node States
		0 Normal
			+-+-+-+
			+-+-+-+
			+-+-+-+
		1 Line   (lt == lb, rt == rb)
			+-+-+
			+-+-+
		2 Column (lt == rt, lb == rb)
			+-+
			+-+
			+-+
		3 Block  (lt == rt == lb == rb)
			+-+
			+-+
*/
#define STATE_NORMAL    0
#define STATE_LINE      1
#define STATE_COLUMN    2
#define STATE_BLOCK     3

struct st {
	int state;
	int leftTopX, rightBackX;
	int leftTopY, rightBackY;
	st* ltson, *rtson, *lbson, *rbson;
	int sum;
};

st pool[1000001], *root;
int top;

int d[1001][1001], n;


st* buildTree(int ltX, int ltY, int rbX, int rbY) {
	st* tmp = &pool[++top];
	tmp->leftTopX = ltX; tmp->leftTopY = ltY;
	tmp->rightBackX = rbX; tmp->rightBackY = rbY;
	int midX = (ltX + rbX) / 2, midY = (ltY + rbY) / 2;
	if (ltX == rbX&&ltY == rbY) {
		tmp->state = STATE_BLOCK;
		tmp->ltson = tmp->rtson = tmp->lbson = tmp->rbson = NULL;
		tmp->sum = d[ltX][ltY];
	}
	else if (ltX == rbX&&ltY != rbY) {
		tmp->state = STATE_LINE;
		tmp->ltson = tmp->lbson = buildTree(ltX, ltY, midX, midY);
		tmp->rtson = tmp->rbson = buildTree(midX + 1, midY + 1, rbX, rbY);
		tmp->sum = tmp->ltson->sum + tmp->rtson->sum;
	}
	else if (ltX != rbX&&ltY == rbY) {
		tmp->state = STATE_COLUMN;
		tmp->ltson = tmp->rtson = buildTree(ltX, ltY, midX, midY);
		tmp->rtson = tmp->rbson = buildTree(midX + 1, midY + 1, rbX, rbY);
		tmp->sum = tmp->ltson->sum + tmp->rtson->sum;
	}
	else {  //ltX != rbX && ltY != rbY
		tmp->state = STATE_NORMAL;
		tmp->ltson = buildTree(ltX, ltY, midX, midY);
		tmp->rtson = buildTree(ltX, midY + 1, midX, rbY);
		tmp->lbson = buildTree(midX + 1, ltY, rbX, midY);
		tmp->rbson = buildTree(midX + 1, midY + 1, rbX, rbY);
		tmp->sum = tmp->ltson->sum + tmp->rtson->sum +
			tmp->lbson->sum + tmp->rbson->sum;
	}
	return tmp;
}

void change(int ltX, int ltY, int rbX, int rbY, int add = 1, st* p = root) {
	if (p->leftTopX == ltX&&p->leftTopY == ltY&&
		p->rightBackX == rbX&&p->rightBackY == rbY) {
		p->sum += add;
		return;
	}
	//No pushBack required.
	if (rbX <= p->ltson->rightBackX&&rbY <= p->ltson->rightBackY)        //Left-top corner
		change(ltX, ltY, rbX, rbY, add, p->ltson);
	else if (rbX <= p->rtson->rightBackX&&ltY >= p->rtson->leftTopY)     //Right-top corner
		change(ltX, ltY, rbX, rbY, add, p->rtson);
	else if (ltX >= p->lbson->leftTopX&&rbY <= p->lbson->rightBackY)     //Left-back corner
		change(ltX, ltY, rbX, rbY, add, p->lbson);
	else if (ltX >= p->rbson->leftTopX&&ltY >= p->rbson->leftTopY)       //Right-back corner
		change(ltX, ltY, rbX, rbY, add, p->rbson);
	else if (rbY <= p->ltson->rightBackY) {                              //lt + lb
		change(ltX, ltY, p->ltson->rightBackX, rbY, add, p->ltson);
		change(p->lbson->leftTopX, ltY, rbX, rbY, add, p->lbson);
	}
	else if (rbX <= p->ltson->rightBackX) {                              //lt + rt
		change(ltX, ltY, rbX, p->ltson->rightBackY, add, p->ltson);
		change(ltX, p->rtson->leftTopY, rbX, rbY, add, p->rtson);
	}
	else if (ltY >= p->rtson->leftTopY) {                                //rt + rb
		change(ltX, ltY, p->rtson->rightBackX, rbY, add, p->rtson);
		change(p->rbson->leftTopX, ltY, rbX, rbY, add, p->rbson);
	}
	else if (ltX >= p->lbson->leftTopX) {                                //lb + rb
		change(ltX, ltY, rbX, p->rbson->rightBackY, add, p->lbson);
		change(ltX, p->lbson->leftTopY, rbX, rbY, add, p->rbson);
	}
	else {                                                               //lt + rt + lb + rb
		change(ltX, ltY, p->ltson->rightBackX, p->ltson->rightBackY, add, p->ltson);
		change(ltX, p->rtson->leftTopY, p->rtson->rightBackX, rbY, add, p->rtson);
		change(p->lbson->leftTopX, ltY, rbX, p->lbson->rightBackY, add, p->lbson);
		change(p->rbson->leftTopX, p->rbson->leftTopY, rbX, rbY, add, p->rbson);
	}
}

int main(int argc, char* argv[]) {
	system("PAUSE");
	return 0;
}

#endif
