/*
DOCUMENT NAME "20180814-bnds0760.cpp"
CREATION DATE 2018-08-14
SIGNATURE CODE_20180814_BNDS0760
COMMENT 2018-8-12noipģ����飨����-��������
*/

#include "Overall.hpp"

// Check if this code file is enabled for testing
#ifdef CODE_20180814_BNDS0760

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {

	return 0;
}

#endif

