/*
DOCUMENT CODE "poj3468.cpp"
CREATION DATE 2017-05-21
SIGNATURE CODE_20170521_POJ3468
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170521_POJ3468

#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

#define MAXN 101000
#define ll __int64

ll num[MAXN];

class SplayTree {
public:
	ll son[MAXN][2], parent[MAXN], value[MAXN], lazy[MAXN], size[MAXN], sum[MAXN];
	ll root, top;

	void AddNode(ll x, ll c) {
		if (x == 0) return;
		value[x] += c;
		lazy[x] += c;
		sum[x] += c*size[x];
	}
	void PushUp(ll x) {
		if (x == 0) return;
		size[x] = size[son[x][0]] + size[son[x][1]] + 1;
		sum[x] = value[x] + sum[son[x][0]] + sum[son[x][1]];
	}
	void PushDown(ll x) {
		if (x == 0) return;
		if (lazy[x]) {
			AddNode(son[x][0], lazy[x]);
			AddNode(son[x][1], lazy[x]);
			lazy[x] = 0;
		}
	}
	void Rotate(ll x, ll c) {
		ll y = parent[x];
		PushDown(y);
		PushDown(x);
		son[y][!c] = son[x][c];
		if (son[x][c]) parent[son[x][c]] = y;
		parent[x] = parent[y];
		if (parent[y]) son[parent[y]][son[parent[y]][1] == y] = x;
		son[x][c] = y;
		parent[y] = x;
		PushUp(y);
		if (y == root) root = x;
	}
	void Splay(ll x, ll f) {
		PushDown(x);
		while (parent[x] != f) {
			PushDown(parent[parent[x]]);
			PushDown(parent[x]);
			PushDown(x);
			if (parent[parent[x]] == f) Rotate(x, son[parent[x]][0] == x);
			else {
				ll y = parent[x], z = parent[y];
				ll c = (son[z][0] == y);
				if (son[y][c] == x) Rotate(x, !c), Rotate(x, c);
				else Rotate(y, c), Rotate(x, c);
			}
		}
		PushUp(x);
		if (f == 0) root = x;
	}
	void SplayKth(ll k, ll f) {
		ll x = root;
		k += 1;
		while (1) {
			PushDown(x);
			if (k == size[son[x][0]] + 1) break;
			else if (k <= size[son[x][0]]) x = son[x][0];
			else k -= size[son[x][0]] + 1, x = son[x][1];
		}
		Splay(x, f);
	}
	void NewNode(ll &x, ll c) {
		x = ++top;
		son[x][0] = son[x][1] = parent[x] = 0;
		size[x] = 1;
		lazy[x] = 0;
		sum[x] = value[x] = c;
	}
	void Build(ll &x, ll l, ll r, ll f) {
		if (l > r) return;
		ll m = (l + r) >> 1;
		NewNode(x, num[m]);
		Build(son[x][0], l, m - 1, x);
		Build(son[x][1], m + 1, r, x);
		parent[x] = f;
		PushUp(x);
	}
	void Init(ll n) {
		son[0][0] = son[0][1] = parent[0] = value[0] = lazy[0] = size[0] = sum[0] = 0;
		root = top = 0;
		for (ll i = 1; i <= n; i++) scanf("%I64d", &num[i]);
		Build(root, 0, n + 1, 0);
	}
	void Add(ll a, ll b, ll c) {
		SplayKth(a - 1, 0);
		SplayKth(b + 1, root);
		AddNode(son[son[root][1]][0], c);
	}
	void GetSum(ll a, ll b) {
		SplayKth(a - 1, 0);
		SplayKth(b + 1, root);
		printf("%I64d\n", sum[son[son[root][1]][0]]);
	}

}t;
int main() {
	ios::sync_with_stdio(false);
	ll n, m;
	while (cin >> n >> m) {
		t.Init(n);
		while (m--) {
			char op;
			ll a, b, c;
			scanf(" %c", &op);
			if (op == 'Q') {
				cin >> a >> b;
				t.GetSum(a, b);
			}
			else if (op == 'C') {
				cin >> a >> b >> c;
				t.Add(a, b, c);
			}
		}
	}
	return 0;
}

#endif
