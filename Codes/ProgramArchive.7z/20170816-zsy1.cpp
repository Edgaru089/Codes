/*
DOCUMENT CODE "zsy1.cpp"
CREATION DATE 2017-08-16
SIGNATURE CODE_20170816_ZSY1
TOPIC �� n/1��ȡ�� + n/2��ȡ�� + ... + n/n��ȡ��
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170816_ZSY1

#include <cstdlib>
#include <iostream>
#include <cmath>
using namespace std;

#define max(a,b) ((a)>(b)?(a):(b))

int n;
long long ans = 0;

int main(int argc, char* argv[]) {
	cin >> n;
	int m = sqrt(n);

	//��sqrt(n)���µĲ��ֱ������
	for (int i = 1; i < m; i++)
		ans += n / i;
	for (int i = 1; i <= m; i++)
		ans += (long long)(n / i - max(n / (i + 1), m))*i;
	if (m*m == n)
		ans -= m;




	return 0;
}

#endif
