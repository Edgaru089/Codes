/*
DOCUMENT NAME "20180717-luogu4752.cpp"
CREATION DATE 2018-07-17
SIGNATURE CODE_20180717_LUOGU4752
COMMENT
*/

#include "Overall.hpp"

// Check if this code file is enabled for testing
#ifdef CODE_20180717_LUOGU4752

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {

	return 0;
}

#endif

