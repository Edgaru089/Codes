/*
DOCUMENT CODE "bzoj1604.cpp"
CREATION DATE 2017-06-03
SIGNATURE CODE_20170603_BZOJ1604
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170603_BZOJ1604

#include <cstdio>
#include <algorithm>
#include <set>

using namespace std;
typedef long long ll;
const ll inf = (ll) 1e16;
const int N = 100005;

struct Data {
	Data() {}
	Data(ll x, ll y, int w) :x(x), y(y), w(w) {}
	ll x, y;
	int w;
}a[N];
inline bool operator < (const Data &a, const Data &b) {
	return a.y < b.y;
}
inline bool cmpx(const Data &a, const Data &b) {
	return a.x < b.x;
}

int fa[N], cnt[N], ans, ANS;
int n, c, X, Y;
multiset<Data> S;
set<Data>::iterator it;

int x;
char ch;
inline unsigned int read() {
	x = 0;
	ch = getchar();
	while (ch < '0' || ch > '9')
		ch = getchar();

	while (ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x;
}

int find_fa(int x) {
	return fa[x] == x ? x : fa[x] = find_fa(fa[x]);
}

inline void Union(int x, int y) {
	x = find_fa(x), y = find_fa(y);
	if (x != y)
		fa[x] = y, --ans;
}

void work() {
	for (int i = 1; i <= n; ++i)
		fa[i] = i;
	S.insert(Data(0, inf, 0));
	S.insert(Data(0, -inf, 0));
	S.insert(a[1]);
	int now = 1;
	Data l, r;
	for (int i = 2; i <= n; ++i) {
		while (a[i].x - a[now].x > c)
			S.erase(S.find(a[now++]));
		it = S.lower_bound(a[i]);
		r = *it, l = *--it;
		if (a[i].y - l.y <= c)
			Union(a[i].w, l.w);
		if (r.y - a[i].y <= c)
			Union(a[i].w, r.w);
		S.insert(a[i]);
	}
}

int main() {
	n = read(), c = read(), ans = n;
	for (int i = 1; i <= n; ++i) {
		X = read(), Y = read();
		a[i].x = X + Y, a[i].y = X - Y, a[i].w = i;
	}
	sort(a + 1, a + n + 1, cmpx);

	work();
	for (int i = 1; i <= n; ++i)
		++cnt[find_fa(i)];
	for (int i = 1; i <= n; ++i)
		ANS = max(ANS, cnt[i]);
	printf("%d %d\n", ans, ANS);
	return 0;
}

#endif
