/*
DOCUMENT CODE "noi2006d1t2.cpp"
CREATION DATE 2017-02-11
SIGNATURE CODE_20170211_NOI2006D1T2
TOPIC ���տ��� happybirthday
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170211_NOI2006D1T2

static const int maxN = 1000010;
class SBT
{
private:
	struct Node
	{
		long ID, num; Node() {} Node(long ID, long num) : ID(ID), num(num) {}
		bool operator<(const Node &b) const
		{
			return num < b.num || (num == b.num && ID > b.ID);
		}
		bool operator>(const Node &b) const { return b < *this; }
		bool operator<=(const Node &b) const { return !(b < *this); }
		bool operator>=(const Node &b) const { return !(*this < b); }
		bool operator==(const Node &b) const { return ID == b.ID && num == b.num; }
		bool operator!=(const Node &b) const { return ID != b.ID || num != b.num; }
	} key[maxN]; long sz[maxN]; int T, tot, lc[maxN], rc[maxN];
	void Zig(int &T)
	{
		int tmp = lc[T]; lc[T] = rc[tmp]; rc[tmp] = T;
		sz[tmp] = sz[T]; sz[T] = sz[lc[T]] + sz[rc[T]] + 1;
		T = tmp; return;
	}
	void Zag(int &T)
	{
		int tmp = rc[T]; rc[T] = lc[tmp]; lc[tmp] = T;
		sz[tmp] = sz[T]; sz[T] = sz[lc[T]] + sz[rc[T]] + 1;
		T = tmp; return;
	}
	void maintain(int &T, bool flag)
	{
		if (!T || (!lc[T] && !rc[T])) return;
		if (!flag)
		{
			if (sz[lc[lc[T]]] > sz[rc[T]]) Zig(T);
			else if (sz[rc[lc[T]]] > sz[rc[T]]) Zag(lc[T]), Zig(T);
			else return;
		}
		else
		{
			if (sz[rc[rc[T]]] > sz[lc[T]]) Zag(T);
			else if (sz[lc[rc[T]]] > sz[lc[T]]) Zig(rc[T]), Zag(T);
			else return;
		}
		maintain(lc[T], 0); maintain(rc[T], 1);
		maintain(T, 0); maintain(T, 1); return;
	}
	void Ins(int &T, Node v)
	{
		if (!T) { key[T = ++tot] = v, sz[T] = 1; return; }
		++sz[T]; Ins(v < key[T] ? lc[T] : rc[T], v);
		maintain(T, v >= key[T]); return;
	}
	Node Del(int &T, Node v)
	{
		--sz[T];
		if (v == key[T] || (v < key[T] && !lc[T]) || (v > key[T] && !rc[T]))
		{
			Node tmp = key[T];
			if (!lc[T] || !rc[T]) T = lc[T] + rc[T];
			else key[T] = Del(lc[T], key[T]);
			return tmp;
		}
		return Del(v < key[T] ? lc[T] : rc[T], v);
	}
	long Rank(Node v)
	{
		long ans = 0;
		for (int t = T; t;)
		{
			if (v == key[t]) return ans + sz[lc[t]] + 1;
			if (v > key[t]) ans += sz[lc[t]] + 1;
			t = v < key[t] ? lc[t] : rc[t];
		}
		return ans;
	}
	Node K_th(long k)
	{
		for (int t = T; t;)
		{
			if (k == sz[lc[t]] + 1) return key[t]; long tmp = k;
			if (k > sz[lc[t]]) k -= sz[lc[t]] + 1;
			t = tmp <= sz[lc[t]] ? lc[t] : rc[t];
		}
	}
public:
	SBT() : T(0), tot(0)
	{
		for (int i = 0; i < maxN; ++i) sz[i] = lc[i] = rc[i] = 0;
	}
	void Ins(long num, long ID) { Ins(T, Node(ID, num)); return; }
	long find(long num, long ID, long inc)
	{
		long tmp = Rank(Node(ID, num)) + inc;
		if (tmp < 1 || tmp > sz[T]) return -1;
		Node res = K_th(tmp); Del(T, res);
		if (res.num > 1) Ins(T, Node(res.ID, res.num - 1));
		return res.ID;
	}
} mp;

int main()
{
	init(); bool sex; long lucky, num, Now = 0;
	while (getpresent(num, lucky, sex))
	{
		mp.Ins(num, ++Now);
		tell(mp.find(num, Now, sex ? lucky : -lucky));
	}
	return 0;
}
#endif
