/*
DOCUMENT CODE "20180220-Chess.cpp"
CREATION DATE 2018-02-20
SIGNATURE CODE_20180220_CHESS
TOPIC
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20180220_CHESS

#include <cstdlib>
#include <iostream>

#include <SFML/Graphics.hpp>

using namespace std;
using namespace sf;



int main(int argc, char* argv[]) {

	return 0;
}

#endif

