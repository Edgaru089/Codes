/*
DOCUMENT CODE "ChairmanTree.cpp"
CREATION DATE 2017-08-08
SIGNATURE CODE_20170808_CHAIRMANTREE
TOPIC ��ϯ�����ɳ־û��߶�����
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170808_CHAIRMANTREE

#include <cstdlib>
#include <iostream>
using namespace std;

struct node {
	int l, r, s;
	node* lson, *rson;
};

const int MaxN = 120000;

node pool[MaxN * 2 + MaxN * 20], *t[MaxN];
int top;

int n, q;
int a[MaxN];

void buildTree(node* id, int l, int r) {
	id->l = l;
	id->r = r;
	if (l == r) {
		id->s = a[l];
		return;
	}
	int mid = (l + r) / 2;
	id->lson = &pool[++top];
	id->rson = &pool[++top];
	buildTree(id->lson, l, mid);
	buildTree(id->rson, mid + 1, r);
	id->s = id->lson->s + id->rson->s;
}

void add(node* id, node* idd, int l, int x) {
	id->l = idd->l;
	id->r = idd->r;
	if (id->l == id->r) {
		id->s = x;
		return;
	}
	int mid = (id->l + id->r) / 2;
	if (l <= mid) {
		id->rson = idd->rson;
		id->lson = &pool[++top];
		add(id->lson, idd->lson, l, x);
	}
	else {
		id->lson = idd->lson;
		id->rson = &pool[++top];
		add(id->rson, idd->rson, l, x);
	}
	id->s = id->lson->s + id->rson->s;
}

int query(node* id, int l, int r) {
	if (id->l == l&&id->r == r)
		return id->s;
	int mid = (id->l + id->r) / 2;
	if (r <= mid)
		return query(id->lson, l, r);
	else {
		if (l > mid)
			return query(id->rson, l, r);
		else
			return query(id->lson, l, mid) + query(id->rson, mid + 1, r);
	}
}

void work() {
	int tim, op, l, r;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	t[0] = &pool[++top];
	buildTree(t[0], 1, n);
	cin >> q;
	for (int i = 1; i <= q; i++) {
		cin >> op >> tim >> l >> r;
		if (op == 1) {
			t[i] = &pool[++top];
			add(t[i], t[tim], l, r);
		}
		else {
			cout << query(t[tim], l, r);
			t[i] = t[tim];
		}
	}
}


int main(int argc, char* argv[]) {
	work();

	return 0;
}

#endif
