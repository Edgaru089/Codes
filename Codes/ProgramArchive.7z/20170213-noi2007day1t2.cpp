/*
DOCUMENT CODE "noi2007day1t2.cpp"
CREATION DATE 2017-02-13
SIGNATURE CODE_20170213_NOI2007DAY1T2
TOPIC ���Ҷһ� Cash
TODO: δ��ɵĴ��� ֻ����60��
*/

#include "Overall.hpp"

//Check if this code file is enabled for testing.
#ifdef CODE_20170213_NOI2007DAY1T2

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>

#define inf 0x7fffffff
#define ll long long

using namespace std;

int n, s;
double a[100005], b[100005], rate[100005];
double f[100005], ans;

int main()
{
	scanf("%d%d", &n, &s);
	for (int i = 1; i <= n; i++)
		scanf("%lf%lf%lf", &a[i], &b[i], &rate[i]);
	ans = s;
	f[1] = s*rate[1] / (a[1] * rate[1] + b[1]);
	for (int i = 2; i <= n; i++)
	{
		for (int j = 1; j<i; j++)
			ans = max(ans, f[j] * a[i] + f[j] / rate[j] * b[i]);
		f[i] = ans*rate[i] / (a[i] * rate[i] + b[i]);
	}
	printf("%.3lf", ans);
	return 0;
}

#endif
