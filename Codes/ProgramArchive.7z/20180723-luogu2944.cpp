/*
DOCUMENT NAME "20180723-luogu2944.cpp"
CREATION DATE 2018-07-23
SIGNATURE CODE_20180723_LUOGU2944
COMMENT
*/

#include "Overall.hpp"

// Check if this code file is enabled for testing
#ifdef CODE_20180723_LUOGU2944

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {

	return 0;
}

#endif

