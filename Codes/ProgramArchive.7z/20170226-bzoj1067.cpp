/*
 DOCUMENT CODE "bzoj1067.cpp"
 CREATION DATE 2017-02-26
 SIGNATURE CODE_20170226_BZOJ1067
 TOPIC [POJ2637][SCOI2007]������
 */

#include "Overall.hpp"

#ifdef CODE_20170226_BZOJ1067

#include <cstdlib>
#include <iostream>
using namespace std;

struct request {
	int yearId, account;
};

struct node {
	int left, right;
	node* lson, *rson;
	int lazy, Max;
};

node pool[200001];
node* h[50000], *root;
int top;

int n, m;
int p[50001];

node* buildTree(int left, int right) {
	node* cur = &pool[++top];
	cur->left = left;
	cur->right = right;
	cur->lazy = 0;
	if (left == right) {
		cur->Max = p[left];
		cur->lson->rson = NULL;
	}
	else {
		cur->lson = buildTree(left, (left + right) / 2);
		cur->rson = buildTree((left + right) / 2 + 1, right);
		cur->Max = max(cur->lson->Max, cur->rson->Max);
		cur->lson = 0;
	}
	return cur;
}

int query(int left, int right) {

}

int main(int argc, char* argv[]) {
	system("PAUSE");
	return 0;
}

#endif
