/*
DOCUMENT CODE "NOIP2012D2T1.cpp"
CREATION DATE 2017-01-12
SIGNATURE CODE_20170112_NOIP2012D2T1
TOPIC NOIP2012 ����� �ڶ����һ�� ͬ�෽��
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170112_NOIP2012D2T1

#include<iostream>
#include<cstdio>

using namespace std;

void extended_Euclid(long long a, long long b, long long * d, long long* x, long long * y) {
	long long d1, x1, y1;
	if (b == 0) {
		*d = a;
		*x = 1;
		*y = 0;
	}
	else {
		extended_Euclid(b, a%b, &d1, &x1, &y1);
		*d = d1;
		*x = y1;
		*y = x1 - a / b*y1;
	}
}

int main() {
	long long a, b, x, y, c;
	cin >> a >> b;
	extended_Euclid(a, b, &c, &x, &y);
	while (x < 0)
		x = x + b;
	cout << x;
	system("PAUSE");
	return 0;
}

#endif
