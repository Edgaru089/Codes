/*
DOCUMENT CODE "zsy1.cpp"
CREATION DATE 2017-01-12
SIGNATURE CODE_20170112_ZSY1
TOPIC ����n����������Ϊm�������ж��ٸ�
����1	3 3
		1 2 3
��		2
*/

#include "Overall.hpp"

//Check if this codefile is enabled for testing.
#ifdef CODE_20170112_ZSY1

#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <iomanip>

using namespace std;

int n, m;
int a[100001], pref[100001], prefXor[100001];
int cur, curXor;
long long ans;

int main(int argc, char* argv[]) {
	cin >> n >> m;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		pref[i] = pref[i - 1] ^ a[i];
		prefXor[i] = pref[i] ^ m;
	}
	n++;
	pref[n] = 0;
	prefXor[n] = 0 ^ m;
	sort(pref + 1, pref + n + 1);
	sort(prefXor + 1, prefXor + n + 1);
	for (int i = 1; i <= n; i++) {
		cout << " " << pref[i];
	}
	cout << endl;
	for (int i = 1; i <= n; i++) {
		cout << " " << prefXor[i];
	}
	cout << endl;
	cur = curXor = 1;
	while (cur <= n&&curXor <= n) {
		if (pref[cur] == prefXor[curXor]) {
			int sum = 1, sumXor = 1;
			while (pref[cur] == pref[cur + 1] && cur <= n - 1) {
				cur++;
				sum++;
			}
			while (prefXor[curXor] == prefXor[curXor + 1] && curXor <= n - 1) {
				curXor++;
				sumXor++;
			}
			cur++;
			curXor++;
			ans += sum*sumXor;
		}
		else if (pref[cur] < prefXor[curXor])
			cur++;
		else if (prefXor[curXor] < pref[cur])
			curXor++;
	}
	if (m == 0)
		ans -= n + 1;
	cout << ans / 2 << endl;
	system("PAUSE");
	return 0;
}

#endif
